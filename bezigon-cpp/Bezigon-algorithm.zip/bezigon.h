// bezigon.h
// Bezigon handle computation.
//
// This file defines the data model and the two functions the host
// application needs to call. It has no dependency on any windowing
// or graphics library — only on the C++ standard library.

#pragma once
#include <vector>

namespace bezigon {
	
// Version of this interface. Bump when the public API changes.
#define BEZIGON_VERSION "1.0"
	
// A path node. Position, type, and the two handle offsets.
//
//   hx_in,  hy_in   offset from the node to the incoming control point
//   hx_out, hy_out  offset from the node to the outgoing control point
//
//   smooth  true for a smooth node (modifier click), false for a cusp
//   manual  true if the user has dragged a handle here; the algorithm
//           will not overwrite the handles of a manual node
	struct Node
	{
		double x, y;
		bool   smooth;
		bool   manual;
		double hx_in,  hy_in;
		double hx_out, hy_out;
	};
	
// Tunable constants for the algorithm.
	struct Options
	{
		// Fraction of the local segment length used as handle length.
		// 0.39 matches FreeHand's Bezigon tool.
		double handleFraction = 0.39;
	};
	
// Fill in the handles of every non-manual node in the list.
//
//   nodes               the path's nodes, in order
//   closed              true if the path is closed
//   closedWithModifier  true if the closing click used the modifier key
//   opts                tuning constants
//
// All handles are overwritten on non-manual nodes. Manual nodes are
// left untouched.
	void compute_handles(std::vector<Node>& nodes,
						 bool closed,
						 bool closedWithModifier,
						 const Options& opts = Options());
	
// Called by the host application when the user drags a handle.
//
//   node    the node whose handle is being dragged
//   isIn    true to drag the in-handle, false for the out-handle
//   x, y    the new tip position, in the same coordinate space as the node
//
// Sets the dragged handle to point at (x, y). If the node is smooth,
// the opposite handle is rotated so the two remain collinear, and its
// length is preserved. Marks the node as manual so subsequent calls to
// compute_handles() leave its handles alone.
	void drag_handle(Node& node, bool isIn, double x, double y);
	
}

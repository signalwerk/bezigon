# Bezigon-Handle-Berechnung

Eine kleine, in sich geschlossene C++-Implementierung der
Bezigon-Regeln aus Macromedia FreeHand. Ausgehend von einer Liste
von Pfadknoten mit ihren Positionen und Typen berechnet sie die
Bezier-Kontrollpunkte, die zum Zeichnen des Pfades benötigt werden.

**Version:** 1.0.1

## Aufbau dieses Pakets

Das Paket ist so aufgebaut, dass der Algorithmus ohne Abhängigkeiten,
ohne Einrichtung und ohne Plattformannahmen in eine beliebige
Codebasis übernommen werden kann. Für die Integration sind nur zwei
der fünf Dateien relevant; alles andere ist Referenzmaterial.

| Datei | Zweck | Für Integration nötig? |
|---|---|---|
| `bezigon.h` | Öffentliche Schnittstelle: Datentypen und Funktionsdeklarationen | **Ja** |
| `bezigon.cpp` | Der Algorithmus | **Ja** |
| `main.cpp` | Interaktive Demo (benötigt EGE unter Windows) | Nein |
| `test_bezigon.cpp` | Eigenständige Tests | Nein |
| `README.md` | Diese Datei | Nein |

### Warum die Dateien so aufgeteilt sind

Algorithmus und Demo waren ursprünglich eine einzige Datei. Die
Aufteilung erfolgte aus drei Gründen:

1. **Der Algorithmus hat keine Abhängigkeiten.** `bezigon.h` und
   `bezigon.cpp` verwenden nur `<vector>` und `<cmath>` — keine
   Grafikbibliothek, kein Windowing, kein Plattformcode. `main.cpp`
   hingegen benötigt EGE und Windows, um ein Fenster zu öffnen und
   Maus- und Tastatureingaben zu verarbeiten. Durch die Aufteilung
   kann der Algorithmus unverändert in PhotoLine übernommen werden,
   ohne die Abhängigkeiten der Demo mitzuschleppen.

2. **Die beiden Dateien haben unterschiedliche Adressaten.**
   `main.cpp` ist eine visuelle Referenz — nützlich, um die Ausgabe
   des Algorithmus mit FreeHand zu vergleichen. `bezigon.cpp` ist der
   Code, der tatsächlich ausgeliefert wird. Die Trennung macht auf
   einen Blick klar, was was ist.

3. **Die interaktive Logik gehört zum Algorithmus, nicht zur Demo.**
   Die Regel, was passiert, wenn der Benutzer ein Handle zieht (das
   gegenüberliegende Handle spiegelt sich, wenn der Knoten ein
   Kurvenpunkt ist), ist eine Bezigon-Regel und nicht die Regel
   irgendeiner Benutzeroberfläche. Sie liegt in `bezigon.cpp` und
   wird als `drag_handle` exportiert, damit PhotoLine sie nicht
   erneut implementieren muss.

### Inhalt der einzelnen Dateien

- **`bezigon.h`** — Die Struktur `Node` (Position, Typ, Handles), die
  Struktur `Options` (Feinabstimmung) sowie die Deklarationen von
  `compute_handles` und `drag_handle`. Dies ist die gesamte
  öffentliche Schnittstelle der Bibliothek. Alles andere im Paket
  gehört zur internen Implementierung oder zur Demo.

- **`bezigon.cpp`** — Die Implementierung der fünf Regeln, die die
  Handle-Positionen bestimmen. Etwa 200 Zeilen. Ohne eigenen Zustand;
  alle Daten werden übergeben und an Ort und Stelle geändert.
  Thread-sicher, solange nicht zwei Threads auf derselben Knotenliste
  arbeiten.

- **`main.cpp`** — Eine lauffähige Demo. Öffnet ein Fenster, verarbeitet
  Maus- und Tastaturereignisse, ruft `compute_handles` zum richtigen
  Zeitpunkt auf und zeichnet die resultierende Form. Ihr einziger
  Zweck ist, einem Menschen die Ausgabe des Algorithmus sichtbar zu
  machen und einen Vergleich mit FreeHand zu ermöglichen. Sie ist
  nicht Teil des Lieferumfangs und kann jederzeit gelöscht werden.

- **`test_bezigon.cpp`** — Ein Konsolenprogramm, das automatische
  arithmetische Prüfungen des Algorithmus ausführt und entweder
  `all tests passed` oder eine Liste von Fehlschlägen ausgibt. Siehe
  „Wozu die Testdatei dient" weiter unten.

- **`README.md`** — Dieses Dokument.

## Wozu die Testdatei dient

`test_bezigon.cpp` dient dazu, **Probleme des Algorithmus von
Integrationsproblemen zu trennen**.

Wenn der Algorithmus erstmals in PhotoLine eingebunden wird und
irgendetwas falsch aussieht, stellt sich die Frage: Liefert der
Algorithmus schlechte Handles, oder ruft PhotoLine ihn mit schlechten
Eingaben auf? Ein Lauf der Tests beantwortet das sofort. Wenn die
Tests bestehen, ist der Algorithmus in Ordnung, und das Problem liegt
auf der Integrationsseite — Befüllen der Knoten, Koordinatenraum,
Schließen-Flag, etwas in dieser Richtung. Wenn die Tests fehlschlagen,
hat sich der Algorithmus selbst verschlechtert.

Die Tests prüfen Arithmetik, nicht das visuelle Ergebnis. Sie
verifizieren zum Beispiel, dass ein Kreis aus vier Kurvenpunkten
Handles exakt der erwarteten Länge erzeugt, dass kollineare Eckpunkte
waagerechte Handles liefern, und dass Regel 5 nur greift, wenn alle
drei Bedingungen erfüllt sind. Sie öffnen kein Fenster und zeichnen
nichts.

Führen Sie die Tests nach jeder Änderung an `bezigon.cpp` aus. Sie
brauchen weniger als eine Sekunde zum Kompilieren und weniger als
eine Sekunde zum Ausführen.

## Schnittstelle

    #include "bezigon.h"

    std::vector<bezigon::Node> nodes = ...;  // nach Wunsch befüllen

    bezigon::compute_handles(nodes,
                             /*closed*/             true,
                             /*closedWithModifier*/ false);

Nach dem Aufruf hat jeder nicht-manuelle Knoten in `nodes` seine
Felder `hx_in, hy_in, hx_out, hy_out` gefüllt.

Es gibt eine zweite exportierte Funktion, `drag_handle`, für die
interaktive Bearbeitung.

## Integrationsanleitung

### Schritt 1 — Entscheiden Sie, wo Ihre Knoten liegen

Der Algorithmus arbeitet auf `std::vector<bezigon::Node>`. Sie haben
zwei Möglichkeiten:

- **Behalten Sie Ihre Knotendarstellung bei** und kopieren Sie sie
  vor jedem Aufruf in einen `std::vector<Node>` und die Handles
  hinterher zurück. Einfacher, wenn sich Ihre Darstellung stark von
  unserer unterscheidet.
- **Verwenden Sie `bezigon::Node` direkt** in Ihren Pfaddaten. Kein
  Kopieren. Sauberer, setzt aber voraus, dass Ihre Pfaddarstellung
  die beiden zusätzlichen Felder `smooth` und `manual` aufnehmen kann.

Beide Ansätze funktionieren. Die Struktur `bezigon::Node` ist bewusst
minimal gehalten — sechs `double` und zwei `bool` — und lässt sich
daher fast überall einbetten.

### Schritt 2 — Knotenliste befüllen

Für jeden Knoten des Pfades, in Reihenfolge:

    n.x      = position.x;
    n.y      = position.y;
    n.smooth = (dieser Knoten wurde mit Modifikatortaste gesetzt);
    n.manual = (der Benutzer hat eines seiner Handles gezogen);
    // Handle-Felder können beim ersten Aufruf uninitialisiert bleiben

Bei einem neuen Pfad ist `manual` immer `false`. Es wird erst `true`,
wenn der Benutzer ein Handle interaktiv zieht (siehe Schritt 5).

### Schritt 3 — compute_handles aufrufen

    bezigon::compute_handles(nodes,
                             path.isClosed,
                             path.wasClosedWithModifier);

**Wann aufrufen:** nach jeder Änderung, die die Geometrie der Form
beeinflusst. Das heißt:

- Nach dem Hinzufügen eines Knotens
- Nach dem Entfernen eines Knotens
- Nach dem Verschieben eines Knotens
- Nach dem Umschalten des Geschlossen-Zustands
- Nach dem Schließen des Pfades

**Wann nicht aufrufen:** bei jedem Einzelbild. Die Handle-Positionen
sind stabil, solange sich die Knotenliste nicht ändert. Zwischenspeichern.

In einem typischen interaktiven Editor heißt das: einmal beim
Abschluss des Ziehens aufrufen, nicht bei jeder Mausbewegung.
Alternativ können Sie es bei jeder Mausbewegung während des Ziehens
aufrufen — es ist günstig (wenige Mikrosekunden für einen typischen
Pfad), aber nicht kostenlos. Ihre Wahl, je nach Aufbau Ihres Editors.

### Schritt 4 — Segmente zeichnen

Für jedes Paar aufeinanderfolgender Knoten eine kubische Bezierkurve
zeichnen:

    P0 = (nodes[i].x,                       nodes[i].y)
    P1 = (nodes[i].x + nodes[i].hx_out,     nodes[i].y + nodes[i].hy_out)
    P2 = (nodes[i+1].x + nodes[i+1].hx_in,  nodes[i+1].y + nodes[i+1].hy_in)
    P3 = (nodes[i+1].x,                     nodes[i+1].y)

Wenn der Pfad geschlossen ist, zusätzlich das Segment vom letzten
Knoten zurück zum ersten zeichnen.

Wie Sie die Bezierkurve tatsächlich zeichnen — mit Ihrem eigenen
Rasterizer, durch Zerlegung in Liniensegmente, oder über die GPU —
bleibt Ihnen überlassen. Der Algorithmus liefert die vier
Kontrollpunkte; das Zeichnen ist Aufgabe Ihrer vorhandenen Pipeline.

### Schritt 5 — Interaktives Bearbeiten von Handles (optional)

Wenn der Benutzer ein Handle ergreift und zieht:

    bezigon::drag_handle(node, isIn, newX, newY);

Dabei ist `isIn` `true` für das In-Handle (zum vorherigen Knoten hin)
und `false` für das Out-Handle (zum nächsten Knoten hin). `newX, newY`
ist die neue Position der Handle-Spitze.

Die Funktion:

- setzt das gezogene Handle auf die Richtung von `(newX, newY)`
- dreht bei einem Kurvenpunkt das gegenüberliegende Handle mit, sodass
  beide kollinear bleiben, und behält dabei dessen Länge bei
- markiert den Knoten als `manual`, sodass nachfolgende Aufrufe von
  `compute_handles` seine Handles nicht überschreiben

### Schritt 6 — Neu zeichnen

Nach jeder der obigen Operationen die Form mit den aktuellen
Handle-Positionen neu zeichnen. Sonst muss nichts mitgeteilt werden —
die Handles sind einfach Zahlen in den Knotenstrukturen.

## Ein minimales Beispiel

    #include "bezigon.h"
    #include <vector>

    using bezigon::Node;

    // Drei Knoten, offener Pfad: Eckpunkt, Kurvenpunkt, Eckpunkt.
    std::vector<Node> nodes(3);

    nodes[0] = { 100, 100, false, false, 0, 0, 0, 0 };
    nodes[1] = { 300, 200, true,  false, 0, 0, 0, 0 };
    nodes[2] = { 500, 100, false, false, 0, 0, 0, 0 };

    bezigon::compute_handles(nodes, /*closed*/ false,
                             /*closedWithModifier*/ false);

    // Jetzt hat nodes[1] von Null verschiedene Werte in
    // hx_in, hy_in, hx_out, hy_out.
    // Die beiden Beziersegmente (0->1 und 1->2) nach der Formel
    // aus Schritt 4 zeichnen.

## Knotentypen

Ein Knoten hat zwei relevante Flags:

- `smooth` — `true` für einen Kurvenpunkt (Modifikatorklick in
  FreeHand), `false` für einen Eckpunkt (einfacher Klick).
- `manual` — `true`, wenn der Benutzer an diesem Knoten ein Handle
  gezogen hat; `compute_handles` überschreibt manuelle Handles nicht.
  Die Tangente des Knotens wird trotzdem an benachbarte Eckpunkte
  gemeldet, damit diese sie spiegeln können.

## Die fünf Regeln

1. **Kurvenpunkt.** Die Handles liegen auf der Tangente, das heißt in
   Richtung vom vorherigen zum nächsten Knoten.
2. **Eckpunkt mit einem Kurvenpunkt als Nachbarn.** Das Handle auf
   dieser Seite ist die Spiegelung der Tangente des Kurvenpunkts über
   die Sehne. Dadurch wird ein gekrümmtes Segment zu einem echten
   Kreisbogen.
3. **Eckpunkt zwischen zwei Eckpunkten (oder Endpunkt).** Das Handle
   zeigt direkt auf den Nachbarn — ein gerades Segment.
4. **Schließen eines Pfades.** Ein Modifikator-Klick beim Schließen
   erzwingt am Startknoten einen Eckpunkt; ein einfacher Klick lässt
   seinen Typ unverändert.
5. **Mit einfachem Klick geschlossener Pfad, bei dem Startknoten und
   zweiter Knoten Eckpunkte sind und der letzte Knoten ein
   Kurvenpunkt ist.** Die Handles des Startknotens werden kollinear
   und liegen auf der Linie vom Start zum zweiten Knoten. Alle drei
   Bedingungen sind erforderlich.

## Feinabstimmung

Der Handle-Längenanteil wird in `bezigon::Options::handleFraction`
gesetzt und beträgt standardmäßig **0,39**, entsprechend dem
Bezigon-Werkzeug von FreeHand. Es ist der Anteil der lokalen
Segmentlänge, der als Handle-Länge verwendet wird.

## Annahmen

Zwei der oben genannten Regeln sind **Rekonstruktionen** des
FreeHand-Verhaltens, abgeleitet aus visuellen Vergleichen mit
FreeHand-Ausgaben. Sie stimmen mit den von uns getesteten Fällen
überein, beruhen aber auf keiner veröffentlichten Spezifikation:

- Die Handle-Längenregel für Eckpunkte verwendet den *Mittelwert* der
  beiden angrenzenden Segmentlängen als gemeinsame Länge für beide
  Seiten. Das ergab in unseren Tests ausgewogene Eckpunkte, aber die
  tatsächliche Regel von FreeHand kann leicht abweichen.
- Die Spiegelungsregel für Eckpunkte mit einem Kurvenpunkt als
  Nachbarn erzeugt in den getesteten Fällen Kreisbögen. Sie ist für
  einen echten Kreisbogen mathematisch exakt, ihr Verhalten bei stark
  nicht-kreisförmigen Segmenten wurde jedoch nicht mit FreeHand
  verifiziert.

Sollte die Integration bei irgendeiner Konfiguration Formen ergeben,
die von FreeHand abweichen, sind diese beiden Regeln die ersten
Stellen, an denen man nachsehen sollte.

## Anzeige der Handles

Der Algorithmus liefert nur Handle-*Positionen* — vier Zahlen pro
Knoten. Er zeichnet nicht, führt kein Hit-Testing durch und verwaltet
keine Auswahl. Alle Anzeige- und Interaktionsregeln liegen in der
Verantwortung der Host-Anwendung.

Insbesondere zeigt die Demo Handles nur, wenn der Benutzer D drückt.
Das ist eine Bequemlichkeit der Demo, keine Eigenschaft des
Algorithmus. PhotoLine sollte Handles nach seinen eigenen
bestehenden Konventionen anzeigen — zum Beispiel die Handles eines
Knotens, wenn dieser ausgewählt ist. Der Algorithmus wird davon nicht
beeinflusst.

## Zuordnung der Modifikatortaste

Der Algorithmus weiß nichts über physische Tasten. Er erhält nur zwei
boolesche Werte:

- `Node::smooth` — vom Host auf `true` gesetzt, wenn der Benutzer
  einen Knoten mit gedrückter Modifikatortaste platziert.
- `closedWithModifier` — vom Host auf `true` gesetzt, wenn der
  Benutzer einen Pfad mit gedrückter Modifikatortaste schließt.

Welche physische Taste auf diese booleschen Werte abgebildet wird,
ist allein eine Entscheidung der Host-Anwendung. Die Demo verwendet
Umschalt (Shift), weil Windows unter Windows die Alt-Taste abfängt,
bevor die Anwendung sie sieht. FreeHand verwendete Alt (auf dem
Macintosh: Option). PhotoLine sollte die Konvention verwenden, die zu
seinen bestehenden Werkzeugen passt — der Algorithmus verhält sich in
allen Fällen identisch.

## Abhängigkeiten

Der Algorithmus verwendet nur `<vector>` und `<cmath>`. Keine
Grafikbibliothek, kein Plattformcode, keine Ein-/Ausgabe.

Die Demo (`main.cpp`) benötigt EGE und Windows. Sie ist für die
Integration nicht erforderlich und kann ohne Einfluss auf den
Algorithmus aus dem Paket gelöscht werden.

## Kompilieren der Tests

Mit GCC:

    g++ -std=c++11 -O2 bezigon.cpp test_bezigon.cpp -o test_bezigon
    ./test_bezigon

Erwartete Ausgabe:

    all tests passed
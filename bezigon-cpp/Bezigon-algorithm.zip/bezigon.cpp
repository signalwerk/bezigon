// bezigon.cpp
// Implementation of the Bezigon handle computation.
//
// The five rules this implements, in order of precedence:
//
//   Rule 1  Smooth node: handles lie on the tangent through the node,
//           which is the direction from the previous node to the next.
//
//   Rule 2  Cusp node with a smooth neighbour on one side: the handle
//           toward that neighbour is the reflection of the neighbour's
//           tangent across the chord between the two nodes. This is
//           what makes curved segments into proper arcs.
//
//   Rule 3  Cusp node between two cusps (or endpoint): the handle
//           points straight at the neighbour — a straight segment.
//
//   Rule 4  Start node of a closed path: a modifier close forces it to
//           a cusp; a plain close leaves its type unchanged.
//
//   Rule 5  Start node of a *plain*-closed path: if the start node is
//           a cusp, the second node is a cusp, AND the last node is
//           smooth, the handles are collinear, lying on the line from
//           start to second node.
//
// A manual flag on a smooth node means the user has set that node's
// handles by hand. Its tangent is still reported to the neighbouring
// cusps, so they can reflect it; only the node's own handles are left
// alone.

#include "bezigon.h"
#include <cmath>

namespace bezigon {
	
// Any length below this is treated as zero.
	static const double MIN_LENGTH = 1e-9;
	
// --- Index helpers (wrap around for closed paths) ---
	
	static int prev_index(int i, int n, bool closed)
	{
		if (i == 0) return closed ? (n - 1) : -1;
		return i - 1;
	}
	
	static int next_index(int i, int n, bool closed)
	{
		if (i == n - 1) return closed ? 0 : -1;
		return i + 1;
	}
	
// --- Rule 2 helper: reflect a direction across a chord ---
	
// Given the smooth tangent (sx, sy) at one end of a chord, and the
// chord direction (cx, cy), compute the corresponding tangent at the
// other end of the chord.
	static void reflect(double sx, double sy,
						double cx, double cy,
						double& tx, double& ty)
	{
		double dot = sx * cx + sy * cy;
		tx = 2.0 * dot * cx - sx;
		ty = 2.0 * dot * cy - sy;
	}
	
	void compute_handles(std::vector<Node>& nodes,
						 bool closed,
						 bool closedWithModifier,
						 const Options& opts)
	{
		const int n = (int)nodes.size();
		if (n == 0) return;
		const bool isClosed = closed && n >= 3;
		
		// Reusable per-call scratch buffers.
		static thread_local std::vector<double> stx;
		static thread_local std::vector<double> sty;
		static thread_local std::vector<char>   hasST;
		stx.assign(n, 0.0);
		sty.assign(n, 0.0);
		hasST.assign(n, 0);
		
		// --- Pass 1: precompute the smooth tangent at each smooth node ---
		// Rule 1: the tangent is the direction from the previous node to
		// the next. Manual smooth nodes use the direction of their own
		// handles, so the adjacent cusps can still reflect the tangent.
		for (int i = 0; i < n; ++i) {
			const Node& node = nodes[i];
			if (!node.smooth) continue;
			
			if (node.manual) {
				double dx = node.hx_out;
				double dy = node.hy_out;
				double tl = std::sqrt(dx * dx + dy * dy);
				if (tl < MIN_LENGTH) {
					dx = -node.hx_in;
					dy = -node.hy_in;
					tl = std::sqrt(dx * dx + dy * dy);
				}
				if (tl < MIN_LENGTH) continue;
				stx[i] = dx / tl;
				sty[i] = dy / tl;
				hasST[i] = 1;
				continue;
			}
			
			int pi = prev_index(i, n, isClosed);
			int ni = next_index(i, n, isClosed);
			if (pi < 0 || ni < 0) continue;
			double tx = nodes[ni].x - nodes[pi].x;
			double ty = nodes[ni].y - nodes[pi].y;
			double tl = std::sqrt(tx * tx + ty * ty);
			if (tl < MIN_LENGTH) continue;
			stx[i] = tx / tl;
			sty[i] = ty / tl;
			hasST[i] = 1;
		}
		
		// --- Pass 2: fill in the handles of every non-manual node ---
		for (int i = 0; i < n; ++i) {
			Node& node = nodes[i];
			if (node.manual) continue;
			
			int pi = prev_index(i, n, isClosed);
			int ni = next_index(i, n, isClosed);
			
			double toPrevX = 0, toPrevY = 0, lenPrev = 0;
			double toNextX = 0, toNextY = 0, lenNext = 0;
			if (pi >= 0) {
				toPrevX = nodes[pi].x - node.x;
				toPrevY = nodes[pi].y - node.y;
				lenPrev = std::sqrt(toPrevX * toPrevX + toPrevY * toPrevY);
			}
			if (ni >= 0) {
				toNextX = nodes[ni].x - node.x;
				toNextY = nodes[ni].y - node.y;
				lenNext = std::sqrt(toNextX * toNextX + toNextY * toNextY);
			}
			
			node.hx_in  = node.hy_in  = 0.0;
			node.hx_out = node.hy_out = 0.0;
			
			// --- Rule 5: collinear start of a plain-closed path, when
			//     the start node is a cusp, the second node is a cusp,
			//     and the last node is smooth. ---
			if (i == 0 && isClosed && !closedWithModifier && !node.smooth
				&& pi >= 0 && ni >= 0 && lenNext > MIN_LENGTH
				&& !nodes[ni].smooth
				&&  nodes[pi].smooth)
			{
				double tx = toNextX / lenNext;
				double ty = toNextY / lenNext;
				node.hx_in  = -tx * (opts.handleFraction * lenPrev);
				node.hy_in  = -ty * (opts.handleFraction * lenPrev);
				node.hx_out =  tx * (opts.handleFraction * lenNext);
				node.hy_out =  ty * (opts.handleFraction * lenNext);
				continue;
			}
			
			// --- Rule 1: smooth node. Handles lie on the tangent. ---
			if (pi >= 0 && ni >= 0 && node.smooth) {
				node.hx_in  = -stx[i] * (opts.handleFraction * lenPrev);
				node.hy_in  = -sty[i] * (opts.handleFraction * lenPrev);
				node.hx_out =  stx[i] * (opts.handleFraction * lenNext);
				node.hy_out =  sty[i] * (opts.handleFraction * lenNext);
				continue;
			}
			
			// --- Rules 2 & 3: cusp (or endpoint). ---
			// Handle length: a single common value, the average of the
			// two sides. Endpoints use the one side they have.
			double commonLen;
			if (pi < 0)      commonLen = opts.handleFraction * lenNext;
			else if (ni < 0) commonLen = opts.handleFraction * lenPrev;
			else             commonLen = opts.handleFraction * (lenPrev + lenNext) * 0.5;
			
			// In-handle, pointing toward the previous node.
			if (pi >= 0 && lenPrev > MIN_LENGTH) {
				double tax, tay;
				if (hasST[pi]) {
					double cx = -toPrevX / lenPrev;
					double cy = -toPrevY / lenPrev;
					reflect(stx[pi], sty[pi], cx, cy, tax, tay);
				} else {
					tax = -toPrevX / lenPrev;
					tay = -toPrevY / lenPrev;
				}
				node.hx_in = -tax * commonLen;
				node.hy_in = -tay * commonLen;
			}
			
			// Out-handle, pointing toward the next node.
			if (ni >= 0 && lenNext > MIN_LENGTH) {
				double tax, tay;
				if (hasST[ni]) {
					double ux = toNextX / lenNext;
					double uy = toNextY / lenNext;
					reflect(stx[ni], sty[ni], ux, uy, tax, tay);
				} else {
					tax = toNextX / lenNext;
					tay = toNextY / lenNext;
				}
				node.hx_out = tax * commonLen;
				node.hy_out = tay * commonLen;
			}
		}
	}
	
	void drag_handle(Node& node, bool isIn, double x, double y)
	{
		double dx = x - node.x;
		double dy = y - node.y;
		
		if (isIn) {
			node.hx_in = dx;
			node.hy_in = dy;
			if (node.smooth) {
				double oppLen = std::sqrt(node.hx_out * node.hx_out +
										  node.hy_out * node.hy_out);
				double curLen = std::sqrt(dx * dx + dy * dy);
				if (curLen > MIN_LENGTH && oppLen > MIN_LENGTH) {
					node.hx_out = -dx / curLen * oppLen;
					node.hy_out = -dy / curLen * oppLen;
				}
			}
		} else {
			node.hx_out = dx;
			node.hy_out = dy;
			if (node.smooth) {
				double oppLen = std::sqrt(node.hx_in * node.hx_in +
										  node.hy_in * node.hy_in);
				double curLen = std::sqrt(dx * dx + dy * dy);
				if (curLen > MIN_LENGTH && oppLen > MIN_LENGTH) {
					node.hx_in = -dx / curLen * oppLen;
					node.hy_in = -dy / curLen * oppLen;
				}
			}
		}
		
		node.manual = true;
	}
	
}

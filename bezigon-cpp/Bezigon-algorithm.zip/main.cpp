// main.cpp
// Bezigon demo — EGE window, mouse and keyboard handling, drawing.
// Uses bezigon.h / bezigon.cpp for the handle computation.

#include <graphics.h>
#include <cmath>
#include "bezigon.h"

using bezigon::Node;

static const int HIT_RADIUS          = 10;
static const int NODE_HIT_RADIUS     = 8;
static const int HANDLE_HIT_RADIUS   = 8;
static const int CLOSE_MOVE_SQ       = 25;
static const int STEPS               = 200;

static std::vector<Node> g_nodes;
static bool              g_finished            = false;
static bool              g_closed              = false;
static bool              g_closedWithModifier  = false;
static bool              g_showHandles         = false;

enum DragKind { DRAG_NONE, DRAG_NODE, DRAG_HANDLE_IN, DRAG_HANDLE_OUT };
static DragKind g_dragKind       = DRAG_NONE;
static int      g_dragIndex      = -1;
static int      g_pressX         = 0;
static int      g_pressY         = 0;
static bool     g_potentialClose = false;

static void add_node(int x, int y, bool smooth)
{
	if (g_finished) {
		g_nodes.clear();
		g_finished           = false;
		g_closed             = false;
		g_closedWithModifier = false;
	}
	Node n;
	n.x = x;  n.y = y;
	n.smooth = smooth;
	n.manual = false;
	n.hx_in = n.hy_in = n.hx_out = n.hy_out = 0.0;
	g_nodes.push_back(n);
	bezigon::compute_handles(g_nodes, g_closed, g_closedWithModifier);
}

static bool try_close(int x, int y, bool modifier)
{
	if (g_nodes.size() < 3) return false;
	
	double dx = g_nodes[0].x - x;
	double dy = g_nodes[0].y - y;
	if (dx * dx + dy * dy > (double)HIT_RADIUS * HIT_RADIUS) return false;
	
	if (modifier) g_nodes[0].smooth = false;
	
	g_finished           = true;
	g_closed             = true;
	g_closedWithModifier = modifier;
	bezigon::compute_handles(g_nodes, g_closed, g_closedWithModifier);
	return true;
}

static int hit_node(int x, int y)
{
	for (int i = 0; i < (int)g_nodes.size(); ++i) {
		int dx = g_nodes[i].x - x;
		int dy = g_nodes[i].y - y;
		if (dx * dx + dy * dy <= NODE_HIT_RADIUS * NODE_HIT_RADIUS)
			return i;
	}
	return -1;
}

static int hit_handle(int x, int y, bool& isIn)
{
	for (int i = 0; i < (int)g_nodes.size(); ++i) {
		const Node& n = g_nodes[i];
		if (n.hx_in != 0.0 || n.hy_in != 0.0) {
			double hx = n.x + n.hx_in;
			double hy = n.y + n.hy_in;
			double dx = hx - x, dy = hy - y;
			if (dx * dx + dy * dy <= HANDLE_HIT_RADIUS * HANDLE_HIT_RADIUS) {
				isIn = true;  return i;
			}
		}
		if (n.hx_out != 0.0 || n.hy_out != 0.0) {
			double hx = n.x + n.hx_out;
			double hy = n.y + n.hy_out;
			double dx = hx - x, dy = hy - y;
			if (dx * dx + dy * dy <= HANDLE_HIT_RADIUS * HANDLE_HIT_RADIUS) {
				isIn = false;  return i;
			}
		}
	}
	return -1;
}

static void start_press(int x, int y, bool shift)
{
	bool isIn = false;
	int hi = hit_handle(x, y, isIn);
	if (hi >= 0) {
		g_dragKind  = isIn ? DRAG_HANDLE_IN : DRAG_HANDLE_OUT;
		g_dragIndex = hi;
		g_pressX    = x;  g_pressY = y;
		g_potentialClose = false;
		return;
	}
	
	int ni = hit_node(x, y);
	if (ni >= 0) {
		g_dragKind  = DRAG_NODE;
		g_dragIndex = ni;
		g_pressX    = x;  g_pressY = y;
		g_potentialClose = (ni == 0 && g_nodes.size() >= 3 && !g_closed);
		return;
	}
	
	add_node(x, y, shift);
	g_dragKind  = DRAG_NODE;
	g_dragIndex = (int)g_nodes.size() - 1;
	g_pressX    = x;  g_pressY = y;
	g_potentialClose = false;
}

static void continue_drag(int x, int y)
{
	if (g_dragKind == DRAG_NONE) return;
	
	if (g_potentialClose) {
		int dx = x - g_pressX, dy = y - g_pressY;
		if (dx * dx + dy * dy <= CLOSE_MOVE_SQ) return;
		g_potentialClose = false;
	}
	
	Node& n = g_nodes[g_dragIndex];
	
	if (g_dragKind == DRAG_NODE) {
		n.x = x;  n.y = y;
		bezigon::compute_handles(g_nodes, g_closed, g_closedWithModifier);
		return;
	}
	
	if (g_dragKind == DRAG_HANDLE_IN) {
		bezigon::drag_handle(n, true, x, y);
	}
	else if (g_dragKind == DRAG_HANDLE_OUT) {
		bezigon::drag_handle(n, false, x, y);
	}
}

static void finish_press(int x, int y, bool shift)
{
	if (g_potentialClose) try_close(x, y, shift);
	g_dragKind       = DRAG_NONE;
	g_dragIndex      = -1;
	g_potentialClose = false;
}

static void draw_node(int x, int y, bool smooth)
{
	const int r = 5;
	if (smooth) {
		setfillcolor(EGERGB(60, 120, 220));
		setlinecolor(EGERGB(60, 120, 220));
		fillcircle(x, y, r);
	} else {
		setfillcolor(EGERGB(220, 60, 60));
		setlinecolor(EGERGB(220, 60, 60));
		fillrect(x - r, y - r, x + r, y + r);
	}
	setlinecolor(EGERGB(0, 0, 0));
}

static void draw_bezier(double x0, double y0,
						double x1, double y1,
						double x2, double y2,
						double x3, double y3)
{
	double prevX = x0, prevY = y0;
	for (int s = 1; s <= STEPS; ++s) {
		double t  = (double)s / STEPS;
		double mt = 1.0 - t;
		double a = mt * mt * mt;
		double b = 3.0 * mt * mt * t;
		double c = 3.0 * mt * t * t;
		double d = t * t * t;
		double x = a * x0 + b * x1 + c * x2 + d * x3;
		double y = a * y0 + b * y1 + c * y2 + d * y3;
		line((int)(prevX + 0.5), (int)(prevY + 0.5),
			 (int)(x + 0.5),     (int)(y + 0.5));
		prevX = x;  prevY = y;
	}
}

static void draw_segment(const Node& a, const Node& b)
{
	draw_bezier(a.x, a.y,
				a.x + a.hx_out, a.y + a.hy_out,
				b.x + b.hx_in,  b.y + b.hy_in,
				b.x, b.y);
}

static void redraw(int mouseX, int mouseY)
{
	cleardevice();
	setlinestyle(PS_SOLID, 2);
	setlinecolor(EGERGB(0, 0, 0));
	
	for (size_t i = 1; i < g_nodes.size(); ++i)
		draw_segment(g_nodes[i - 1], g_nodes[i]);
	
	if (g_closed && g_nodes.size() >= 2)
		draw_segment(g_nodes.back(), g_nodes.front());
	
	if (!g_finished && !g_nodes.empty()) {
		setlinestyle(PS_DOT, 1);
		setlinecolor(EGERGB(150, 150, 150));
		line(g_nodes.back().x, g_nodes.back().y, mouseX, mouseY);
		setlinestyle(PS_SOLID, 2);
		setlinecolor(EGERGB(0, 0, 0));
	}
	
	if (g_showHandles) {
		setlinestyle(PS_SOLID, 1);
		setlinecolor(EGERGB(120, 200, 120));
		for (size_t i = 0; i < g_nodes.size(); ++i) {
			const Node& n = g_nodes[i];
			if (n.hx_in != 0.0 || n.hy_in != 0.0) {
				int hx = (int)(n.x + n.hx_in + 0.5);
				int hy = (int)(n.y + n.hy_in + 0.5);
				line(n.x, n.y, hx, hy);
				setfillcolor(EGERGB(120, 200, 120));
				fillcircle(hx, hy, 3);
			}
			if (n.hx_out != 0.0 || n.hy_out != 0.0) {
				int hx = (int)(n.x + n.hx_out + 0.5);
				int hy = (int)(n.y + n.hy_out + 0.5);
				line(n.x, n.y, hx, hy);
				setfillcolor(EGERGB(120, 200, 120));
				fillcircle(hx, hy, 3);
			}
		}
		setlinecolor(EGERGB(0, 0, 0));
	}
	
	for (size_t i = 0; i < g_nodes.size(); ++i)
		draw_node(g_nodes[i].x, g_nodes[i].y, g_nodes[i].smooth);
}

int main()
{
	initgraph(900, 700);
	setbkcolor(EGERGB(250, 250, 250));
	cleardevice();
	setwritemode(R2_COPYPEN);
	setcaption("Bezigon — " BEZIGON_VERSION);
	
	int mouseX = 0, mouseY = 0;
	
	while (true) {
		if (mousemsg()) {
			mouse_msg m = getmouse();
			mouseX = m.x;  mouseY = m.y;
			
			if (m.is_left() && m.is_down()) {
				start_press(m.x, m.y, keystate(VK_SHIFT) != 0);
			}
			else if (m.is_left() && m.is_up()) {
				finish_press(m.x, m.y, keystate(VK_SHIFT) != 0);
			}
			else if (m.is_right() && m.is_down()) {
				if (!g_finished && g_dragKind == DRAG_NONE) {
					g_finished = true;
					g_closed   = false;
				}
			}
			else if (g_dragKind != DRAG_NONE) {
				continue_drag(m.x, m.y);
			}
		}
		
		if (kbmsg()) {
			key_msg k = getkey();
			if (k.msg == key_msg_down) {
				if (k.key == key_esc) {
					g_nodes.clear();
					g_finished           = false;
					g_closed             = false;
					g_closedWithModifier = false;
				}
				else if (k.key == key_enter) {
					if (!g_finished) {
						g_finished = true;
						g_closed   = false;
					}
				}
				else if (k.key == 'D' || k.key == 'd') {
					g_showHandles = !g_showHandles;
				}
			}
		}
		
		redraw(mouseX, mouseY);
		delay_ms(10);
	}
	
	closegraph();
	return 0;
}

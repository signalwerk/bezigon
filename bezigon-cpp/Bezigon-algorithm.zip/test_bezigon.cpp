// test_bezigon.cpp
// Self-contained tests for the Bezigon handle computation.

#include "bezigon.h"
#include <cmath>
#include <iostream>

using bezigon::Node;

static int g_failures = 0;

static void check(bool cond, const char* what, int line)
{
	if (!cond) {
		std::cout << "FAIL (line " << line << "): " << what << "\n";
		++g_failures;
	}
}
#define CHECK(cond) check((cond), #cond, __LINE__)

static bool near(double a, double b, double tol = 0.01)
{
	return std::fabs(a - b) < tol;
}

static Node mk(double x, double y, bool smooth)
{
	Node n;
	n.x = x;  n.y = y;
	n.smooth = smooth;  n.manual = false;
	n.hx_in = n.hy_in = n.hx_out = n.hy_out = 0.0;
	return n;
}

static void test_collinear_cusps()
{
	std::vector<Node> n = {
	mk(100, 100, false),
	mk(200, 100, false),
	mk(300, 100, false)
};
	bezigon::compute_handles(n, false, false);
	
	CHECK(near(n[1].hy_in,  0.0));
	CHECK(near(n[1].hy_out, 0.0));
	CHECK(n[1].hx_in  < 0.0);
	CHECK(n[1].hx_out > 0.0);
}

static void test_collinear_smooth()
{
	std::vector<Node> n = {
	mk(100, 100, false),
	mk(200, 100, true),
	mk(300, 100, false)
};
	bezigon::compute_handles(n, false, false);
	
	CHECK(near(n[1].hy_in,  0.0));
	CHECK(near(n[1].hy_out, 0.0));
	CHECK(near(n[1].hx_in, -n[1].hx_out));
}

static void test_circle_handles()
{
	const double R = 100.0;
	const double cx = 400.0, cy = 400.0;
	std::vector<Node> n = {
		mk(cx,     cy - R, true),
		mk(cx + R, cy,     true),
		mk(cx,     cy + R, true),
		mk(cx - R, cy,     true)
	};
	bezigon::compute_handles(n, true, true);
	
	double chord = std::sqrt(2.0) * R;
	double expected = 0.39 * chord;
	
	for (int i = 0; i < 4; ++i) {
		double lenIn  = std::sqrt(n[i].hx_in  * n[i].hx_in  +
								  n[i].hy_in  * n[i].hy_in);
		double lenOut = std::sqrt(n[i].hx_out * n[i].hx_out +
								  n[i].hy_out * n[i].hy_out);
		CHECK(near(lenIn,  expected, 0.5));
		CHECK(near(lenOut, expected, 0.5));
	}
}

static void test_reflection_at_cusp()
{
	std::vector<Node> n = {
	mk(400, 200, true),
	mk(300, 300, false),
	mk(500, 300, true)
};
	bezigon::compute_handles(n, false, false);
	
	double len = std::sqrt(n[1].hx_in * n[1].hx_in +
						   n[1].hy_in * n[1].hy_in);
	CHECK(len > 1.0);
}

static void test_closing()
{
	std::vector<Node> n = {
	mk(400, 100, false),
	mk(700, 400, false),
	mk(400, 700, false),
	mk(100, 400, true)
};
	bezigon::compute_handles(n, true, false);
	
	double ux = n[1].x - n[0].x;
	double uy = n[1].y - n[0].y;
	double crossIn  = n[0].hx_in  * uy - n[0].hy_in  * ux;
	double crossOut = n[0].hx_out * uy - n[0].hy_out * ux;
	CHECK(near(crossIn,  0.0, 1.0));
	CHECK(near(crossOut, 0.0, 1.0));
}

static void test_manual_smooth_tangent()
{
	// A is a smooth node with manually-set handles pointing
	// horizontally (tangent = (1, 0)).
	// B is a cusp.
	// C is a smooth node, to give B something on the other side.
	//
	// Without the fix, the first pass skipped manual nodes and
	// B fell back to the chord. With the fix, B's in-handle
	// reflects A's manual tangent, giving a direction roughly
	// straight down, not toward A.
	std::vector<Node> n = {
	mk(300, 300, true),
	mk(200, 200, false),
	mk(300, 100, true)
};
	n[0].hx_out =  50.0;
	n[0].hy_out =   0.0;
	n[0].hx_in  = -50.0;
	n[0].hy_in  =   0.0;
	n[0].manual = true;
	
	bezigon::compute_handles(n, false, false);
	
	double chordX = n[0].x - n[1].x;
	double chordY = n[0].y - n[1].y;
	double cross  = n[1].hx_in * chordY - n[1].hy_in * chordX;
	CHECK(std::fabs(cross) > 100.0);
	
	CHECK(near(n[1].hx_in, 0.0, 1.0));
	CHECK(n[1].hy_in < 0.0);
}

int main()
{
	test_collinear_cusps();
	test_collinear_smooth();
	test_circle_handles();
	test_reflection_at_cusp();
	test_closing();
	test_manual_smooth_tangent();
	
	if (g_failures == 0) {
		std::cout << "all tests passed\n";
		return 0;
	}
	std::cout << g_failures << " test(s) failed\n";
	return 1;
}

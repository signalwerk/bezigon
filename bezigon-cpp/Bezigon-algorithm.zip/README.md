# Bezigon handle computation

A small, self-contained C++ implementation of the Bezigon handle rules
used by Macromedia FreeHand. Given a list of path nodes with their
positions and types, it fills in the Bezier control handles needed to
render the path.

**Version:** 1.0.1

## How this package is structured

The package is arranged so that the algorithm can be lifted out and
dropped into any codebase with no dependencies, no setup, and no
platform assumptions. Only two of the five files matter for
integration; the rest are reference material.

| File | Purpose | Required for integration? |
|---|---|---|
| `bezigon.h` | Public interface: data types and function declarations | **Yes** |
| `bezigon.cpp` | The algorithm | **Yes** |
| `main.cpp` | Interactive demo (requires EGE on Windows) | No |
| `test_bezigon.cpp` | Self-contained tests | No |
| `README.md` | This file | No |

### Why the files are split this way

The algorithm and the demo were originally one file. They were split
for three reasons:

1. **The algorithm has no dependencies.** `bezigon.h` and
   `bezigon.cpp` use only `<vector>` and `<cmath>` — no graphics
   library, no windowing, no platform code. `main.cpp`, by contrast,
   needs EGE and Windows to open a window and read mouse input.
   Splitting them means the algorithm can be taken into PhotoLine
   as-is, without dragging any of the demo's dependencies along.

2. **The two files have different audiences.** `main.cpp` is a visual
   reference — useful for comparing the algorithm's output against
   FreeHand. `bezigon.cpp` is the code you actually ship. Keeping
   them apart makes it obvious which is which.

3. **The interactive logic belongs with the algorithm, not the demo.**
   The rule for what happens when a user drags a handle (the opposite
   handle mirrors if the node is smooth) is a rule of Bezigon, not
   a rule of any particular user interface. It lives in
   `bezigon.cpp`, exported as `drag_handle`, so PhotoLine does not
   have to reimplement it.

### What each file contains

- **`bezigon.h`** — The `Node` struct (position, type, handles), the
  `Options` struct (tuning constants), and the declarations of
  `compute_handles` and `drag_handle`. This is the entire public
  surface of the library. Everything else in the package is internal
  to the implementation or belongs to the demo.

- **`bezigon.cpp`** — The implementation of the five rules that
  determine handle positions. About 200 lines. No state of its own;
  all data is passed in and modified in place. Thread-safe as long
  as no two threads operate on the same node list.

- **`main.cpp`** — A runnable demo. Opens a window, listens for mouse
  and keyboard events, calls `compute_handles` at the right moments,
  and draws the resulting shape. Its only purpose is to let a human
  see the algorithm's output and compare it against FreeHand. It is
  not part of the deliverable and can be deleted freely.

- **`test_bezigon.cpp`** — A command-line program that runs automated
  arithmetic checks on the algorithm and prints `all tests passed`
  or a list of failures. See "What the test file is for" below.

- **`README.md`** — This document.

## What the test file is for

`test_bezigon.cpp` exists to **isolate algorithm problems from
integration problems**.

When you first plug the algorithm into PhotoLine and something looks
wrong, the question is: is the algorithm producing bad handles, or is
PhotoLine calling it with bad inputs? Running the tests answers that
immediately. If the tests pass, the algorithm is fine and the problem
is on the integration side — node population, coordinate space,
closing flag, something like that. If the tests fail, the algorithm
itself has regressed.

The tests check arithmetic, not visuals. They verify, for example,
that a circle of four smooth nodes produces handles of exactly the
expected length; that collinear cusps produce horizontal handles;
that Rule 5 fires only when all three of its conditions hold. They
do not open a window or draw anything.

Run the tests after any change to `bezigon.cpp`. They take under a
second to build and under a second to run.

## Interface

    #include "bezigon.h"

    std::vector<bezigon::Node> nodes = ...;  // populate as you like

    bezigon::compute_handles(nodes,
                             /*closed*/             true,
                             /*closedWithModifier*/ false);

After the call, every non-manual node in `nodes` has `hx_in, hy_in,
hx_out, hy_out` filled in.

There is a second exported function, `drag_handle`, for interactive
editing.

## Integration guide

### Step 1 — Decide where your nodes live

The algorithm operates on `std::vector<bezigon::Node>`. You have two
options:

- **Keep your node data as-is** and copy it into a `std::vector<Node>`
  before each call, then copy the handles back afterwards. Simpler if
  your node representation is very different from ours.
- **Store `bezigon::Node` directly** in your path data. Zero copying.
  Cleaner, but requires that your path representation can tolerate
  the two extra fields `smooth` and `manual`.

Either approach works. The `bezigon::Node` struct is deliberately
minimal — six doubles and two booleans — so it can be embedded almost
anywhere.

### Step 2 — Populate the node list

For each node on your path, in order:

    n.x      = position.x;
    n.y      = position.y;
    n.smooth = (this node was placed with the modifier key);
    n.manual = (the user has dragged one of its handles);
    // handle fields can be left uninitialised on first call

For a new path, `manual` is always `false`. It only becomes `true`
when the user drags a handle interactively (see Step 5).

### Step 3 — Call compute_handles

    bezigon::compute_handles(nodes,
                             path.isClosed,
                             path.wasClosedWithModifier);

**When to call it:** after any change that affects the shape's
geometry. That means:

- After adding a node
- After removing a node
- After moving a node
- After the user toggles the closed state
- After the user closes the path

**When NOT to call it:** on every frame. Handle positions are stable
until something about the node list changes. Cache them.

In a typical interactive editor this means: call it once when the user
finishes dragging, not on every mouse-move event. Alternatively, call
it on every mouse-move while dragging — it is cheap (a few
microseconds for a typical path), but not free. Your choice depending
on how the rest of your editor is structured.

### Step 4 — Render the segments

For each pair of consecutive nodes, draw a cubic Bezier:

    P0 = (nodes[i].x,                       nodes[i].y)
    P1 = (nodes[i].x + nodes[i].hx_out,     nodes[i].y + nodes[i].hy_out)
    P2 = (nodes[i+1].x + nodes[i+1].hx_in,  nodes[i+1].y + nodes[i+1].hy_in)
    P3 = (nodes[i+1].x,                     nodes[i+1].y)

If the path is closed, also render the segment from the last node back
to the first.

How you actually draw the Bezier — with your own rasteriser, by
flattening into line segments, by handing it to a GPU — is entirely
your call. The algorithm produces the four control points; rendering
is your existing pipeline's job.

### Step 5 — Interactive handle editing (optional)

When the user grabs a handle and drags it, call:

    bezigon::drag_handle(node, isIn, newX, newY);

where `isIn` is `true` for the in-handle (toward the previous node)
and `false` for the out-handle (toward the next node). `newX, newY` is
the new position of the handle tip.

The function:

- Sets the dragged handle to point at `(newX, newY)`
- If the node is smooth, rotates the opposite handle so the two stay
  collinear, preserving the opposite handle's length
- Marks the node as `manual`, so subsequent calls to
  `compute_handles` will not overwrite this node's handles

### Step 6 — Repaint

After any of the above operations, redraw the shape using the current
handle positions. Nothing else needs to be told — the handles are
just numbers in the node structs.

## A minimal worked example

    #include "bezigon.h"
    #include <vector>

    using bezigon::Node;

    // Three nodes forming an open path: cusp, smooth, cusp.
    std::vector<Node> nodes(3);

    nodes[0] = { 100, 100, false, false, 0, 0, 0, 0 };
    nodes[1] = { 300, 200, true,  false, 0, 0, 0, 0 };
    nodes[2] = { 500, 100, false, false, 0, 0, 0, 0 };

    bezigon::compute_handles(nodes, /*closed*/ false,
                             /*closedWithModifier*/ false);

    // Now nodes[1] has non-zero hx_in, hy_in, hx_out, hy_out.
    // Draw the two Bezier segments (0->1 and 1->2) using the
    // formula from Step 4.

## Node types

A node has two relevant flags:

- `smooth` — `true` for a smooth node (modifier click in FreeHand),
  `false` for a cusp (plain click).
- `manual` — `true` if the user has dragged a handle on this node;
  `compute_handles` will not overwrite manual handles. The node's
  tangent is still reported to adjacent cusps, so they can reflect it.

## The five rules

1. **Smooth node.** Handles lie on the tangent, which is the direction
   from the previous node to the next.
2. **Cusp next to a smooth neighbour.** The handle on that side is the
   reflection of the neighbour's smooth tangent across the chord. This
   is what makes a curved segment trace a proper arc.
3. **Cusp between two cusps (or endpoint).** The handle points straight
   at the neighbour — a straight segment.
4. **Closing a path.** A modifier close forces the start node to a
   cusp; a plain close leaves its type unchanged.
5. **Plain-closed path with cusp start, cusp second node, and smooth
   last node.** The start node's handles become collinear, lying on
   the line from the start to the second node. All three conditions
   are required.

## Tuning

The handle length fraction is set in `bezigon::Options::handleFraction`
and defaults to **0.39**, matching FreeHand's Bezigon tool. It is the
fraction of the local segment length used as the handle length.

## Assumptions

Two of the rules above are **reconstructions** of FreeHand's behaviour,
derived by visual comparison against FreeHand output. They match the
test cases we ran, but they are not based on any published
specification:

- The cusp handle length rule uses the *average* of the two adjacent
  segment lengths as a single common length for both sides. This is
  what produced balanced cusps in our tests, but FreeHand's actual rule
  may differ slightly.
- The reflection rule for cusps adjacent to smooth nodes produces
  circular arcs in the cases we tested. It is mathematically exact for
  a true circular arc, but its behaviour on strongly non-circular
  segments was not verified against FreeHand.

If the integration produces shapes that differ from FreeHand on any
particular configuration, those two rules are the places to look first.

## Handle display

The algorithm produces only handle *positions* — four numbers per node.
It does not draw, hit-test, or manage selection of any kind. All
display and interaction policy is the responsibility of the host
application.

In particular, the demo shows handles only when the user presses D.
This is a demo convenience, not a feature of the algorithm. PhotoLine
should display handles according to its own existing conventions — for
example, showing a node's handles when that node is selected. The
algorithm is unaffected either way.

## Modifier key mapping

The algorithm knows nothing about physical keys. It receives only two
booleans:

- `Node::smooth` — set to `true` by the host when the user places a
  node with the modifier held.
- `closedWithModifier` — set to `true` by the host when the user closes
  a path with the modifier held.

Which physical key maps to those booleans is entirely a host-application
decision. The demo uses Shift, because on Windows the operating system
intercepts Alt before the application sees it. FreeHand used Alt
(Option on Macintosh). PhotoLine should use whichever convention fits
its existing tools — the algorithm will behave identically in all cases.

## Dependencies

The algorithm uses only `<vector>` and `<cmath>`. No graphics library,
no platform code, no I/O.

The demo (`main.cpp`) requires EGE and Windows. It is not required for
integration and can be deleted from the package without affecting the
algorithm.

## Building the tests

With GCC:

    g++ -std=c++11 -O2 bezigon.cpp test_bezigon.cpp -o test_bezigon
    ./test_bezigon

Expected output:

    all tests passed
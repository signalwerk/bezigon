<!--
This file is part of Bezigon, released under the MIT License.
See LICENSE.md for details.
-->

# Bezigon

A small, self-contained C++ library that computes Bezier handles the way
Macromedia FreeHand's Bezigon pen did. You click where you want nodes; given
their positions and types, the library works out every handle needed to draw
the path.

There are two versions, built from the same rules:

| Version | Folder | Node types |
|---|---|---|
| **4.2.0** | `4T/` | Corner, Smooth, Tangent |
| **2.2.0** | `2CS/` | Corner, Smooth |

On any path made only of Corner and Smooth nodes the two produce byte-for-byte
the same handles. Use 4.2.0 if you want Tangent nodes; use 2.2.0 if you don't,
since it is about half the size.

## Node types

| Type | Placed by | Behaviour |
|---|---|---|
| **Corner** | plain click | The path may turn sharply here. Beside a Smooth node it continues that node's curve; otherwise it draws straight. |
| **Smooth** | modifier click | The path flows through on a curve: the tangent of the circle through the node and its two neighbours. |
| **Tangent** (4.2.0) | modifier click | FreeHand's "connector point". Each handle continues the chord on the other side, so a straight edge joins a curve without a kink. Only the handle's length is free. |

A **cusp** is a state, not a fourth type: a Corner converted from a curved
node. Its handles lie along the chords to its neighbours and move
independently. Any node toggles between smooth and the same cusp.

FreeHand draws a cusp this way too: convert a corner to smooth and back, and
its handles lie on the chords to its neighbours, as in the FreeHand
screenshots. Xara does the same.

Every handle is 0.39 of its own segment, FreeHand's value: the fraction that
makes four Smooth nodes on a square draw a near-perfect circle.

Every sharp node carries handles lying flat along its chords. They change
nothing about the drawn shape, but they let you reshape any node without
converting it first.

## Package layout

Only `bezigon.h` and `bezigon.cpp` are needed to integrate either version.

```
Bezigon 4.2.0/          version 4.2.0
  bezigon.h             public interface
  bezigon.cpp           the rules (about 500 lines)
  main.cpp              interactive demo (EGE, Windows)
  demo_scenes.h         seven example paths for the demo and the tests
  test_bezigon.cpp      test program
  Bezigon - Permutations - Corner, Smooth and Cusp.docx
  Bezigon - Permutations - Tangent.docx
Bezigon 2.2.0/          version 2.2.0
  bezigon.h             public interface
  bezigon.cpp           the rules (about 280 lines)
  main.cpp              interactive demo (EGE, Windows)
  test_bezigon.cpp      test program
  Bezigon - Permutations - Corner, Smooth and Cusp.docx
Technical Documentation/
  all four Word documents and this README
```

The library depends only on `<vector>` and `<cmath>`, needs C++11 or later,
and has no global state, no I/O and no exceptions. It has been built and tested
with g++ and clang under C++11 and C++20; it has not yet been built with MSVC.

## Quick start

```cpp
#include "bezigon.h"

bezigon::Path path;

// After each click:
path.nodes.push_back(bezigon::make_node(x, y, bezigon::NodeType::Smooth));
bezigon::compute_handles(path);

// A click on the start node closes the path. Two nodes are enough.
if (bezigon::close_path(path, withModifier))
    bezigon::compute_handles(path);

// The user changes a node's type, or drags a handle tip.
// Both recompute for you.
bezigon::set_node_type(path, i, bezigon::NodeType::Corner);
bezigon::drag_handle(path, i, isIn, x, y);
```

In 2.2.0 the type is a `bool smooth`: `make_node(x, y, smooth)` and
`set_node_smooth(path, i, smooth)`. Everything else is the same.

## Interface

All in `namespace bezigon`.

| Function | 4.2.0 | 2.2.0 | Purpose |
|---|---|---|---|
| `make_node(x, y, type)` | yes | `bool smooth` | Create a node as a click would. |
| `close_path(path, withModifier)` | yes | yes | Close the path. Returns `false`, changing nothing, if there are fewer than two nodes. A modifier close turns the start node into a Corner (a cusp, if it was curved). |
| `compute_handles(path, opts)` | yes | yes | Recompute every handle that is not manual. |
| `set_node_type(path, i, type)` | yes | `set_node_smooth(path, i, smooth)` | Change a node's type. Use this rather than assigning the field: it also decides what happens to the handles. |
| `drag_handle(path, i, isIn, x, y)` | yes | yes | Move one handle tip and update whatever depends on it. |
| `segment_is_straight(path, i)` | yes | no | True if the segment from node `i` draws as a straight line. Use it when exporting. |
| `handle_axis(path, i, isIn, ax, ay)` | yes | no | The direction a Tangent's handle may be pulled along. |

`Path` holds a public `std::vector<Node> nodes`. Its close state is read with
`path.close()` and can only be set by `close_path`, so the start node and the
close state can never disagree.

### When to call `compute_handles`

After any change to the node list: a node added, moved, inserted or deleted,
or a manual flag cleared; and after `close_path`. `set_node_type` and
`drag_handle` call it for you. It is cheap: about 40 microseconds for 1,000
nodes, so calling it on every mouse move is fine.

### Drawing

For each pair of consecutive nodes, draw a cubic Bezier:

```
P0 = (n[i].x,                n[i].y)
P1 = (n[i].x   + n[i].hx_out, n[i].y   + n[i].hy_out)
P2 = (n[i+1].x + n[i+1].hx_in, n[i+1].y + n[i+1].hy_in)
P3 = (n[i+1].x,              n[i+1].y)
```

If the path is closed, also draw the segment from the last node back to the
first. A closed path of two nodes therefore has two segments.

When exporting, write a segment for which `segment_is_straight` is true as a
line rather than a curve, so a polygon stays recognisable as one.

## Coordinates and keys

Any units, any origin, y-up or y-down: handles are fractions of their own
segments, so the results scale with the drawing, and mirroring the drawing
mirrors the output exactly.

The library knows nothing about keys. It receives a node type and a boolean
for the modifier. Which physical keys map to them is the host's decision. The
demos use Shift for the modifier and Ctrl for Tangent, because Windows
intercepts Alt; FreeHand used Alt (Option on the Macintosh).

## The demos

Both demos need the EGE graphics library on Windows. Build `main.cpp` with
`bezigon.cpp` against EGE.

| Action | 4.2.0 | 2.2.0 |
|---|---|---|
| Corner / Smooth node | click / Shift + click | click / Shift + click |
| Tangent node | Ctrl + click | - |
| Close the path | click the start node (Shift for a modifier close) | same |
| Close by dragging | drag the end node onto the start node; it snaps there, and releasing closes the path (Shift held at release for a modifier close) | same |
| Change the node under the cursor | C / S / T | C / S |
| Pull a Tangent's handle | Ctrl + drag from the Tangent | - |
| Show / hide handles | D | D |
| Release dragged handles | R | R |
| Example paths | 1 to 7 | - |
| Finish an open path / clear | Enter or right-click / Esc | same |

## Tests

Each test program needs only its own folder's `bezigon.h` and `bezigon.cpp`
(and `demo_scenes.h` for 4.2.0). It opens no window.

```
cd "Bezigon 4.2.0"
g++ -std=c++11 -O2 -Wall -Wextra test_bezigon.cpp bezigon.cpp -o test_bezigon
./test_bezigon
```

and the same in `Bezigon 2.2.0`. Expected last lines, with g++:

```
4.2.0:  2150377 checks, 0 failed
2.2.0:  1010577 checks, 0 failed
```

clang reports slightly more checks (2152112 and 1011140), because it evaluates
function arguments in a different order and so builds different random paths
from the same seed. `--runs 200` shortens the random tests and `--seed 7`
changes them. The program returns 0 on success and 1 on failure.

Run the tests after any change to `bezigon.cpp`, and once with your own
compiler and flags.

## Testing the demos

The demos need the EGE graphics library on Windows. Build `main.cpp` with
`bezigon.cpp` against EGE, as you would any EGE program. Then work through the
checks below in both versions. Where a check says 4.2.0 only, skip it in 2.2.0.

Start a demo, then:

1. **Corners.** Plain-click four points in a zig-zag. Each segment should be a
   straight line.
2. **Smooth.** Shift-click four points. The path should curve through each one.
3. **Plain close.** Click the start node with no modifier. The path closes;
   the join at the start is an ordinary corner.
4. **Modifier close.** Repeat with Shift held on the start-node click. The start
   node becomes a cusp: its handles lie along the chords, so it points.
5. **Two-node loops.** Place two Smooth nodes, then close plainly. The result
   is an oval. Repeat with a modifier close: a teardrop.
6. **Drag to close.** Place an open path, drag the end node onto the start node.
   It snaps onto the start node while you drag, and releasing closes the path.
   Repeat, but hold Shift when you release: the close is a modifier close.
7. **Changing a node.** Press C, S (and T in 4.2.0) over a node. Convert a
   Smooth node to a Corner and back. The second conversion should leave it as a
   cusp, with its handles on the chords.
8. **Handles.** Press D to hide and show handles. Drag a handle tip, then press R:
   the dragged handle is released and the node returns to its computed handles.
9. **Example paths.** Press 1 to 7. Each example should close as its name says.
   Example 6 (the teardrop), closed with a modifier, should show a cusp at its
   start node.
10. **Tangent (4.2.0 only).** Ctrl-click to place a Tangent. Its handles
    continue the chords to its neighbours. Ctrl-drag the Tangent to pull a
    handle along its axis. A neighbouring Corner must not follow the pulled
    handle.
11. **Finishing.** Enter or right-click finishes an open path. Esc clears the
    canvas.

Any check that fails is a bug in the demo or the library. Note which version,
which step and which node types were involved.

## Changes since 4.1.0 and 2.1.1

- **Two nodes can be closed.** A plain close of two Smooth nodes draws an
  oval; a modifier close draws a teardrop.
- **Coincident nodes:** outside a two-node loop, two nodes on one point simply
  coexist, and nothing special happens.
- **Cusps:** any curved node converted to a Corner becomes a cusp, however it
  was drawn.
- **A Corner beside a Tangent** (4.2.0) no longer follows a handle pulled out
  of the Tangent.
- **API:** the close state is read with `close()` and set only by
  `close_path`; the `born_curved` and `was_smooth` fields are replaced by
  `cusp`. 2.2.0 gains `make_node`, `set_node_smooth`, a `bool` result from
  `close_path`, a path-level `drag_handle` that recomputes, and tolerances
  that scale with the drawing.
- **Demos:** releasing the end node on the start node closes the path.

Every Tangent configuration that 4.1.0 could build is unchanged except the
pulled-handle case. The *Technical Reference* has the upgrade details.

## Documents

| Document | Contents |
|---|---|
All four are in `Technical Documentation/`. The two permutation tables are also
copied into the version folders that they describe.

| Document | Contents |
|---|---|
| `Bezigon - Technical Reference.docx` | API for both versions, the rules, detailed PhotoLine integration guidance, degenerate input, verification |
| `Bezigon - History and Derivation.docx` | How each rule was arrived at and on what evidence, the derivations, the FreeHand and Xara comparisons, and where FreeHand was overridden |
| `Bezigon - Permutations - Corner, Smooth and Cusp.docx` | Every click and close combination for four-, three- and two-node paths, polygons, out-and-back paths and edit sequences, with pictures (both versions) |
| `Bezigon - Permutations - Tangent.docx` | Every neighbour configuration around a Tangent node, open and closed, two-node loops and edit sequences, with pictures (4.2.0) |

## Licence

MIT. See `LICENSE.md`.

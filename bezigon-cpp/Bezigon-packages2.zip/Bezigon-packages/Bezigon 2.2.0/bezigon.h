// This file is part of Bezigon, released under the MIT License.
// See LICENSE for details.
//
// Diese Datei ist Teil von Bezigon und steht unter der MIT-Lizenz.
// Siehe LICENSE für Einzelheiten.

// bezigon.h
// Bezigon handle computation. Depends only on the C++ standard library.
//
// A path is a list of nodes. Every node has two Bezier handles: an
// in-handle (toward the previous node) and an out-handle (toward the
// next node). Neighbouring nodes share a cubic Bezier segment:
//
//     segment i -> i+1  =  node[i], node[i] + out, node[i+1] + in, node[i+1]
//
// Typical use:
//
//     bezigon::Path path;
//     path.nodes.push_back(bezigon::make_node(x, y, smooth));  // after each click
//     bezigon::compute_handles(path);            // after ANY change to the nodes
//
//     bezigon::close_path(path, withModifier);   // click on the start node
//     bezigon::compute_handles(path);
//
//     bezigon::set_node_smooth(path, i, smooth); // change a node's type
//     bezigon::drag_handle(path, i, isIn, x, y); // user drags a handle tip

#pragma once
#include <vector>

#define BEZIGON_VERSION "2.2.0"

namespace bezigon {

// A path node.
//
//   x, y            position
//   hx_in, hy_in    offset from the node to its incoming control point
//   hx_out, hy_out  offset from the node to its outgoing control point
//                   (0, 0) means "no handle": only a side with no neighbour
//                   has none.
//
//   smooth          true for a curve node (modifier click),
//                   false for a corner node (plain click)
//
//   cusp            corner nodes only: true if the corner came from converting
//                   a smooth node (see set_node_smooth, close_path). A cusp's
//                   handles lie along its chords; a plain corner continues
//                   its smooth neighbours' arcs.
//
//   manual_in, manual_out
//                   true once the user has dragged that handle;
//                   compute_handles never overwrites it.
struct Node
{
    double x = 0.0, y = 0.0;
    bool   smooth      = false;
    bool   cusp        = false;
    bool   manual_in   = false;
    bool   manual_out  = false;
    double hx_in  = 0.0, hy_in  = 0.0;
    double hx_out = 0.0, hy_out = 0.0;
};

// A new node, as created by a click: smooth for a modifier click.
inline Node make_node(double x, double y, bool smooth)
{
    Node n;
    n.x = x;  n.y = y;
    n.smooth = smooth;
    return n;
}

// How a path was closed.
enum class Close
{
    Open,      // path is not closed
    Plain,     // closed with a plain click
    Modifier   // closed with a modifier click
};

// A path: its nodes in order, and how it is closed.
//
// The close state is read with close() and set only by close_path. A modifier
// close also turns the start node into a corner, and doing both in one call
// means the start node and the close state can never disagree. To reopen a
// path, copy its nodes into a new Path.
class Path
{
public:
    std::vector<Node> nodes;

    Close close() const { return close_; }

private:
    Close close_ = Close::Open;
    friend bool close_path(Path& path, bool withModifier);
};

struct Options
{
    // Handle length as a fraction of the segment it belongs to.
    double handleFraction = 0.39;
};

// Close the path. Returns false, and changes nothing, if there are fewer
// than two nodes. Closing with the modifier also turns the start node into
// a corner (a cusp, if it was smooth). Call compute_handles afterwards.
//
// Two nodes close into a loop of two segments. Each node then has the other
// on both sides, and a smooth node points square to the chord, so a plain
// close of two smooth nodes draws an ellipse. A modifier close makes the
// start node a cusp, which lies along the chord instead.
bool close_path(Path& path, bool withModifier);

// Change a node's type and recompute. Use this rather than assigning
// Node::smooth, because it also decides what happens to the handles:
//   to smooth   the handles are reset to the automatic ones.
//   to corner   the node becomes a cusp, however it was drawn: its handles
//               lie along the chords to its neighbours.
// So any node toggles between smooth and the same cusp every time. A plain
// (arc-following) corner comes only from a plain click. A type equal to the
// current one is ignored, and so are out-of-range indices.
void set_node_smooth(Path& path, int index, bool smooth,
                     const Options& opts = Options());

// Recompute every handle that is not manual. Call after any change to a
// node position or a node type, and after close_path.
void compute_handles(Path& path, const Options& opts = Options());

// Move one handle tip to (x, y), mark it manual, and recompute, so the
// neighbours that depend on it follow at once. On a smooth node the opposite
// handle is turned to stay collinear (length kept) and is marked manual too,
// unless it has zero length. Out-of-range indices are ignored.
void drag_handle(Path& path, int index, bool isIn, double x, double y,
                 const Options& opts = Options());

}   // namespace bezigon

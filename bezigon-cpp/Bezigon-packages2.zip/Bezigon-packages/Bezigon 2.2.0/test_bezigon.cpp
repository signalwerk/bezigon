// This file is part of Bezigon, released under the MIT License.
// See LICENSE for details.
//
// Diese Datei ist Teil von Bezigon und steht unter der MIT-Lizenz.
// Siehe LICENSE für Einzelheiten.

// test_bezigon.cpp
// Tests for the 2.2.0 build of the Bezigon handle computation.
// Needs only the C++ standard library.
//
//   g++ -std=c++11 -O2 -Wall -Wextra test_bezigon.cpp bezigon.cpp -o test_bezigon
//   ./test_bezigon                 run everything
//   ./test_bezigon --runs 100000   more random paths (default 20000)
//   ./test_bezigon --seed 7        different random paths (default 1)
//
// Prints "ok" or "FAIL" per test, then a summary line. Exit code 0 if
// every check passed.

#include "bezigon.h"

#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <vector>

using namespace bezigon;

namespace {

const double K   = 0.39;
const double EPS = 1e-9;
const double PI  = 3.14159265358979323846;

int         g_checks   = 0;
int         g_failures = 0;
const char* g_test     = "";

void report(bool ok, const char* what, int line)
{
    ++g_checks;
    if (ok) return;
    ++g_failures;
    if (g_failures <= 40)
        std::printf("  FAIL [%s] line %d: %s\n", g_test, line, what);
}

#define CHECK(cond)           report((cond), #cond, __LINE__)
#define CHECK_NEAR(a, b, tol) report(std::fabs((a) - (b)) <= (tol), \
                                     #a " ~ " #b, __LINE__)

double len_in(const Node& n)  { return std::hypot(n.hx_in,  n.hy_in);  }
double len_out(const Node& n) { return std::hypot(n.hx_out, n.hy_out); }
bool   has_in(const Node& n)  { return len_in(n)  > EPS; }
bool   has_out(const Node& n) { return len_out(n) > EPS; }

double dist(const Path& p, int i, int j)
{
    return std::hypot(p.nodes[j].x - p.nodes[i].x,
                      p.nodes[j].y - p.nodes[i].y);
}

double cosine(double ax, double ay, double bx, double by)
{
    const double la = std::hypot(ax, ay), lb = std::hypot(bx, by);
    return (la < EPS || lb < EPS) ? 0.0 : (ax * bx + ay * by) / (la * lb);
}

bool all_finite(const Path& p)
{
    for (size_t i = 0; i < p.nodes.size(); ++i) {
        const Node& n = p.nodes[i];
        if (!std::isfinite(n.hx_in)  || !std::isfinite(n.hy_in)  ||
            !std::isfinite(n.hx_out) || !std::isfinite(n.hy_out)) return false;
    }
    return true;
}

bool same_handles(const Path& a, const Path& b, double tol)
{
    if (a.nodes.size() != b.nodes.size()) return false;
    for (size_t i = 0; i < a.nodes.size(); ++i) {
        const Node& p = a.nodes[i];
        const Node& q = b.nodes[i];
        if (std::fabs(p.hx_in  - q.hx_in)  > tol ||
            std::fabs(p.hy_in  - q.hy_in)  > tol ||
            std::fabs(p.hx_out - q.hx_out) > tol ||
            std::fabs(p.hy_out - q.hy_out) > tol) return false;
    }
    return true;
}

bool points_at(const Path& p, int from, int to, double hx, double hy)
{
    return cosine(hx, hy,
                  p.nodes[to].x - p.nodes[from].x,
                  p.nodes[to].y - p.nodes[from].y) > 1.0 - 1e-9;
}

bool flat(const Path& p, int i, int j, bool isIn)
{
    const Node& n = p.nodes[i];
    const double hx = isIn ? n.hx_in  : n.hx_out;
    const double hy = isIn ? n.hy_in  : n.hy_out;
    return std::fabs(hx - K * (p.nodes[j].x - n.x)) < 1e-9
        && std::fabs(hy - K * (p.nodes[j].y - n.y)) < 1e-9;
}

struct Pt { double x, y; bool smooth; };

Path make_path(const std::vector<Pt>& pts, Close close = Close::Open)
{
    Path p;
    for (size_t i = 0; i < pts.size(); ++i)
        p.nodes.push_back(make_node(pts[i].x, pts[i].y, pts[i].smooth));
    if (close != Close::Open) close_path(p, close == Close::Modifier);
    compute_handles(p);
    return p;
}

// ------------------------------------------------------- hand-worked cases

void test_empty_path()
{
    Path p;
    compute_handles(p);
    CHECK(p.nodes.empty());
}

void test_single_node_has_no_handles()
{
    Path p = make_path({{5, 5, true}});
    CHECK(!has_in(p.nodes[0]) && !has_out(p.nodes[0]));
}

void test_two_nodes_have_handles_to_each_other()
{
    Path p = make_path({{0, 0, true}, {100, 0, true}});
    CHECK(has_out(p.nodes[0]) && has_in(p.nodes[1]));
    CHECK(!has_in(p.nodes[0]) && !has_out(p.nodes[1]));
    CHECK_NEAR(len_out(p.nodes[0]), K * 100, 1e-9);
    CHECK_NEAR(len_in(p.nodes[1]),  K * 100, 1e-9);
    CHECK(points_at(p, 0, 1, p.nodes[0].hx_out, p.nodes[0].hy_out));
    CHECK(points_at(p, 1, 0, p.nodes[1].hx_in,  p.nodes[1].hy_in));
}

void test_handle_length_is_k_times_own_segment()
{
    Path p = make_path({{0,0,false},{100,0,true},{600,80,true},{700,0,false}});
    CHECK_NEAR(len_in(p.nodes[1]),  K * dist(p, 1, 0), 1e-9);
    CHECK_NEAR(len_out(p.nodes[1]), K * dist(p, 1, 2), 1e-9);
    CHECK_NEAR(len_in(p.nodes[2]),  K * dist(p, 2, 1), 1e-9);
    CHECK_NEAR(len_out(p.nodes[2]), K * dist(p, 2, 3), 1e-9);
}

void test_handle_fraction_option()
{
    Path p = make_path({{0,0,true},{100,0,true},{100,100,true}});
    Options o;  o.handleFraction = 0.25;
    compute_handles(p, o);
    CHECK_NEAR(len_out(p.nodes[0]), 25.0, 1e-9);
    CHECK_NEAR(len_in(p.nodes[2]),  25.0, 1e-9);
}

void test_smooth_collinear_three_points()
{
    Path p = make_path({{100,100,false},{200,100,true},{300,100,false}});
    CHECK_NEAR(p.nodes[1].hy_in,  0.0, 1e-9);
    CHECK_NEAR(p.nodes[1].hy_out, 0.0, 1e-9);
    CHECK(p.nodes[1].hx_in < 0 && p.nodes[1].hx_out > 0);
    CHECK_NEAR(cosine(p.nodes[1].hx_in, p.nodes[1].hy_in,
                      p.nodes[1].hx_out, p.nodes[1].hy_out), -1.0, 1e-9);
}

void test_smooth_eight_on_a_circle()
{
    std::vector<Pt> pts;
    for (int i = 0; i < 8; ++i)
        pts.push_back({ 300 + 200 * std::cos(i * PI / 4),
                        300 + 200 * std::sin(i * PI / 4), true });
    Path p = make_path(pts, Close::Plain);
    for (int i = 0; i < 8; ++i) {
        const Node& n = p.nodes[i];
        const double rx = n.x - 300, ry = n.y - 300;
        CHECK_NEAR(cosine(n.hx_in,  n.hy_in,  rx, ry), 0.0, 1e-9);
        CHECK_NEAR(cosine(n.hx_out, n.hy_out, rx, ry), 0.0, 1e-9);
        CHECK_NEAR(cosine(n.hx_in, n.hy_in, n.hx_out, n.hy_out), -1.0, 1e-9);
        CHECK_NEAR(len_out(n), K * dist(p, i, (i + 1) % 8), 1e-9);
        CHECK_NEAR(len_in(n),  K * dist(p, i, (i + 7) % 8), 1e-9);
    }
}

void test_smooth_unequal_segments()
{
    const double R = 100;
    Path p = make_path({
        { R * std::cos(0),            R * std::sin(0),            false },
        { R * std::cos(PI / 2),       R * std::sin(PI / 2),       true  },
        { R * std::cos(150 * PI/180), R * std::sin(150 * PI/180), false },
    });
    CHECK_NEAR(p.nodes[1].hy_in,  0.0, 1e-6);
    CHECK_NEAR(p.nodes[1].hy_out, 0.0, 1e-6);
}

void test_smooth_endpoints_point_at_their_neighbour()
{
    Path p = make_path({{0,0,true},{100,0,true},{200,0,true}});
    CHECK(!has_in(p.nodes[0]));
    CHECK(has_out(p.nodes[0]));
    CHECK(points_at(p, 0, 1, p.nodes[0].hx_out, p.nodes[0].hy_out));
    CHECK_NEAR(len_out(p.nodes[0]), K * dist(p, 0, 1), 1e-9);
    CHECK(has_in(p.nodes[2]));
    CHECK(!has_out(p.nodes[2]));
    CHECK(points_at(p, 2, 1, p.nodes[2].hx_in, p.nodes[2].hy_in));
    CHECK_NEAR(len_in(p.nodes[2]), K * dist(p, 2, 1), 1e-9);
}

void test_corner_between_corners_is_a_straight_line()
{
    Path p = make_path({{0,0,false},{100,0,false},{200,0,false}});
    CHECK(flat(p, 1, 0, true));
    CHECK(flat(p, 1, 2, false));
}

void test_corner_between_smooth_neighbours()
{
    Path p = make_path({{0,300,true},{300,100,false},{600,300,true}});
    const Node& c = p.nodes[1];
    CHECK(has_in(c) && has_out(c));
    CHECK(cosine(c.hx_in, c.hy_in, c.hx_out, c.hy_out) > -0.99);
    CHECK(len_in(c) > 1.0 && len_out(c) > 1.0);
}

void test_corner_between_smooth_and_corner()
{
    Path p = make_path({{0,50,true},{100,0,false},{200,0,false}});
    CHECK(has_in(p.nodes[1]));
    CHECK(flat(p, 1, 2, false));
}

void test_corner_reflection_is_symmetric()
{
    Path p = make_path({{0,100,false},{100,0,true},{200,100,false},{100,200,false}});
    const Node& a = p.nodes[0];
    const Node& b = p.nodes[1];
    const double cx = b.x - a.x, cy = b.y - a.y;
    const double cl = std::hypot(cx, cy);
    const double cross_a = a.hx_out * cy - a.hy_out * cx;
    const double cross_b = b.hx_in  * cy - b.hy_in  * cx;
    CHECK_NEAR(std::fabs(cross_a) / cl, std::fabs(cross_b) / cl, 1e-6);
}

// --------------------------------------------------------------- closing

void test_plain_close_preserves_start_type()
{
    const std::vector<Pt> pts = {
        {0,0,true},{100,0,false},{100,100,true},{0,100,false}
    };
    Path p = make_path(pts, Close::Plain);
    CHECK(p.nodes[0].smooth);
    CHECK(!p.nodes[0].cusp);
    CHECK(p.close() == Close::Plain);
    CHECK_NEAR(cosine(p.nodes[0].hx_in, p.nodes[0].hy_in,
                      p.nodes[0].hx_out, p.nodes[0].hy_out), -1.0, 1e-9);
}

void test_modifier_close_converts_smooth_start_to_corner()
{
    const std::vector<Pt> pts = {
        {0,0,true},{100,0,false},{100,100,false},{0,100,false}
    };
    Path p = make_path(pts, Close::Modifier);
    CHECK(!p.nodes[0].smooth);
    CHECK(p.nodes[0].cusp);
    CHECK(p.close() == Close::Modifier);
}

void test_modifier_close_start_handles_point_at_neighbours()
{
    const std::vector<Pt> pts = {
        {0,0,true},{100,0,true},{100,100,true},{0,100,true}
    };
    Path p = make_path(pts, Close::Modifier);
    CHECK(points_at(p, 0, 1, p.nodes[0].hx_out, p.nodes[0].hy_out));
    CHECK(points_at(p, 0, 3, p.nodes[0].hx_in,  p.nodes[0].hy_in));
    CHECK_NEAR(len_out(p.nodes[0]), K * dist(p, 0, 1), 1e-9);
    CHECK_NEAR(len_in(p.nodes[0]),  K * dist(p, 0, 3), 1e-9);
}

void test_modifier_close_corner_start_reflects_out()
{
    Path p = make_path({{0,0,false},{100,-40,true},{200,40,true},{100,150,true}},
                       Close::Modifier);
    CHECK(has_out(p.nodes[0]));
    CHECK(!points_at(p, 0, 1, p.nodes[0].hx_out, p.nodes[0].hy_out));
}

void test_close_path_requires_two_nodes()
{
    Path p;
    p.nodes.push_back(make_node(0, 0, true));
    CHECK(!close_path(p, true));
    CHECK(p.close() == Close::Open);
    CHECK(p.nodes[0].smooth);                          // nothing changed
    p.nodes.push_back(make_node(100, 0, true));
    CHECK(close_path(p, false));
    CHECK(p.close() == Close::Plain);
}

// The close state can only be set by close_path (Path::close_ is private), so
// a host can no longer mark a path modifier-closed while its start node is
// still smooth. That is a compile-time guarantee; this checks the outcome.
void test_close_state_and_start_node_agree()
{
    Path p = make_path({{0,0,true},{100,0,true},{100,100,true}});
    CHECK(p.close() == Close::Open);
    CHECK(close_path(p, true));
    CHECK(p.close() == Close::Modifier);
    CHECK(!p.nodes[0].smooth);
}

// ------------------------------------------------ two-node loops (2.2.0)

void test_two_node_loop_plain_close_is_an_ellipse()
{
    const Path p = make_path({{0,0,true},{0,200,true}}, Close::Plain);
    const Node& a = p.nodes[0];
    const Node& b = p.nodes[1];
    for (int i = 0; i < 2; ++i) {
        const Node& n = p.nodes[i];
        CHECK_NEAR(n.hy_in,  0.0, 1e-9);                    // square to the chord
        CHECK_NEAR(n.hy_out, 0.0, 1e-9);
        CHECK_NEAR(len_in(n),  K * 200, 1e-9);
        CHECK_NEAR(len_out(n), K * 200, 1e-9);
        CHECK(cosine(n.hx_in, n.hy_in, n.hx_out, n.hy_out) < -0.999999);
    }
    CHECK(a.hx_out * b.hx_in > 0);                          // segment 0 -> 1, one side
    CHECK(b.hx_out * a.hx_in > 0);                          // segment 1 -> 0, the other
    CHECK(a.hx_out * b.hx_out < 0);
}

void test_two_node_loop_modifier_close_makes_a_cusp()
{
    const Path p = make_path({{0,0,true},{0,200,true}}, Close::Modifier);
    const Node& a = p.nodes[0];
    const Node& b = p.nodes[1];
    CHECK(!a.smooth && a.cusp);
    CHECK(points_at(p, 0, 1, a.hx_in,  a.hy_in));
    CHECK(points_at(p, 0, 1, a.hx_out, a.hy_out));
    CHECK_NEAR(b.hy_in,  0.0, 1e-9);
    CHECK_NEAR(b.hy_out, 0.0, 1e-9);
    CHECK(std::fabs(b.hx_in) > 1.0);
}

void test_two_node_loop_of_corners_is_flat()
{
    const Path p = make_path({{0,0,false},{0,200,false}}, Close::Plain);
    CHECK(flat(p, 0, 1, true)  && flat(p, 0, 1, false));
    CHECK(flat(p, 1, 0, true)  && flat(p, 1, 0, false));
}

void test_two_node_loop_toggles()
{
    const Path closed = make_path({{0,0,true},{0,200,true}}, Close::Modifier);
    Path p = closed;
    set_node_smooth(p, 0, true);
    const Path ellipse = make_path({{0,0,true},{0,200,true}}, Close::Plain);
    CHECK(same_handles(p, ellipse, 1e-9));
    set_node_smooth(p, 0, false);
    CHECK(same_handles(p, closed, 1e-12));
    CHECK(p.close() == Close::Modifier);
}

// Two separate nodes on one point, anywhere other than a two-node loop:
// nothing special happens, the handles point straight at the shared point.
void test_coincidence_in_a_larger_loop_stays_plain()
{
    const Path p = make_path({{0,0,false},{100,0,false},{100,200,true},{100,0,false}},
                             Close::Plain);
    CHECK(all_finite(p));
    CHECK(points_at(p, 2, 1, p.nodes[2].hx_in,  p.nodes[2].hy_in));
    CHECK(points_at(p, 2, 3, p.nodes[2].hx_out, p.nodes[2].hy_out));
}

// ------------------------------------------------------ toggling (2.2.0)

void test_make_node()
{
    const Node s = make_node(1, 2, true);
    const Node c = make_node(1, 2, false);
    CHECK(s.smooth && !s.cusp);
    CHECK(!c.smooth && !c.cusp);
    CHECK(s.x == 1 && s.y == 2);
}

// A node drawn sharp continues its smooth neighbours' arcs. Made smooth and
// then a corner again, it is a cusp, not the corner it was drawn as.
void test_toggle_sharp_node_becomes_cusp()
{
    const Path orig = make_path({{0,300,true},{300,100,false},{600,300,true},{300,500,false}},
                                Close::Plain);
    CHECK(!points_at(orig, 1, 0, orig.nodes[1].hx_in, orig.nodes[1].hy_in));
    Path p = orig;
    set_node_smooth(p, 1, true);
    CHECK(p.nodes[1].smooth && !p.nodes[1].cusp);
    CHECK_NEAR(cosine(p.nodes[1].hx_in, p.nodes[1].hy_in,
                      p.nodes[1].hx_out, p.nodes[1].hy_out), -1.0, 1e-9);
    set_node_smooth(p, 1, false);
    CHECK(!p.nodes[1].smooth && p.nodes[1].cusp);
    CHECK(points_at(p, 1, 0, p.nodes[1].hx_in,  p.nodes[1].hy_in));
    CHECK(points_at(p, 1, 2, p.nodes[1].hx_out, p.nodes[1].hy_out));
}

// In a two-node loop a drawn corner beside a smooth node continues its arc,
// which is the ellipse. Made smooth and then a corner, it is a cusp that lies
// along the chord.
void test_two_node_loop_corner_toggles_to_cusp()
{
    const Path orig = make_path({{0,0,false},{0,200,true}}, Close::Plain);
    const Path ellipse = make_path({{0,0,true},{0,200,true}}, Close::Plain);
    CHECK(same_handles(orig, ellipse, 1e-9));
    Path p = orig;
    set_node_smooth(p, 0, true);
    CHECK(same_handles(p, ellipse, 1e-9));
    set_node_smooth(p, 0, false);
    CHECK(points_at(p, 0, 1, p.nodes[0].hx_in,  p.nodes[0].hy_in));
    CHECK(points_at(p, 0, 1, p.nodes[0].hx_out, p.nodes[0].hy_out));
    const Path modifier = make_path({{0,0,true},{0,200,true}}, Close::Modifier);
    CHECK(same_handles(p, modifier, 1e-12));
}

// A node drawn smooth turned into a corner is a cusp: its handles point
// straight at its neighbours even though they are smooth, and it returns to
// the same cusp every time.
void test_toggle_curved_node_becomes_cusp()
{
    const Path orig = make_path({{0,300,true},{300,100,true},{600,300,true},{300,500,true}},
                                Close::Plain);
    Path p = orig;
    set_node_smooth(p, 1, false);
    CHECK(points_at(p, 1, 0, p.nodes[1].hx_in,  p.nodes[1].hy_in));
    CHECK(points_at(p, 1, 2, p.nodes[1].hx_out, p.nodes[1].hy_out));
    const Path cusp = p;
    set_node_smooth(p, 1, true);
    CHECK(same_handles(p, orig, 1e-12));
    set_node_smooth(p, 1, false);
    CHECK(same_handles(p, cusp, 1e-12));
}

void test_toggle_releases_dragged_handles()
{
    const Path orig = make_path({{0,0,false},{100,0,true},{200,80,false}});
    Path p = orig;
    drag_handle(p, 1, false, 150, 60);
    CHECK(p.nodes[1].manual_out && p.nodes[1].manual_in);
    set_node_smooth(p, 1, false);
    CHECK(!p.nodes[1].manual_in && !p.nodes[1].manual_out);
    set_node_smooth(p, 1, true);
    CHECK(same_handles(p, orig, 1e-12));
}

void test_toggle_ignores_same_type_and_bad_index()
{
    Path p = make_path({{0,0,false},{100,0,true},{200,80,false}});
    drag_handle(p, 1, false, 150, 60);
    const Path before = p;
    set_node_smooth(p, 1, true);                        // already smooth
    set_node_smooth(p, -1, false);
    set_node_smooth(p, 3, false);
    CHECK(same_handles(p, before, 0.0));
    CHECK(p.nodes[1].manual_out);
}

// A modifier-closed start node can be made smooth again, and turned back
// into the same closed shape.
void test_modifier_closed_start_toggles()
{
    const Path closed = make_path({{0,0,true},{100,0,true},{100,100,true},{0,100,true}},
                                  Close::Modifier);
    Path p = closed;
    set_node_smooth(p, 0, true);
    CHECK_NEAR(cosine(p.nodes[0].hx_in, p.nodes[0].hy_in,
                      p.nodes[0].hx_out, p.nodes[0].hy_out), -1.0, 1e-9);
    set_node_smooth(p, 0, false);
    CHECK(same_handles(p, closed, 1e-12));
    CHECK(p.close() == Close::Modifier);
}

// ------------------------------------------------------- manual handles

void test_drag_smooth_mirrors_opposite()
{
    Path p = make_path({{0,0,false},{100,0,true},{200,80,false}});
    const double oppLen = len_out(p.nodes[1]);
    drag_handle(p, 1, true, 100 - 30, 40);
    const Node& n = p.nodes[1];
    CHECK_NEAR(n.hx_in, -30, EPS);
    CHECK_NEAR(n.hy_in,  40, EPS);
    CHECK(n.manual_in && n.manual_out);
    CHECK_NEAR(cosine(n.hx_in, n.hy_in, n.hx_out, n.hy_out), -1.0, 1e-9);
    CHECK_NEAR(len_out(n), oppLen, 1e-9);
}

void test_drag_corner_leaves_opposite_alone()
{
    Path p = make_path({{0,0,true},{100,0,false},{200,80,true}});
    const Node before = p.nodes[1];
    drag_handle(p, 1, false, 140, 60);
    CHECK_NEAR(p.nodes[1].hx_out, 40, EPS);
    CHECK(p.nodes[1].manual_out && !p.nodes[1].manual_in);
    CHECK_NEAR(p.nodes[1].hx_in, before.hx_in, EPS);
    CHECK_NEAR(p.nodes[1].hy_in, before.hy_in, EPS);
}

void test_drag_with_missing_opposite_handle()
{
    Path p = make_path({{0,0,true},{100,50,true},{200,0,false}});
    drag_handle(p, 0, false, 50, 50);
    CHECK(p.nodes[0].manual_out);
    CHECK(!p.nodes[0].manual_in);
    CHECK(!has_in(p.nodes[0]));
}

void test_manual_frozen_across_recompute()
{
    Path p = make_path({{0,0,false},{100,0,true},{200,80,false},{300,0,true}});
    drag_handle(p, 1, false, 150, 30);
    const Node dragged = p.nodes[1];
    p.nodes[3].y = 40;
    compute_handles(p);
    CHECK_NEAR(p.nodes[1].hx_out, dragged.hx_out, 1e-12);
    CHECK_NEAR(p.nodes[1].hy_in,  dragged.hy_in,  1e-12);
}

void test_drag_bad_index_is_a_no_op()
{
    Path p = make_path({{0,0,false},{100,0,true},{200,80,false}});
    const Path before = p;
    drag_handle(p, -1, true, 60, 50);
    drag_handle(p, 3,  true, 60, 50);
    CHECK(same_handles(p, before, 0.0));
}

// 2.2.0: a drag updates the neighbours at once. The corner after a smooth
// node continues its arc, so it follows the dragged handle without waiting
// for the next compute_handles.
void test_drag_updates_neighbours_at_once()
{
    Path p = make_path({{0,0,false},{100,0,true},{200,80,false}});
    const Node before = p.nodes[2];
    drag_handle(p, 1, false, 150, 60);
    Path q = p;
    compute_handles(q);
    CHECK(same_handles(p, q, 1e-12));                   // already settled
    CHECK(std::fabs(p.nodes[2].hx_in - before.hx_in) > 1e-6
       || std::fabs(p.nodes[2].hy_in - before.hy_in) > 1e-6);
}

// ------------------------------------------------- FreeHand measurements

void test_freehand_shield()
{
    const double xs[8]  = { 431, 307, 119, 121, 430, 716, 733, 589 };
    const double ys[8]  = {  27, 178, 220, 488, 833, 446, 214, 206 };
    const bool   sm[8]  = { false, true, false, true, false, true, false, true };

    const double exp_inx[8]  = {  21,  66,  74,  -28, -169, -45,  11,  52 };
    const double exp_iny[8]  = {  91, -40,   9, -101,  -66, 183,  89,  19 };
    const double exp_outx[8] = { -26, -65, -26,   47,  161,  24, -55, -89 };
    const double exp_outy[8] = {  70,  39, 102,  174,  -96, -88,  14, -33 };

    Path p;
    for (int i = 0; i < 8; ++i) p.nodes.push_back(make_node(xs[i], ys[i], sm[i]));
    close_path(p, false);
    compute_handles(p);

    for (int i = 0; i < 8; ++i) {
        const Node& n = p.nodes[i];
        CHECK_NEAR(n.hx_in,  exp_inx[i],  3.0);
        CHECK_NEAR(n.hy_in,  exp_iny[i],  3.0);
        CHECK_NEAR(n.hx_out, exp_outx[i], 3.0);
        CHECK_NEAR(n.hy_out, exp_outy[i], 3.0);
    }
}

void test_shield_smooth_nodes_are_collinear()
{
    const double xs[8] = { 431, 307, 119, 121, 430, 716, 733, 589 };
    const double ys[8] = {  27, 178, 220, 488, 833, 446, 214, 206 };
    const bool   sm[8] = { false, true, false, true, false, true, false, true };
    Path p;
    for (int i = 0; i < 8; ++i) p.nodes.push_back(make_node(xs[i], ys[i], sm[i]));
    close_path(p, false);
    compute_handles(p);
    for (int i = 0; i < 8; ++i) {
        if (!sm[i]) continue;
        CHECK_NEAR(cosine(p.nodes[i].hx_in, p.nodes[i].hy_in,
                          p.nodes[i].hx_out, p.nodes[i].hy_out), -1.0, 1e-9);
    }
}

// ------------------------------------------------------- degenerate input

void test_coincident_nodes()
{
    const std::vector<std::vector<Pt> > cases = {
        { {50,50,true},  {50,50,true},  {50,50,true} },
        { {0,0,false},   {0,0,true},    {100,0,true} },
        { {0,0,true},    {100,0,true},  {0,0,true} },
        { {0,0,true},    {100,0,false}, {0,0,true}, {100,0,true} },
        { {1e-12,0,true},{100,0,true},  {200,0,true} },
        { {50,50,true},  {50,50,true} },
    };
    const Close closes[3] = { Close::Open, Close::Plain, Close::Modifier };
    for (size_t c = 0; c < cases.size(); ++c) {
        for (int k = 0; k < 3; ++k) {
            Path p = make_path(cases[c], closes[k]);
            CHECK(all_finite(p));
        }
    }
}

// Click A, modifier-click B, click C, drag C onto A, path left open. A and C
// coincide but are separate nodes: nothing special happens, and every handle
// lies along the one chord until the nodes are moved apart.
void test_path_that_goes_out_and_comes_back()
{
    Path p = make_path({{0,0,false},{100,0,true},{0,0,false}});
    CHECK(all_finite(p));
    CHECK(points_at(p, 1, 0, p.nodes[1].hx_in,  p.nodes[1].hy_in));
    CHECK(points_at(p, 1, 2, p.nodes[1].hx_out, p.nodes[1].hy_out));
    CHECK(flat(p, 0, 1, false));
    CHECK(flat(p, 2, 1, true));
}

void test_huge_and_tiny_coordinates()
{
    const double scales[] = { 1e-6, 1e-3, 1.0, 1e3, 1e6, 1e9 };
    for (size_t k = 0; k < sizeof(scales) / sizeof(scales[0]); ++k) {
        const double s = scales[k];
        Path p = make_path({ {0,0,false}, {s,0,true}, {2*s,s,false}, {3*s,0,true} });
        CHECK(all_finite(p));
        CHECK(has_out(p.nodes[1]));
    }
}

// 2.2.0: the threshold for "no circle" scales with the drawing, so a smooth
// node behaves the same at any size. With the old fixed threshold, once its
// segments were longer than about 2e9 units the node lost its circle and its
// handles stopped being collinear (2.1.1 fails this from 3e9 up).
void test_smooth_node_at_any_scale()
{
    const double scales[] = { 1e-6, 1.0, 1e3, 1e9, 3e9, 1e10, 1e12 };
    for (size_t k = 0; k < sizeof(scales) / sizeof(scales[0]); ++k) {
        const double s = scales[k];
        Path p = make_path({ {0,0,false}, {s,0,true}, {2*s,1e-3*s,false} });
        const Node& b = p.nodes[1];
        CHECK_NEAR(cosine(b.hx_in, b.hy_in, b.hx_out, b.hy_out), -1.0, 1e-12);
    }
}

// Scaling every coordinate scales every handle by the same factor.
void test_scale_invariance()
{
    const std::vector<Pt> base = { {0,0,false},{100,-40,true},{200,40,true},{100,150,true},{-20,90,false} };
    const Close closes[3] = { Close::Open, Close::Plain, Close::Modifier };
    const double scales[] = { 1e-6, 1e-3, 1e3, 1e6, 1e9 };
    for (int c = 0; c < 3; ++c) {
        const Path ref = make_path(base, closes[c]);
        for (size_t k = 0; k < sizeof(scales) / sizeof(scales[0]); ++k) {
            const double s = scales[k];
            std::vector<Pt> pts = base;
            for (size_t i = 0; i < pts.size(); ++i) { pts[i].x *= s; pts[i].y *= s; }
            const Path p = make_path(pts, closes[c]);
            bool ok = true;
            for (size_t i = 0; i < p.nodes.size(); ++i) {
                const double a[4] = {ref.nodes[i].hx_in, ref.nodes[i].hy_in, ref.nodes[i].hx_out, ref.nodes[i].hy_out};
                const double b[4] = {p.nodes[i].hx_in / s, p.nodes[i].hy_in / s, p.nodes[i].hx_out / s, p.nodes[i].hy_out / s};
                for (int j = 0; j < 4; ++j) if (std::fabs(a[j] - b[j]) > 1e-6) ok = false;
            }
            CHECK(ok);
        }
    }
}

// ------------------------------------------------------- random properties

struct Rng
{
    uint64_t s;
    explicit Rng(uint64_t seed) : s(seed * 0x9E3779B97F4A7C15ull + 1) {}
    uint64_t next() { s ^= s << 13;  s ^= s >> 7;  s ^= s << 17;  return s; }
    double uniform(double lo, double hi)
    {
        return lo + (hi - lo) * ((next() >> 11) * (1.0 / 9007199254740992.0));
    }
    int below(int n) { return (int)(next() % (uint64_t)n); }
};

Path random_path(Rng& rng, int n, Close close)
{
    Path p;
    while ((int)p.nodes.size() < n) {
        const double x = rng.uniform(0, 600);
        const double y = rng.uniform(0, 600);
        bool clear = true;
        for (size_t i = 0; i < p.nodes.size(); ++i)
            if (std::hypot(p.nodes[i].x - x, p.nodes[i].y - y) < 25)
                clear = false;
        if (!clear) continue;
        p.nodes.push_back(make_node(x, y, rng.below(2) == 1));
    }
    if (close != Close::Open) close_path(p, close == Close::Modifier);
    compute_handles(p);
    return p;
}

Close random_close(Rng& rng)
{
    const int r = rng.below(3);
    return r == 0 ? Close::Open : r == 1 ? Close::Plain : Close::Modifier;
}

void prop_finite(Rng& rng, int runs)
{
    for (int r = 0; r < runs; ++r) {
        const Path p = random_path(rng, 1 + rng.below(12), random_close(rng));
        CHECK(all_finite(p));
    }
}

void prop_handle_lengths(Rng& rng, int runs)
{
    for (int r = 0; r < runs; ++r) {
        const Path p = random_path(rng, 2 + rng.below(9), random_close(rng));
        const int  n = (int)p.nodes.size();
        const bool loop = p.close() != Close::Open && n >= 2;
        for (int i = 0; i < n; ++i) {
            const Node& nd = p.nodes[i];
            const int prev = i > 0 ? i - 1 : (loop ? n - 1 : -1);
            const int next = i < n - 1 ? i + 1 : (loop ? 0 : -1);
            if (has_in(nd))  { CHECK(prev >= 0); CHECK_NEAR(len_in(nd),  K * dist(p, i, prev), 1e-9); }
            if (has_out(nd)) { CHECK(next >= 0); CHECK_NEAR(len_out(nd), K * dist(p, i, next), 1e-9); }
        }
    }
}

void prop_smooth_nodes_are_collinear(Rng& rng, int runs)
{
    for (int r = 0; r < runs; ++r) {
        const Path p = random_path(rng, 2 + rng.below(9), random_close(rng));
        for (int i = 0; i < (int)p.nodes.size(); ++i) {
            const Node& nd = p.nodes[i];
            if (nd.smooth && has_in(nd) && has_out(nd))
                CHECK_NEAR(cosine(nd.hx_in, nd.hy_in, nd.hx_out, nd.hy_out),
                           -1.0, 1e-9);
        }
    }
}

void prop_idempotent(Rng& rng, int runs)
{
    for (int r = 0; r < runs; ++r) {
        Path p = random_path(rng, 2 + rng.below(9), random_close(rng));
        Path q = p;
        compute_handles(q);
        CHECK(same_handles(p, q, 1e-9));
    }
}

void prop_corner_arcs_are_symmetric(Rng& rng, int runs)
{
    for (int r = 0; r < runs; ++r) {
        const Path p = random_path(rng, 3 + rng.below(9), Close::Plain);
        const int n = (int)p.nodes.size();
        for (int i = 0; i < n; ++i) {
            const int j = (i + 1) % n;
            const bool ca = !p.nodes[i].smooth, cb = !p.nodes[j].smooth;
            if (ca == cb) continue;
            const Node& a = p.nodes[i];
            const Node& b = p.nodes[j];
            if (!has_out(a) || !has_in(b)) continue;
            const double cx = b.x - a.x, cy = b.y - a.y, cl = std::hypot(cx, cy);
            if (cl < EPS) continue;
            const double cross_a = (a.hx_out * cy - a.hy_out * cx) / cl;
            const double cross_b = (b.hx_in  * cy - b.hy_in  * cx) / cl;
            CHECK_NEAR(std::fabs(cross_a), std::fabs(cross_b), 1e-6);
        }
    }
}

void prop_all_smooth_full_handles(Rng& rng, int runs)
{
    for (int r = 0; r < runs; ++r) {
        Path p = random_path(rng, 2 + rng.below(9), Close::Plain);
        for (size_t i = 0; i < p.nodes.size(); ++i) set_node_smooth(p, (int)i, true);
        for (size_t i = 0; i < p.nodes.size(); ++i)
            CHECK(has_in(p.nodes[i]) && has_out(p.nodes[i]));
    }
}

// 2.2.0: drag_handle recomputes, so after any drag the whole path is settled
// at once, and every handle the drag marked manual is exactly where the user
// left it.
void prop_drag_leaves_path_settled(Rng& rng, int runs)
{
    for (int r = 0; r < runs; ++r) {
        Path p = random_path(rng, 2 + rng.below(9), random_close(rng));
        for (int d = 0; d < 3; ++d) {
            const int  i    = rng.below((int)p.nodes.size());
            const bool isIn = rng.below(2) == 1;
            const double tx = p.nodes[i].x + rng.uniform(-80, 80);
            const double ty = p.nodes[i].y + rng.uniform(-80, 80);
            drag_handle(p, i, isIn, tx, ty);

            const Node& nd = p.nodes[i];
            if (isIn  && nd.manual_in)  { CHECK_NEAR(nd.hx_in,  tx - nd.x, 1e-9); CHECK_NEAR(nd.hy_in,  ty - nd.y, 1e-9); }
            if (!isIn && nd.manual_out) { CHECK_NEAR(nd.hx_out, tx - nd.x, 1e-9); CHECK_NEAR(nd.hy_out, ty - nd.y, 1e-9); }
            CHECK(all_finite(p));

            Path q = p;
            compute_handles(q);
            CHECK(same_handles(p, q, 1e-9));
        }
    }
}

// Toggling a node twice (nothing dragged): a smooth node comes back as it was,
// and a corner comes back as a cusp.
void prop_toggle_twice(Rng& rng, int runs)
{
    for (int r = 0; r < runs; ++r) {
        const Path p = random_path(rng, 2 + rng.below(9), random_close(rng));
        Path q = p;
        const int i = rng.below((int)q.nodes.size());
        set_node_smooth(q, i, !q.nodes[i].smooth);
        set_node_smooth(q, i, !q.nodes[i].smooth);
        CHECK(q.nodes[i].smooth == p.nodes[i].smooth);

        Path expected = p;
        expected.nodes[i].cusp = !p.nodes[i].smooth;
        compute_handles(expected);
        CHECK(same_handles(q, expected, 1e-9));
    }
}

void run_property(const char* name, void (*fn)(Rng&, int), Rng& rng, int runs)
{
    g_test = name;
    const int before = g_failures;
    fn(rng, runs);
    std::printf("%-4s %s\n", g_failures == before ? "ok" : "FAIL", name);
}

#define PROPERTY(fn) run_property(#fn, fn, rng, runs)

void test_random_properties(int runs, uint64_t seed)
{
    Rng rng(seed);
    std::printf("-- random properties: %d paths each, seed %llu\n",
                runs, (unsigned long long)seed);
    PROPERTY(prop_finite);
    PROPERTY(prop_handle_lengths);
    PROPERTY(prop_smooth_nodes_are_collinear);
    PROPERTY(prop_idempotent);
    PROPERTY(prop_corner_arcs_are_symmetric);
    PROPERTY(prop_all_smooth_full_handles);
    PROPERTY(prop_drag_leaves_path_settled);
    PROPERTY(prop_toggle_twice);
}

struct TestCase { const char* name; void (*fn)(); };
#define TEST(fn) { #fn, fn }
const TestCase kTests[] = {
    TEST(test_empty_path),
    TEST(test_single_node_has_no_handles),
    TEST(test_two_nodes_have_handles_to_each_other),
    TEST(test_handle_length_is_k_times_own_segment),
    TEST(test_handle_fraction_option),
    TEST(test_smooth_collinear_three_points),
    TEST(test_smooth_eight_on_a_circle),
    TEST(test_smooth_unequal_segments),
    TEST(test_smooth_endpoints_point_at_their_neighbour),
    TEST(test_corner_between_corners_is_a_straight_line),
    TEST(test_corner_between_smooth_neighbours),
    TEST(test_corner_between_smooth_and_corner),
    TEST(test_corner_reflection_is_symmetric),
    TEST(test_plain_close_preserves_start_type),
    TEST(test_modifier_close_converts_smooth_start_to_corner),
    TEST(test_modifier_close_start_handles_point_at_neighbours),
    TEST(test_modifier_close_corner_start_reflects_out),
    TEST(test_close_path_requires_two_nodes),
    TEST(test_close_state_and_start_node_agree),
    TEST(test_two_node_loop_plain_close_is_an_ellipse),
    TEST(test_two_node_loop_modifier_close_makes_a_cusp),
    TEST(test_two_node_loop_of_corners_is_flat),
    TEST(test_two_node_loop_toggles),
    TEST(test_coincidence_in_a_larger_loop_stays_plain),
    TEST(test_make_node),
    TEST(test_toggle_sharp_node_becomes_cusp),
    TEST(test_two_node_loop_corner_toggles_to_cusp),
    TEST(test_toggle_curved_node_becomes_cusp),
    TEST(test_toggle_releases_dragged_handles),
    TEST(test_toggle_ignores_same_type_and_bad_index),
    TEST(test_modifier_closed_start_toggles),
    TEST(test_drag_smooth_mirrors_opposite),
    TEST(test_drag_corner_leaves_opposite_alone),
    TEST(test_drag_with_missing_opposite_handle),
    TEST(test_manual_frozen_across_recompute),
    TEST(test_drag_bad_index_is_a_no_op),
    TEST(test_drag_updates_neighbours_at_once),
    TEST(test_freehand_shield),
    TEST(test_shield_smooth_nodes_are_collinear),
    TEST(test_coincident_nodes),
    TEST(test_path_that_goes_out_and_comes_back),
    TEST(test_huge_and_tiny_coordinates),
    TEST(test_smooth_node_at_any_scale),
    TEST(test_scale_invariance),
};

}   // namespace

int main(int argc, char** argv)
{
    int      runs = 20000;
    uint64_t seed = 1;
    for (int i = 1; i < argc; ++i) {
        if (!std::strcmp(argv[i], "--runs") && i + 1 < argc)
            runs = std::atoi(argv[++i]);
        else if (!std::strcmp(argv[i], "--seed") && i + 1 < argc)
            seed = (uint64_t)std::atoll(argv[++i]);
        else {
            std::printf("usage: %s [--runs N] [--seed N]\n", argv[0]);
            return 2;
        }
    }

    for (size_t t = 0; t < sizeof(kTests) / sizeof(kTests[0]); ++t) {
        g_test = kTests[t].name;
        const int before = g_failures;
        kTests[t].fn();
        std::printf("%-4s %s\n",
                    g_failures == before ? "ok" : "FAIL", kTests[t].name);
    }
    test_random_properties(runs, seed);

    std::printf("\n%d checks, %d failed\n", g_checks, g_failures);
    return g_failures == 0 ? 0 : 1;
}

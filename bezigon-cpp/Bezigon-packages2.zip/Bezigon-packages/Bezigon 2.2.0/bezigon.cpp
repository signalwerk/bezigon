// This file is part of Bezigon, released under the MIT License.
// See LICENSE for details.
//
// Diese Datei ist Teil von Bezigon und steht unter der MIT-Lizenz.
// Siehe LICENSE für Einzelheiten.

// bezigon.cpp
// Handle computation for the Bezigon tool.
//
// Every node has an in-handle (toward the previous node) and an
// out-handle (toward the next node). Each is handleFraction times the
// length of its own segment, so only the direction needs deciding:
//
//   Smooth node    Follows its tangent: the tangent of the circle
//                  through previous, node and next. A missing neighbour
//                  (an end of an open path) simply drops out of the
//                  formula, which leaves an end node with the direction
//                  of its one chord. If previous and next are the same
//                  point there is no such circle:
//                    - in a closed path of exactly two nodes, both
//                      neighbours are the one other node. The node points
//                      square to the chord, so the two nodes draw an
//                      ellipse, as Xara does.
//                    - anywhere else (two separate nodes that happen to
//                      sit on one point) nothing special happens: each
//                      handle points straight at its neighbour, as in
//                      FreeHand, until the nodes are moved apart.
//
//   Corner node    Each side is decided on its own. If the neighbour on
//                  that side is smooth, continue its arc: reflect the
//                  neighbour's tangent across the chord. Otherwise point
//                  straight at the neighbour.
//
//   Cusp           A corner that was converted from a smooth node. It
//                  follows none of its neighbours: each handle points
//                  straight at its own neighbour.
//
//   Modifier close The start node is made by two clicks, and each
//                  handle is made as if its click ended an open path. A
//                  modifier click at an end gives a straight handle, a
//                  plain click gives the corner rule. So after a
//                  modifier close the start node is a corner whose
//                  in-handle is straight. If it was smooth it is now a
//                  cusp, so its out-handle is straight too.

#include "bezigon.h"
#include <cmath>

namespace bezigon {

static const double EPS = 1e-9;

// One side of a node: its neighbour, and where that neighbour lies.
struct Side
{
    int    j   = -1;              // neighbour index, or -1 if there is none
    bool   ok  = false;           // neighbour exists and is not on top of the node
    double ux  = 0.0, uy = 0.0;   // unit vector from the node to the neighbour
    double len = 0.0;             // distance to the neighbour
};

// Tangent of a smooth node: unit vector, in the direction of travel.
struct Tangent
{
    bool   ok = false;
    double x = 0.0, y = 0.0;
};

// Scale (x, y) to unit length. False, with (x, y) untouched, if it is
// shorter than minLength.
static bool normalise(double& x, double& y, double minLength)
{
    double l = std::hypot(x, y);
    if (l < minLength) return false;
    const double k = 1.0 / l;
    x *= k;  y *= k;
    return true;
}

static int neighbour(int i, int n, bool loop, int step)
{
    int j = i + step;
    if (j >= 0 && j < n) return j;
    return loop ? (j + n) % n : -1;
}

static Side make_side(const std::vector<Node>& v, int i, int j)
{
    Side s;
    s.j = j;
    if (j < 0) return s;
    double dx = v[j].x - v[i].x, dy = v[j].y - v[i].y;
    s.len = std::hypot(dx, dy);
    if (s.len < EPS) return s;
    const double k = 1.0 / s.len;
    s.ux = k * dx;  s.uy = k * dy;  s.ok = true;
    return s;
}

static bool is_loop(const Path& path)
{
    return path.close() != Close::Open && path.nodes.size() >= 2;
}

// A closed path of exactly two nodes: each node has the other on both sides.
static bool is_two_node_loop(const Path& path)
{
    return is_loop(path) && path.nodes.size() == 2;
}

// The start node of a path closed with the modifier.
static bool is_modifier_start(const Path& path, int i)
{
    return i == 0 && is_loop(path) && path.close() == Close::Modifier;
}

// Tangent at the node of the circle through prev, node, next, pointing
// from prev toward next. Inverting about the node turns that circle
// into a line, which gives
//     t  ~  u_next / |next|  -  u_prev / |prev|
// Equal distances reduce this to "from prev toward next". A missing
// neighbour contributes nothing, so an end node gets its chord
// direction. False if there is no such circle: the node has no
// neighbour, or prev and next are the same point. The threshold scales
// with the distances, so the answer does not depend on the size of the
// drawing.
static bool circle_tangent(const Side& prev, const Side& next,
                           double& x, double& y)
{
    double scale = 0.0;
    x = y = 0.0;
    if (next.ok) { x += (1.0 / next.len) * next.ux;  y += (1.0 / next.len) * next.uy;  scale += 1.0 / next.len; }
    if (prev.ok) { x -= (1.0 / prev.len) * prev.ux;  y -= (1.0 / prev.len) * prev.uy;  scale += 1.0 / prev.len; }
    return scale > 0.0 && normalise(x, y, EPS * scale);
}

// Direction implied by a handle the user dragged on a smooth node.
static bool manual_tangent(const Node& nd, double& x, double& y)
{
    double ox = nd.hx_out, oy = nd.hy_out;
    double ix = -nd.hx_in, iy = -nd.hy_in;
    if (nd.manual_out && normalise(ox, oy, EPS)) { x = ox;  y = oy;  return true; }
    if (nd.manual_in  && normalise(ix, iy, EPS)) { x = ix;  y = iy;  return true; }
    return false;
}

// Reflect direction s across the line along c (c need not point either way).
static void reflect(double sx, double sy, double cx, double cy,
                    double& tx, double& ty)
{
    double dot = sx * cx + sy * cy;
    tx = 2.0 * dot * cx - sx;
    ty = 2.0 * dot * cy - sy;
}

bool close_path(Path& path, bool withModifier)
{
    if (path.nodes.size() < 2) return false;
    path.close_ = withModifier ? Close::Modifier : Close::Plain;

    Node& start = path.nodes[0];
    if (withModifier && start.smooth) {
        start.smooth = false;
        start.cusp   = true;
    }
    return true;
}

void set_node_smooth(Path& path, int index, bool smooth, const Options& opts)
{
    if (index < 0 || index >= (int)path.nodes.size()) return;
    Node& nd = path.nodes[index];
    if (nd.smooth == smooth) return;

    // Dragged handles do not survive a conversion: a smooth node's handles
    // belong to the curve running through it, and a corner falls back to its
    // own rule (a cusp lies along its chords).
    // The type changed, so a node becoming a corner was smooth: a cusp.
    nd.smooth     = smooth;
    nd.cusp       = !smooth;
    nd.manual_in  = false;
    nd.manual_out = false;
    compute_handles(path, opts);
}

void compute_handles(Path& path, const Options& opts)
{
    std::vector<Node>& v = path.nodes;
    const int  n       = (int)v.size();
    const bool loop    = is_loop(path);
    const bool twoLoop = is_two_node_loop(path);

    std::vector<Side> prev(n), next(n);
    for (int i = 0; i < n; ++i) {
        prev[i] = make_side(v, i, neighbour(i, n, loop, -1));
        next[i] = make_side(v, i, neighbour(i, n, loop, +1));
    }

    // Pass 1: the tangent of every smooth node. Corners have none.
    std::vector<Tangent> tangent(n);
    for (int i = 0; i < n; ++i) {
        if (!v[i].smooth) continue;
        Tangent& t = tangent[i];
        t.ok = manual_tangent(v[i], t.x, t.y)
            || circle_tangent(prev[i], next[i], t.x, t.y);
        // A closed path of two nodes has no circle through three points.
        // Take the circle that has the chord as its diameter: the tangent is
        // square to the chord, and the two nodes draw an ellipse.
        if (!t.ok && twoLoop && prev[i].ok) {
            t.x  = -prev[i].uy;
            t.y  =  prev[i].ux;
            t.ok = true;
        }
    }

    // Pass 2: the handle on each side of each node.
    for (int i = 0; i < n; ++i) {
        Node& nd = v[i];
        const bool modifierStart = is_modifier_start(path, i);

        for (int pass = 0; pass < 2; ++pass) {
            const bool isIn = (pass == 0);
            if (isIn ? nd.manual_in : nd.manual_out) continue;

            const Side& s  = isIn ? prev[i] : next[i];
            double&     hx = isIn ? nd.hx_in : nd.hx_out;
            double&     hy = isIn ? nd.hy_in : nd.hy_out;
            hx = hy = 0.0;
            if (!s.ok) continue;

            // The direction of travel at this node that the handle
            // follows. Default: straight at the neighbour.
            double dx = isIn ? -s.ux : s.ux;
            double dy = isIn ? -s.uy : s.uy;

            if (nd.smooth) {
                // No tangent only when the neighbours coincide: stay straight.
                if (tangent[i].ok) { dx = tangent[i].x;  dy = tangent[i].y; }
            } else if (isIn && modifierStart) {
                // The modifier close reaches straight back to the last node.
            } else if (nd.cusp) {
                // A cusp follows nothing.
            } else if (tangent[s.j].ok) {
                // A corner continues its smooth neighbour's arc.
                reflect(tangent[s.j].x, tangent[s.j].y, s.ux, s.uy, dx, dy);
            }

            const double k = opts.handleFraction * s.len;
            hx = (isIn ? -dx : dx) * k;
            hy = (isIn ? -dy : dy) * k;
        }
    }
}

void drag_handle(Path& path, int index, bool isIn, double x, double y,
                 const Options& opts)
{
    if (index < 0 || index >= (int)path.nodes.size()) return;
    Node& nd = path.nodes[index];

    double& hx   = isIn ? nd.hx_in  : nd.hx_out;   // the handle being dragged
    double& hy   = isIn ? nd.hy_in  : nd.hy_out;
    double& ox   = isIn ? nd.hx_out : nd.hx_in;    // the opposite handle
    double& oy   = isIn ? nd.hy_out : nd.hy_in;
    bool&   man  = isIn ? nd.manual_in  : nd.manual_out;
    bool&   oman = isIn ? nd.manual_out : nd.manual_in;

    hx = x - nd.x;  hy = y - nd.y;
    man = true;

    if (nd.smooth) {
        double len = std::hypot(hx, hy), oppLen = std::hypot(ox, oy);
        if (len > EPS && oppLen > EPS) {
            ox = -hx / len * oppLen;
            oy = -hy / len * oppLen;
            oman = true;
        }
    }
    // Neighbouring corners that continue this node's arc follow at once.
    compute_handles(path, opts);
}

}   // namespace bezigon

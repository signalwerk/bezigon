// This file is part of Bezigon, released under the MIT License.
// See LICENSE for details.
//
// Diese Datei ist Teil von Bezigon und steht unter der MIT-Lizenz.
// Siehe LICENSE für Einzelheiten.

// main.cpp
// Bezigon demo. EGE window, mouse and keyboard handling, drawing.
// Uses bezigon.h / bezigon.cpp for the handle computation.
//
//   Click            corner node        (red square)
//   Shift + click    smooth node        (blue circle)
//   Ctrl + click     tangent node       (orange triangle)
//   Click the start node to close the path; hold Shift for a modifier close.
//               Two nodes are enough: they close into a loop.
//   Or drag the end node onto the start node: it snaps there while in range,
//               and releasing it closes the path (Shift held at release for a
//               modifier close). The end node merges into the start node.
//
//   C / S / T   turn the node under the cursor into a Corner / Smooth /
//               Tangent node. A curved node turned into a Corner becomes a
//               cusp, so any node toggles between smooth and cusp.
//   Ctrl + drag from a Tangent node pulls out one of its handles. The
//               handle stays on its fixed line; only its length follows
//               the cursor. Drag toward the handle you want.
//   D       show / hide handles (handles can be dragged while shown)
//   R       release all dragged handles back to automatic
//   1 - 7   load an example path
//   Enter or right-click   finish an open path
//   Esc     clear

#include <graphics.h>
#include <cmath>
#include "bezigon.h"
#include "demo_scenes.h"

using bezigon::Close;
using bezigon::Node;
using bezigon::NodeType;
using bezigon::Path;

static const int WIN_W               = 900;
static const int WIN_H               = 700;
static const int HIT_RADIUS          = 10;
static const int NODE_HIT_RADIUS     = 8;
static const int HANDLE_HIT_RADIUS   = 8;
static const int CLOSE_MOVE_SQ       = 25;
static const int PULL_MOVE_SQ        = 25;     // pixels^2 before a pull picks a handle
static const int STEPS               = 200;

static Path        g_path;
static bool        g_finished    = false;   // demo-only: user pressed Enter or right-click
static bool        g_showHandles = false;
static const char* g_sceneName   = "";      // shown on screen after loading an example
static int         g_mouseX      = 0;
static int         g_mouseY      = 0;

enum DragKind { DRAG_NONE, DRAG_NODE, DRAG_PULL, DRAG_HANDLE_IN, DRAG_HANDLE_OUT };
static DragKind g_dragKind       = DRAG_NONE;
static int      g_dragIndex      = -1;
static int      g_pressX         = 0;
static int      g_pressY         = 0;
static bool     g_potentialClose = false;

// --- State helpers ---

static void cancel_drag()
{
    g_dragKind       = DRAG_NONE;
    g_dragIndex      = -1;
    g_potentialClose = false;
}

static void reset_path()
{
    g_path = Path();
    g_finished   = false;
    g_sceneName  = "";
    cancel_drag();
}

static void recompute()
{
    bezigon::compute_handles(g_path);
}

// --- Editing ---

static NodeType type_from_keys()
{
    if (keystate(VK_CONTROL)) return NodeType::Tangent;
    if (keystate(VK_SHIFT))   return NodeType::Smooth;
    return NodeType::Corner;
}

static void add_node(int x, int y, NodeType type)
{
    if (g_finished || g_path.close() != Close::Open) reset_path();
    g_path.nodes.push_back(bezigon::make_node(x, y, type));
    recompute();
}

// True if node `index` is the end node of an open path and (x, y) is close
// enough to the start node for the end node to snap onto it.
static bool snaps_to_start(int index, int x, int y)
{
    const int n = (int)g_path.nodes.size();
    if (g_path.close() != Close::Open || n < 3 || index != n - 1) return false;
    const double dx = g_path.nodes[0].x - x;
    const double dy = g_path.nodes[0].y - y;
    return dx * dx + dy * dy <= (double)HIT_RADIUS * HIT_RADIUS;
}

// True if the end node of an open path sits exactly on the start node: it was
// dragged there and snapped.
static bool end_on_start()
{
    const std::vector<Node>& v = g_path.nodes;
    return g_path.close() == Close::Open && v.size() >= 3
        && v.back().x == v[0].x && v.back().y == v[0].y;
}

static void close_now(bool modifier)
{
    // An end node dragged onto the start node merges into it, so the close
    // joins the path into a loop rather than adding a zero-length segment.
    if (end_on_start()) g_path.nodes.pop_back();
    if (!bezigon::close_path(g_path, modifier)) return;
    g_finished = true;
    recompute();
}

// Change a node's type. The library decides which dragged handles survive.
static void convert_node(int index, NodeType type)
{
    bezigon::set_node_type(g_path, index, type);
}

// Load an example path, scaled down if needed and centred in the window.
static void load_scene(int index)
{
    const bezigon::scenes::Scene& s = bezigon::scenes::all[index];
    Path p = bezigon::scenes::build(s);

    double minX = p.nodes[0].x, maxX = minX, minY = p.nodes[0].y, maxY = minY;
    for (size_t i = 1; i < p.nodes.size(); ++i) {
        if (p.nodes[i].x < minX) minX = p.nodes[i].x;
        if (p.nodes[i].x > maxX) maxX = p.nodes[i].x;
        if (p.nodes[i].y < minY) minY = p.nodes[i].y;
        if (p.nodes[i].y > maxY) maxY = p.nodes[i].y;
    }
    const double margin = 80.0;
    double scale = 1.0;
    if (maxX > minX && (WIN_W - 2 * margin) / (maxX - minX) < scale)
        scale = (WIN_W - 2 * margin) / (maxX - minX);
    if (maxY > minY && (WIN_H - 2 * margin) / (maxY - minY) < scale)
        scale = (WIN_H - 2 * margin) / (maxY - minY);
    for (size_t i = 0; i < p.nodes.size(); ++i) {
        p.nodes[i].x = WIN_W / 2.0 + (p.nodes[i].x - (minX + maxX) / 2.0) * scale;
        p.nodes[i].y = WIN_H / 2.0 + (p.nodes[i].y - (minY + maxY) / 2.0) * scale;
    }

    reset_path();
    g_path        = p;
    g_finished    = true;
    g_showHandles = true;
    g_sceneName   = s.name;
    recompute();
}

// --- Hit testing ---

static int hit_node(int x, int y)
{
    for (int i = 0; i < (int)g_path.nodes.size(); ++i) {
        double dx = g_path.nodes[i].x - x;
        double dy = g_path.nodes[i].y - y;
        if (dx * dx + dy * dy <= (double)NODE_HIT_RADIUS * NODE_HIT_RADIUS)
            return i;
    }
    return -1;
}

// True if (x, y) is on the tip of the handle with offset (hx, hy).
// A zero offset means "no handle" and is never hit.
static bool on_handle_tip(const Node& n, double hx, double hy, int x, int y)
{
    if (hx == 0.0 && hy == 0.0) return false;
    double dx = n.x + hx - x;
    double dy = n.y + hy - y;
    return dx * dx + dy * dy <= (double)HANDLE_HIT_RADIUS * HANDLE_HIT_RADIUS;
}

static int hit_handle(int x, int y, bool& isIn)
{
    for (int i = 0; i < (int)g_path.nodes.size(); ++i) {
        const Node& n = g_path.nodes[i];
        if (on_handle_tip(n, n.hx_in,  n.hy_in,  x, y)) { isIn = true;  return i; }
        if (on_handle_tip(n, n.hx_out, n.hy_out, x, y)) { isIn = false; return i; }
    }
    return -1;
}

// --- Mouse ---

static void start_press(int x, int y, NodeType type)
{
    g_pressX = x;  g_pressY = y;
    g_potentialClose = false;

    // Nodes take priority over handles, so a handle tip sitting on top
    // of its node does not shadow the node.
    int ni = hit_node(x, y);
    if (ni >= 0) {
        // Ctrl + press on a Tangent node: pull out one of its handles.
        if (keystate(VK_CONTROL)
            && g_path.nodes[ni].type == NodeType::Tangent) {
            g_dragKind  = DRAG_PULL;
            g_dragIndex = ni;
            return;
        }
        g_dragKind  = DRAG_NODE;
        g_dragIndex = ni;
        g_potentialClose = (ni == 0 && g_path.nodes.size() >= 2
                            && g_path.close() == Close::Open);
        return;
    }

    // Only hit-test handles when they are visible.
    if (g_showHandles) {
        bool isIn = false;
        int hi = hit_handle(x, y, isIn);
        if (hi >= 0) {
            g_dragKind  = isIn ? DRAG_HANDLE_IN : DRAG_HANDLE_OUT;
            g_dragIndex = hi;
            return;
        }
    }

    add_node(x, y, type);
    g_dragKind  = DRAG_NODE;
    g_dragIndex = (int)g_path.nodes.size() - 1;
}

// The first moves of a Ctrl + drag on a Tangent node. The handle that
// points most nearly the way the cursor went is the one pulled out. From
// then on the drag is an ordinary handle drag.
static void pull_handle(int x, int y)
{
    const Node& n = g_path.nodes[g_dragIndex];
    const double dx = x - n.x, dy = y - n.y;
    if (dx * dx + dy * dy <= PULL_MOVE_SQ) return;

    bool   found = false, bestIsIn = false;
    double best  = 0.0;
    for (int side = 0; side < 2; ++side) {
        const bool isIn = (side == 0);
        double ax, ay;
        if (!bezigon::handle_axis(g_path, g_dragIndex, isIn, ax, ay)) continue;
        const double along = ax * dx + ay * dy;
        if (along > best) { best = along;  bestIsIn = isIn;  found = true; }
    }
    if (!found) return;                       // wait for a better direction

    g_dragKind    = bestIsIn ? DRAG_HANDLE_IN : DRAG_HANDLE_OUT;
    g_showHandles = true;
    bezigon::drag_handle(g_path, g_dragIndex, bestIsIn, x, y);
}

static void continue_drag(int x, int y)
{
    if (g_dragKind == DRAG_NONE) return;

    // The node list may have been cleared mid-drag (for example by Esc).
    if (g_dragIndex < 0 || g_dragIndex >= (int)g_path.nodes.size()) {
        cancel_drag();
        return;
    }

    // A press on the start node only becomes a drag after a small move.
    if (g_potentialClose) {
        int dx = x - g_pressX, dy = y - g_pressY;
        if (dx * dx + dy * dy <= CLOSE_MOVE_SQ) return;
        g_potentialClose = false;
    }

    if (g_dragKind == DRAG_PULL) {
        pull_handle(x, y);
    } else if (g_dragKind == DRAG_NODE) {
        Node& n = g_path.nodes[g_dragIndex];
        if (snaps_to_start(g_dragIndex, x, y)) {
            n.x = g_path.nodes[0].x;            // sit exactly on the start node
            n.y = g_path.nodes[0].y;
        } else {
            n.x = x;  n.y = y;
        }
        recompute();
    } else {
        // Also updates whatever depends on the dragged handle.
        bezigon::drag_handle(g_path, g_dragIndex, g_dragKind == DRAG_HANDLE_IN, x, y);
    }
}

// Releasing the mouse closes the path after a click on the start node, or
// after dragging the end node onto it. The modifier held at release decides
// how it closes.
static void finish_press(bool modifier)
{
    const bool droppedOnStart = g_dragKind == DRAG_NODE
                             && g_dragIndex == (int)g_path.nodes.size() - 1
                             && end_on_start();
    if (g_potentialClose || droppedOnStart) close_now(modifier);
    cancel_drag();
}

// --- Drawing ---

static void draw_node(int index)
{
    const Node& n = g_path.nodes[index];
    const int r  = 5;
    const int cx = (int)n.x, cy = (int)n.y;

    switch (n.type) {
    case NodeType::Smooth:
        setfillcolor(EGERGB(60, 120, 220));
        setlinecolor(EGERGB(60, 120, 220));
        fillcircle(cx, cy, r);
        break;
    case NodeType::Tangent: {
        int tri[6] = { cx, cy - r - 1,  cx - r - 1, cy + r,  cx + r + 1, cy + r };
        setfillcolor(EGERGB(230, 140, 20));
        setlinecolor(EGERGB(230, 140, 20));
        fillpoly(3, tri);
        break;
    }
    default:
        setfillcolor(EGERGB(220, 60, 60));
        setlinecolor(EGERGB(220, 60, 60));
        fillrect(cx - r, cy - r, cx + r, cy + r);
        break;
    }
    setlinecolor(EGERGB(0, 0, 0));
}

static void draw_bezier(double x0, double y0,
                        double x1, double y1,
                        double x2, double y2,
                        double x3, double y3)
{
    double prevX = x0, prevY = y0;
    for (int s = 1; s <= STEPS; ++s) {
        double t  = (double)s / STEPS;
        double mt = 1.0 - t;
        double a = mt * mt * mt;
        double b = 3.0 * mt * mt * t;
        double c = 3.0 * mt * t * t;
        double d = t * t * t;
        double x = a * x0 + b * x1 + c * x2 + d * x3;
        double y = a * y0 + b * y1 + c * y2 + d * y3;
        line((int)(prevX + 0.5), (int)(prevY + 0.5),
             (int)(x + 0.5),     (int)(y + 0.5));
        prevX = x;  prevY = y;
    }
}

static void draw_segment(const Node& a, const Node& b)
{
    draw_bezier(a.x, a.y,
                a.x + a.hx_out, a.y + a.hy_out,
                b.x + b.hx_in,  b.y + b.hy_in,
                b.x, b.y);
}

// Draws the handle with offset (hx, hy); a zero offset means "no handle".
static void draw_handle(const Node& n, double hx, double hy)
{
    if (hx == 0.0 && hy == 0.0) return;
    int tx = (int)(n.x + hx + 0.5);
    int ty = (int)(n.y + hy + 0.5);
    line((int)n.x, (int)n.y, tx, ty);
    setfillcolor(EGERGB(120, 200, 120));
    fillcircle(tx, ty, 3);
}

static void draw_help()
{
    setcolor(EGERGB(90, 90, 90));
    outtextxy(10, WIN_H - 80, "click: corner   shift+click: smooth   ctrl+click: tangent   (click start node to close, shift = modifier close)");
    outtextxy(10, WIN_H - 62, "or drag the end node onto the start node and release to close the loop (shift = modifier close)");
    outtextxy(10, WIN_H - 44, "C / S / T: turn node under cursor into corner / smooth / tangent   drag any handle to shape it");
    outtextxy(10, WIN_H - 26, "ctrl+drag a tangent: pull a handle   D: handles   R: release   1-7: examples   Enter: finish   Esc: clear");
    if (g_sceneName[0]) outtextxy(10, 10, g_sceneName);
}

static void redraw(int mouseX, int mouseY)
{
    cleardevice();
    setlinestyle(PS_SOLID, 2);
    setlinecolor(EGERGB(0, 0, 0));

    const std::vector<Node>& v = g_path.nodes;

    for (size_t i = 1; i < v.size(); ++i)
        draw_segment(v[i - 1], v[i]);

    if (g_path.close() != Close::Open && v.size() >= 2)
        draw_segment(v.back(), v.front());

    // Rubber band from the last node to the mouse.
    if (!g_finished && g_path.close() == Close::Open && !v.empty()) {
        setlinestyle(PS_DOT, 1);
        setlinecolor(EGERGB(150, 150, 150));
        line((int)v.back().x, (int)v.back().y, mouseX, mouseY);
        setlinestyle(PS_SOLID, 2);
        setlinecolor(EGERGB(0, 0, 0));
    }

    if (g_showHandles) {
        setlinestyle(PS_SOLID, 1);
        setlinecolor(EGERGB(120, 200, 120));
        for (size_t i = 0; i < v.size(); ++i) {
            draw_handle(v[i], v[i].hx_in,  v[i].hy_in);
            draw_handle(v[i], v[i].hx_out, v[i].hy_out);
        }
        setlinecolor(EGERGB(0, 0, 0));
    }

    for (size_t i = 0; i < v.size(); ++i)
        draw_node((int)i);

    draw_help();
}

// --- Main loop ---

static void handle_key(const key_msg& k)
{
    if (k.msg != key_msg_down) return;

    if (k.key == key_esc) {
        reset_path();
    }
    else if (k.key == key_enter) {
        if (!g_finished && g_path.close() == Close::Open) {
            g_finished = true;
        }
    }
    else if (k.key == 'D' || k.key == 'd') {
        g_showHandles = !g_showHandles;
    }
    else if (k.key == 'R' || k.key == 'r') {
        // Release all manual handles back to automatic.
        for (size_t i = 0; i < g_path.nodes.size(); ++i) {
            g_path.nodes[i].manual_in  = false;
            g_path.nodes[i].manual_out = false;
        }
        recompute();
    }
    else if (k.key == 'C' || k.key == 'c' || k.key == 'S' || k.key == 's'
             || k.key == 'T' || k.key == 't') {
        const int i = hit_node(g_mouseX, g_mouseY);
        if (i >= 0 && g_dragKind == DRAG_NONE) {
            const int key = k.key | 0x20;       // lower case
            convert_node(i, key == 'c' ? NodeType::Corner
                          : key == 's' ? NodeType::Smooth
                                       : NodeType::Tangent);
        }
    }
    else if (k.key >= '1' && k.key < '1' + bezigon::scenes::count) {
        load_scene(k.key - '1');
    }
}

int main()
{
    initgraph(WIN_W, WIN_H);
    setbkcolor(EGERGB(250, 250, 250));
    cleardevice();
    setwritemode(R2_COPYPEN);
    setcaption("Bezigon " BEZIGON_VERSION);

    while (is_run()) {
        // Drain the whole mouse queue each frame, so fast drags do
        // not lag behind the cursor.
        while (mousemsg()) {
            mouse_msg m = getmouse();
            g_mouseX = m.x;  g_mouseY = m.y;

            if (m.is_left() && m.is_down()) {
                start_press(m.x, m.y, type_from_keys());
            }
            else if (m.is_left() && m.is_up()) {
                finish_press(keystate(VK_SHIFT) != 0);
            }
            else if (m.is_right() && m.is_down()) {
                if (!g_finished && g_dragKind == DRAG_NONE
                    && g_path.close() == Close::Open) {
                    g_finished = true;
                }
            }
            else if (g_dragKind != DRAG_NONE) {
                continue_drag(m.x, m.y);
            }
        }

        // Drain the key queue too, so no keystroke is dropped.
        while (kbmsg()) handle_key(getkey());

        redraw(g_mouseX, g_mouseY);
        delay_ms(10);
    }

    closegraph();
    return 0;
}

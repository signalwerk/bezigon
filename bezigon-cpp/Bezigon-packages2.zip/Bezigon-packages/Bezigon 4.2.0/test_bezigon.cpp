// This file is part of Bezigon, released under the MIT License.
// See LICENSE for details.
//
// Diese Datei ist Teil von Bezigon und steht unter der MIT-Lizenz.
// Siehe LICENSE für Einzelheiten.

// test_bezigon.cpp
// Tests for bezigon.cpp. Needs only the C++ standard library.
//
//   g++ -std=c++11 -O1 -Wall -Wextra test_bezigon.cpp bezigon.cpp -o test_bezigon
//   ./test_bezigon                  run everything
//   ./test_bezigon --runs 200000    more random paths (default 20000)
//   ./test_bezigon --seed 7         different random paths (default 1)
//
// Exit code 0 means every check passed. Failures print the test name,
// the line and the failed expression.
//
// Groups:
//   1. Hand-worked cases       exact expectations for each node type.
//   2. FreeHand experiments    Tangent conversions and pulls, one test per
//                              experiment, in the order they were tried.
//   3. FreeHand measurements   the shield, measured from FreeHand itself.
//   4. Manual handles          dragging, mirroring, releasing.
//   5. Degenerate input        empty paths, coincident nodes, tiny paths.
//   6. Random properties       rules that must hold for every path.

#include "bezigon.h"
#include "demo_scenes.h"

#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <vector>

using namespace bezigon;

namespace {

const double K   = 0.39;       // the default handle fraction, written out
const double EPS = 1e-9;
const double PI  = 3.14159265358979323846;

const NodeType C = NodeType::Corner;
const NodeType S = NodeType::Smooth;
const NodeType T = NodeType::Tangent;

// ---------------------------------------------------------------- checks

int         g_checks   = 0;
int         g_failures = 0;
const char* g_test     = "";

void report(bool ok, const char* what, int line)
{
    ++g_checks;
    if (ok) return;
    ++g_failures;
    if (g_failures <= 40)
        std::printf("  FAIL [%s] line %d: %s\n", g_test, line, what);
}

#define CHECK(cond)           report((cond), #cond, __LINE__)
#define CHECK_NEAR(a, b, tol) report(std::fabs((a) - (b)) <= (tol), \
                                     #a " ~ " #b, __LINE__)

// ------------------------------------------------------- small utilities

struct Pt { double x, y; NodeType type; };

Path make_path(const std::vector<Pt>& pts, Close close = Close::Open)
{
    Path p;
    for (size_t i = 0; i < pts.size(); ++i) {
        p.nodes.push_back(make_node(pts[i].x, pts[i].y, pts[i].type));
    }
    if (close != Close::Open) close_path(p, close == Close::Modifier);
    compute_handles(p);
    return p;
}

double len_in(const Node& n)  { return std::hypot(n.hx_in,  n.hy_in);  }
double len_out(const Node& n) { return std::hypot(n.hx_out, n.hy_out); }
bool   has_in(const Node& n)  { return len_in(n)  > EPS; }
bool   has_out(const Node& n) { return len_out(n) > EPS; }

// True if the handle on that side of node i is the automatic straight one:
// it lies along the chord to node j, at the usual length. Such a side is
// drawn as a straight line. Indices are 0-based.
bool flat(const Path& p, int i, int j, bool isIn)
{
    const Node& n = p.nodes[i];
    const double hx = isIn ? n.hx_in : n.hx_out;
    const double hy = isIn ? n.hy_in : n.hy_out;
    return std::fabs(hx - K * (p.nodes[j].x - n.x)) < 1e-9
        && std::fabs(hy - K * (p.nodes[j].y - n.y)) < 1e-9;
}

double dist(const Path& p, int i, int j)
{
    return std::hypot(p.nodes[j].x - p.nodes[i].x, p.nodes[j].y - p.nodes[i].y);
}

// Cosine of the angle between two vectors; 0 if either is zero.
double cosine(double ax, double ay, double bx, double by)
{
    const double la = std::hypot(ax, ay), lb = std::hypot(bx, by);
    return (la < EPS || lb < EPS) ? 0.0 : (ax * bx + ay * by) / (la * lb);
}

// True if the vector points along the line from node i to node j.
bool points_at(const Path& p, int i, int j, double hx, double hy)
{
    return cosine(hx, hy, p.nodes[j].x - p.nodes[i].x,
                          p.nodes[j].y - p.nodes[i].y) > 1.0 - 1e-9;
}

bool all_finite(const Path& p)
{
    for (size_t i = 0; i < p.nodes.size(); ++i) {
        const Node& n = p.nodes[i];
        if (!std::isfinite(n.hx_in) || !std::isfinite(n.hy_in) ||
            !std::isfinite(n.hx_out) || !std::isfinite(n.hy_out)) return false;
    }
    return true;
}

bool same_handles(const Path& a, const Path& b, double tol)
{
    if (a.nodes.size() != b.nodes.size()) return false;
    for (size_t i = 0; i < a.nodes.size(); ++i) {
        const Node& p = a.nodes[i];
        const Node& q = b.nodes[i];
        if (std::fabs(p.hx_in  - q.hx_in)  > tol || std::fabs(p.hy_in  - q.hy_in)  > tol ||
            std::fabs(p.hx_out - q.hx_out) > tol || std::fabs(p.hy_out - q.hy_out) > tol)
            return false;
    }
    return true;
}

// Deterministic random numbers, identical on every platform.
struct Rng
{
    uint64_t s;
    explicit Rng(uint64_t seed) : s(seed * 0x9E3779B97F4A7C15ull + 1) {}
    uint64_t next()
    {
        s ^= s << 13;  s ^= s >> 7;  s ^= s << 17;
        return s;
    }
    double uniform(double lo, double hi)
    {
        return lo + (hi - lo) * ((next() >> 11) * (1.0 / 9007199254740992.0));
    }
    int below(int n) { return (int)(next() % (uint64_t)n); }
};

// A random path of n nodes, at least 25 apart so that nothing is near
// degenerate. Tangent nodes only if allowTangent.
Path random_path(Rng& rng, int n, bool allowTangent, Close close)
{
    Path p;
    while ((int)p.nodes.size() < n) {
        Node nd;
        nd.x = rng.uniform(0, 600);
        nd.y = rng.uniform(0, 600);
        bool clear = true;
        for (size_t i = 0; i < p.nodes.size(); ++i)
            if (std::hypot(p.nodes[i].x - nd.x, p.nodes[i].y - nd.y) < 25) clear = false;
        if (!clear) continue;
        const int r = rng.below(10);
        nd.type = r < 4 ? C : (r < 8 || !allowTangent) ? S : T;
        p.nodes.push_back(nd);
    }
    if (close != Close::Open) close_path(p, close == Close::Modifier);
    compute_handles(p);
    return p;
}

Close random_close(Rng& rng)
{
    const int r = rng.below(3);
    return r == 0 ? Close::Open : r == 1 ? Close::Plain : Close::Modifier;
}

// Distance between two nodes along the path (around the loop if closed).
int graph_distance(const Path& p, int i, int j)
{
    const int n = (int)p.nodes.size();
    const int d = std::abs(i - j);
    return (p.close() != Close::Open) ? (d < n - d ? d : n - d) : d;
}


// ===================================================== tests
// -------------------------------------------- Tangent: helpers

// The FreeHand experiments number nodes from 1, so these helpers do too.
void convert(Path& p, int node, NodeType t) { set_node_type(p, node - 1, t); }
Node&       N(Path& p, int node)       { return p.nodes[node - 1]; }
const Node& N(const Path& p, int node) { return p.nodes[node - 1]; }
double      D(const Path& p, int a, int b) { return dist(p, a - 1, b - 1); }

// Does the vector point from node `from` toward node `to`?
bool toward(const Path& p, int from, int to, double hx, double hy)
{
    return points_at(p, from - 1, to - 1, hx, hy);
}

// The node leaves both its segments straight: its handles lie along their
// chords, or, for a Tangent, there are none (a Tangent never bends a line).
// 1-based.
bool polygon_corner(const Path& p, int node)
{
    const int  i    = node - 1, n = (int)p.nodes.size();
    const bool loop = p.close() != Close::Open && n >= 2;
    const int  prev = i > 0     ? i - 1 : (loop ? n - 1 : -1);
    const int  next = i + 1 < n ? i + 1 : (loop ? 0     : -1);
    const bool tangent = p.nodes[i].type == NodeType::Tangent;

    const bool inOK  = (prev < 0 || tangent) ? !has_in(p.nodes[i])
                                             : flat(p, i, prev, true);
    const bool outOK = (next < 0 || tangent) ? !has_out(p.nodes[i])
                                             : flat(p, i, next, false);
    return inOK && outOK;
}

// handle_axis gives a direction for that side, running from node `from`
// toward node `to`.
bool axis_is(const Path& p, int node, bool isIn, int from, int to)
{
    double ax, ay;
    return handle_axis(p, node - 1, isIn, ax, ay) && toward(p, from, to, ax, ay);
}

bool no_axis(const Path& p, int node, bool isIn)
{
    double ax, ay;
    return !handle_axis(p, node - 1, isIn, ax, ay);
}

// The handles of one node are identical in both paths.
bool same_node(const Path& a, const Path& b, int node)
{
    const Node& p = N(a, node);
    const Node& q = N(b, node);
    return p.hx_in == q.hx_in && p.hy_in == q.hy_in
        && p.hx_out == q.hx_out && p.hy_out == q.hy_out;
}

// FreeHand's closed four-node shape: 1 and 4 are corners along the top,
// 2 and 3 are smooth along the bottom. Closed with a plain click.
Path closed_shape()
{
    return make_path({{100,100,C},{110,400,S},{450,380,S},{520,100,C}}, Close::Plain);
}

// FreeHand's open path PC MC MC MC.
Path open_shape()
{
    return make_path({{50,300,C},{250,120,S},{500,250,S},{750,100,S}});
}

// Five smooth nodes in a ring, closed with a plain click.
Path smooth_ring()
{
    return make_path({{400,100,S},{590,238,S},{517,462,S},{283,462,S},{210,238,S}},
                     Close::Plain);
}

// -------------------------------------------- Tangent: hand-worked cases

void test_tangent_between_sharp_neighbours_is_a_polygon_corner()
{
    // Toward a Corner or a Tangent the segment stays straight, so a Tangent
    // between two sharp neighbours has no handles at all.
    const Path open = make_path({{0,0,C},{100,0,T},{200,80,T},{300,80,C}});
    for (int n = 1; n <= 4; ++n) CHECK(polygon_corner(open, n));

    const Path loop = make_path({{0,0,C},{100,0,T},{100,100,C},{0,100,T}}, Close::Plain);
    for (int n = 1; n <= 4; ++n) CHECK(polygon_corner(loop, n));
}

void test_tangent_between_smooth_neighbours_is_a_notch()
{
    // Each handle continues the chord on the other side of the node.
    Path p = smooth_ring();
    convert(p, 3, T);
    const Node& t = N(p, 3);
    CHECK(has_in(t) && has_out(t));
    CHECK(toward(p, 2, 3, t.hx_out, t.hy_out));          // out continues the chord from node 2
    CHECK(toward(p, 4, 3, t.hx_in,  t.hy_in));           // in continues the chord from node 4
    CHECK_NEAR(len_out(t), K * D(p, 3, 4), 1e-9);        // each is K times its own segment
    CHECK_NEAR(len_in(t),  K * D(p, 2, 3), 1e-9);
    CHECK(cosine(t.hx_in, t.hy_in, t.hx_out, t.hy_out) > -0.9);   // not collinear: a notch
}

void test_tangent_at_open_ends()
{
    // An end node has no chord on its other side, so its handle points
    // along the chord to its one neighbour.
    Path p = make_path({{0,0,T},{100,80,S},{200,0,S}});
    CHECK(has_out(N(p, 1)) && !has_in(N(p, 1)));
    CHECK(toward(p, 1, 2, N(p, 1).hx_out, N(p, 1).hy_out));
    CHECK_NEAR(len_out(N(p, 1)), K * D(p, 1, 2), 1e-9);

    p = make_path({{0,0,S},{100,80,S},{200,0,T}});       // mirror image
    CHECK(has_in(N(p, 3)) && !has_out(N(p, 3)));
    CHECK(toward(p, 3, 2, N(p, 3).hx_in, N(p, 3).hy_in));
    CHECK_NEAR(len_in(N(p, 3)), K * D(p, 2, 3), 1e-9);

    // Beside a Corner or another Tangent the segment stays straight.
    p = make_path({{0,0,T},{100,0,C},{200,100,S}});
    CHECK(polygon_corner(p, 1));
    CHECK(flat(p, 1, 0, true) && has_out(N(p, 2)));      // the corner continues the curve after it
    p = make_path({{0,0,T},{100,50,T}});
    CHECK(polygon_corner(p, 1) && polygon_corner(p, 2));
}

void test_tangent_ignores_coincident_neighbour()
{
    // A neighbour on top of the node cannot give a direction, so the node
    // is treated as an end: it points at its one real neighbour.
    const Path p = make_path({{100,100,C},{100,100,T},{300,150,S},{400,100,S}});
    CHECK(all_finite(p));
    CHECK(!has_in(N(p, 2)) && has_out(N(p, 2)));
    CHECK(toward(p, 2, 3, N(p, 2).hx_out, N(p, 2).hy_out));
}

void test_tangent_beside_modifier_start()
{
    // The start node of a modifier-closed path acts as a corner, so the
    // edge from it to a Tangent stays straight and the curve leaves along it.
    const Path p = make_path({{0,0,S},{100,0,T},{200,60,S},{150,160,S},{50,160,S}},
                             Close::Modifier);
    CHECK(p.nodes[0].type == C);
    CHECK(!has_in(N(p, 2)));
    CHECK(has_out(N(p, 2)));
    CHECK(toward(p, 1, 2, N(p, 2).hx_out, N(p, 2).hy_out));
}

void test_handle_axis_contract()
{
    double ax = 7, ay = 7;
    const Path p = make_path({{0,0,C},{100,0,S},{200,80,T},{300,0,S}});
    CHECK(!handle_axis(p, 0, false, ax, ay));            // Corner
    CHECK(!handle_axis(p, 1, false, ax, ay));            // Smooth
    CHECK(!handle_axis(p, -1, false, ax, ay));
    CHECK(!handle_axis(p, 4, false, ax, ay));
    CHECK(handle_axis(p, 2, false, ax, ay));             // Tangent
    CHECK_NEAR(std::hypot(ax, ay), 1.0, 1e-12);          // a unit vector
    CHECK(axis_is(p, 3, false, 2, 3));                   // out continues the chord from 2
    CHECK(axis_is(p, 3, true,  4, 3));                   // in continues the chord from 4

    // An end node: toward its neighbour on the inner side, away from it beyond the end.
    const Path e = make_path({{0,0,T},{100,80,S},{200,0,S}});
    CHECK(axis_is(e, 1, false, 1, 2));
    CHECK(axis_is(e, 1, true,  2, 1));

    // Both sides can be pulled even between two sharp nodes.
    const Path d = make_path({{0,0,C},{100,0,T},{200,50,C}});
    CHECK(axis_is(d, 2, false, 1, 2) && axis_is(d, 2, true, 3, 2));

    // A neighbour on top of the node counts as absent.
    const Path c = make_path({{100,0,C},{100,0,T},{200,50,C}});
    CHECK(axis_is(c, 2, true, 3, 2) && axis_is(c, 2, false, 2, 3));

    // A node with no neighbour at all has no direction.
    const Path lone = make_path({{5,5,T}});
    CHECK(no_axis(lone, 1, false) && no_axis(lone, 1, true));

    // After a modifier close the start node is a Corner, whatever it was placed as.
    const Path q = make_path({{0,0,T},{100,0,S},{100,100,S},{0,100,S}}, Close::Modifier);
    CHECK(!handle_axis(q, 0, false, ax, ay));
}

// ---------------------------- Tangent nodes placed directly (measured)
// Coordinates read off FreeHand screenshots, so lengths agree to a few pixels.

void test_directly_placed_tangent_has_its_handle()
{
    // PC, TN, MC, MC, closed on the first. The tangent's handle goes toward
    // the smooth node, continuing the edge from the corner. Measured: 258 px.
    Path p = make_path({{954,111,C},{348,407,T},{954,673,S},{1342,273,S}}, Close::Plain);
    CHECK(!has_in(N(p, 2)) && has_out(N(p, 2)));
    CHECK(toward(p, 1, 2, N(p, 2).hx_out, N(p, 2).hy_out));
    CHECK_NEAR(len_out(N(p, 2)), 258.0, 3.0);

    // TN TN TN MC, closed. Only the two tangents beside the smooth node have
    // a handle (measured 124 and 121 px); the one between two tangents has none.
    p = make_path({{475,204,T},{177,379,T},{465,531,T},{739,383,S}}, Close::Plain);
    CHECK(has_in(N(p, 1)) && !has_out(N(p, 1)));
    CHECK(toward(p, 2, 1, N(p, 1).hx_in, N(p, 1).hy_in));
    CHECK_NEAR(len_in(N(p, 1)), 124.0, 3.0);
    CHECK(has_out(N(p, 3)) && !has_in(N(p, 3)));
    CHECK(toward(p, 2, 3, N(p, 3).hx_out, N(p, 3).hy_out));
    CHECK_NEAR(len_out(N(p, 3)), 121.0, 3.0);
    CHECK(polygon_corner(p, 2));

    // TN, MC, TN, modifier close. The start node becomes a corner with
    // handles straight at its neighbours (152 and 158 px). The last node's
    // handle goes toward the smooth node, along the line from the start node
    // (161 px); toward the start node there is none.
    p = make_path({{477,122,T},{143,352,S},{523,511,T}}, Close::Modifier);
    CHECK(p.nodes[0].type == C);
    CHECK(points_at(p, 0, 2, N(p, 1).hx_in,  N(p, 1).hy_in));
    CHECK(points_at(p, 0, 1, N(p, 1).hx_out, N(p, 1).hy_out));
    CHECK_NEAR(len_in(N(p, 1)),  152.0, 3.0);
    CHECK_NEAR(len_out(N(p, 1)), 158.0, 3.0);
    CHECK(has_in(N(p, 3)) && !has_out(N(p, 3)));
    CHECK(toward(p, 1, 3, N(p, 3).hx_in, N(p, 3).hy_in));
    CHECK_NEAR(len_in(N(p, 3)), 161.0, 3.0);
}

void test_wave_with_tangents()
{
    // TN, MC, TN, MC (open). The first tangent points at node 2; the middle
    // one has two handles that make a notch (measured 134 and 128 px).
    const Path p = bezigon::scenes::build(bezigon::scenes::all[6]);
    CHECK(has_out(N(p, 1)) && !has_in(N(p, 1)));
    CHECK(toward(p, 1, 2, N(p, 1).hx_out, N(p, 1).hy_out));
    CHECK_NEAR(len_out(N(p, 1)), K * D(p, 1, 2), 1e-9);
    CHECK(toward(p, 2, 3, N(p, 3).hx_out, N(p, 3).hy_out));
    CHECK(toward(p, 4, 3, N(p, 3).hx_in,  N(p, 3).hy_in));
    CHECK_NEAR(len_in(N(p, 3)),  134.0, 3.0);
    CHECK_NEAR(len_out(N(p, 3)), 128.0, 3.0);
    CHECK(cosine(N(p, 3).hx_in, N(p, 3).hy_in, N(p, 3).hx_out, N(p, 3).hy_out) > -0.9);

    // The same wave from another drawing: the first handle measured 146 px.
    const Path w = make_path({{67,348,T},{409,194,S},{723,387,T},{1045,205,S}});
    CHECK_NEAR(len_out(N(w, 1)), 146.0, 3.0);

    // Ending on a tangent: its handle points back at the smooth node (110 px).
    const Path q = make_path({{55,335,S},{365,170,S},{672,355,S},{903,195,T}});
    CHECK(has_in(N(q, 4)) && !has_out(N(q, 4)));
    CHECK(toward(q, 4, 3, N(q, 4).hx_in, N(q, 4).hy_in));
    CHECK_NEAR(len_in(N(q, 4)), 110.0, 3.0);
}

// ------------------------- A Tangent follows the curve of its neighbour

void test_cusp_straightens_its_own_sides()
{
    // Corner, Smooth, Smooth, Tangent, closed: the Tangent's handle goes to
    // the smooth node 3 and continues the edge from the corner.
    Path p = make_path({{384,56,C},{577,185,S},{414,319,S},{146,246,T}}, Close::Plain);
    CHECK(has_in(N(p, 4)) && !has_out(N(p, 4)));
    CHECK(toward(p, 1, 4, N(p, 4).hx_in, N(p, 4).hy_in));
    CHECK_NEAR(len_in(N(p, 4)), K * D(p, 3, 4), 1e-9);
    const Path smooth = p;

    // Node 3 becomes a cusp, so both its handles lie along their chords and
    // its end of each segment is straight. The segment to the Tangent is then
    // straight at both ends, and the Tangent drops its handle: it never bends
    // a straight segment.
    convert(p, 3, C);
    CHECK(flat(p, 2, 1, true) && flat(p, 2, 3, false));
    CHECK(segment_is_straight(p, 2));
    CHECK(!has_in(N(p, 4)) && !has_out(N(p, 4)));
    // The other side still curves, because node 2 is still smooth.
    CHECK(!segment_is_straight(p, 1));

    convert(p, 3, S);                                    // and back again, exactly
    CHECK(same_handles(p, smooth, 1e-12));
}

void test_tangent_follows_whether_its_segment_is_curved()
{
    // Node 3 is a plain corner: the segment to the Tangent is straight.
    Path p = make_path({{384,56,C},{577,185,S},{414,319,C},{146,246,T}}, Close::Plain);
    CHECK(polygon_corner(p, 4));

    // Smooth makes the segment curved, so the Tangent has its handle; back to
    // a plain corner, and the segment and the handle are gone.
    convert(p, 3, S);
    CHECK(has_in(N(p, 4)));
    convert(p, 3, C);
    CHECK(polygon_corner(p, 4));

    // A handle dragged out of the corner toward the Tangent curves the segment,
    // and the Tangent matches it. A handle on the other side does not.
    drag_handle(p, 2, true, N(p, 3).x + 60, N(p, 3).y - 40);
    CHECK(polygon_corner(p, 4));
    drag_handle(p, 2, false, N(p, 3).x - 90, N(p, 3).y + 20);
    CHECK(has_in(N(p, 4)));
    CHECK_NEAR(len_in(N(p, 4)), K * D(p, 3, 4), 1e-9);
    CHECK(toward(p, 1, 4, N(p, 4).hx_in, N(p, 4).hy_in));

    // The same between two tangents: a handle pulled on one makes the other
    // match it on that segment.
    p = closed_shape();
    convert(p, 2, T);  convert(p, 3, T);
    CHECK(polygon_corner(p, 3));
    drag_handle(p, 1, false, N(p, 2).x + 70, N(p, 2).y - 20);
    CHECK(has_in(N(p, 3)) && !N(p, 3).manual_in);
    CHECK(toward(p, 4, 3, N(p, 3).hx_in, N(p, 3).hy_in));
    CHECK_NEAR(len_in(N(p, 3)), K * D(p, 2, 3), 1e-9);
}

// -------------------------------------------- Converting node types

// A node is only ever a cusp by conversion, never by its click.
void test_make_node_is_never_a_cusp()
{
    CHECK(!make_node(0, 0, C).cusp);
    CHECK(!make_node(0, 0, S).cusp);
    CHECK(!make_node(0, 0, T).cusp);
}

void test_set_node_type_ignores_same_type_and_bad_index()
{
    Path p = make_path({{0,0,C},{100,40,S},{200,0,C}});
    drag_handle(p, 1, false, 150, 60);
    const Path before = p;
    convert(p, 2, S);
    set_node_type(p, -1, T);
    set_node_type(p, 99, T);
    CHECK(same_handles(p, before, 0.0));
    CHECK(N(p, 2).manual_out);
}

void test_converting_to_smooth_or_tangent_resets_the_handles()
{
    // Dragged, unequal handles on a smooth node: converting releases them.
    Path p = make_path({{0,0,C},{100,0,S},{200,80,C}});
    drag_handle(p, 1, false, 170, 30);
    CHECK(N(p, 2).manual_in && N(p, 2).manual_out);
    convert(p, 2, T);
    CHECK(!N(p, 2).manual_in && !N(p, 2).manual_out);
    CHECK(polygon_corner(p, 2));                             // a tangent between two corners

    // Back to smooth: the automatic, collinear handles.
    convert(p, 2, S);
    CHECK_NEAR(len_in(N(p, 2)),  K * D(p, 1, 2), 1e-9);
    CHECK_NEAR(len_out(N(p, 2)), K * D(p, 2, 3), 1e-9);
    CHECK_NEAR(cosine(N(p, 2).hx_in, N(p, 2).hy_in, N(p, 2).hx_out, N(p, 2).hy_out), -1.0, 1e-9);

    // A cusp (a corner with dragged handles) is reset the same way.
    p = make_path({{0,0,C},{100,0,C},{200,80,C}});
    drag_handle(p, 1, false, 150, 40);
    CHECK(N(p, 2).manual_out);
    convert(p, 2, S);
    CHECK(!N(p, 2).manual_in && !N(p, 2).manual_out);
    CHECK(has_in(N(p, 2)) && has_out(N(p, 2)));
}

// The start node of a path closed with the modifier is a Corner. It can be
// turned into a Smooth or Tangent node, and turning it back to a Corner gives
// exactly what the close made, as Xara does.
void test_modifier_start_node_toggles_back_to_what_the_close_made()
{
    const std::vector<Pt> pts = {{190,40,S},{340,150,S},{190,250,S},{40,150,S},{100,70,S}};
    const Path closed = make_path(pts, Close::Modifier);
    CHECK(closed.nodes[0].type == C);
    CHECK(has_in(closed.nodes[0]) && has_out(closed.nodes[0]));       // the two inward handles

    // To Smooth: the same shape as if it had been closed with a plain click.
    Path p = closed;
    convert(p, 1, S);
    CHECK(p.nodes[0].type == S);
    CHECK(same_handles(p, make_path(pts, Close::Plain), 1e-12));
    convert(p, 1, C);                                  // and back, exactly
    CHECK(p.nodes[0].type == C);
    CHECK(same_handles(p, closed, 1e-12));
    CHECK(!p.nodes[0].manual_in && !p.nodes[0].manual_out);

    // To Tangent and back.
    p = closed;
    convert(p, 1, T);
    CHECK(p.nodes[0].type == T);
    Path plain = make_path(pts, Close::Plain);
    convert(plain, 1, T);
    CHECK(same_handles(p, plain, 1e-12));
    convert(p, 1, C);
    CHECK(same_handles(p, closed, 1e-12));

    // Smooth, then Tangent, then Corner: still the original.
    p = closed;
    convert(p, 1, S);
    convert(p, 1, T);
    convert(p, 1, C);
    CHECK(same_handles(p, closed, 1e-12));

    // Already a Corner: nothing happens.
    p = closed;
    convert(p, 1, C);
    CHECK(same_handles(p, closed, 1e-12));

    // A start node created as a Corner, made smooth and then a Corner again,
    // is a cusp: the same as the start node created smooth.
    std::vector<Pt> sharp = pts;
    sharp[0].type = C;
    p = make_path(sharp, Close::Modifier);
    convert(p, 1, S);
    convert(p, 1, C);
    CHECK(same_handles(p, closed, 1e-12));

    // The close itself is never changed by a conversion.
    CHECK(p.close() == Close::Modifier);
}

// Xara: a node made smooth and then a cusp lands on its chords, whatever its
// handles were before. The shape it had as a Tangent, or as a cusp the user
// dragged, is already gone at the smoothing step and does not come back.
void test_smooth_to_cusp_lies_along_the_chords()
{
    // A Tangent between smooth nodes: its handles point outward, a notch.
    Path p = make_path({{350,90,S},{70,325,S},{350,475,S},{650,312,T}}, Close::Plain);
    const Path tangent = p;
    CHECK(cosine(N(p, 4).hx_in, N(p, 4).hy_in, 70 - 650, 325 - 312) < 0.0);   // outward

    convert(p, 4, S);
    convert(p, 4, C);
    CHECK(flat(p, 3, 2, true) && flat(p, 3, 0, false));      // both on their chords
    CHECK(!N(p, 4).manual_in && !N(p, 4).manual_out);
    CHECK(!same_node(p, tangent, 4));                        // not the Tangent's notch

    // Straight to a cusp instead, the Tangent's own handles do survive.
    p = tangent;
    convert(p, 4, C);
    CHECK(same_node(p, tangent, 4));

    // A cusp the user shaped: smoothing discards the shape, so the cusp after
    // it is the chord default, not what was dragged.
    p = make_path({{0,0,C},{100,0,S},{200,80,S},{300,0,S}});
    convert(p, 3, C);
    drag_handle(p, 2, false, 260, 150);
    drag_handle(p, 2, true, 140, 150);
    const Path shaped = p;
    convert(p, 3, S);
    CHECK(!same_node(p, shaped, 3));
    convert(p, 3, C);
    CHECK(!same_node(p, shaped, 3));
    CHECK(flat(p, 2, 1, true) && flat(p, 2, 3, false));

    // A node created as a Corner continues a smooth neighbour's arc. Made
    // smooth and then a Corner again, it is a cusp on its chords like any other.
    p = make_path({{0,0,C},{100,0,C},{200,80,S},{300,0,S}});
    const Path sharp = p;
    convert(p, 2, S);
    convert(p, 2, C);
    CHECK(!same_node(p, sharp, 2));
    CHECK(flat(p, 1, 0, true) && flat(p, 1, 2, false));
}

void test_node_drawn_sharp_toggles_between_smooth_and_cusp()
{
    // Corner -> Smooth -> Corner leaves a cusp, however often it is repeated.
    // Between corners a cusp and a plain corner look the same: nothing to follow.
    Path p = make_path({{0,0,C},{100,0,C},{200,80,C},{300,0,C}});
    const Path start = p;
    for (int k = 0; k < 3; ++k) {
        convert(p, 2, S);
        CHECK(has_in(N(p, 2)) && has_out(N(p, 2)));
        convert(p, 2, C);
        CHECK(same_handles(p, start, 0.0));
        CHECK(!N(p, 2).manual_in && !N(p, 2).manual_out);
    }

    // Handles dragged out before the first conversion do not come back.
    drag_handle(p, 1, false, 150, 40);
    convert(p, 2, S);
    convert(p, 2, C);
    CHECK(!N(p, 2).manual_in && !N(p, 2).manual_out);
    CHECK(same_handles(p, start, 0.0));

    // Through a Tangent beside a smooth node: a cusp that keeps the Tangent's
    // handle, not the plain corner it was drawn as.
    p = make_path({{0,0,C},{100,0,C},{200,80,S},{300,0,S}});
    const Path before = p;
    convert(p, 2, T);
    CHECK(has_out(N(p, 2)));                             // placed or converted, a tangent has its handle
    const Node tangent = N(p, 2);
    convert(p, 2, C);
    CHECK(N(p, 2).cusp);
    CHECK(N(p, 2).hx_out == tangent.hx_out && N(p, 2).hy_out == tangent.hy_out);
    CHECK(!same_node(p, before, 2));
}

void test_node_born_curved_toggles_between_smooth_and_cusp()
{
    Path p = make_path({{0,0,C},{100,40,S},{200,0,C}});
    const Path smooth = p;
    for (int k = 0; k < 3; ++k) {
        // To a corner: a cusp, with both handles along their chords.
        convert(p, 2, C);
        CHECK(flat(p, 1, 0, true) && flat(p, 1, 2, false));
        CHECK(!N(p, 2).manual_in && !N(p, 2).manual_out);
        // Back to smooth: collinear automatic handles again.
        convert(p, 2, S);
        CHECK(same_handles(p, smooth, 1e-12));
    }

    // Once a cusp, each handle moves on its own.
    convert(p, 2, C);
    const Node before = N(p, 2);
    drag_handle(p, 2, false, 150, 90);
    CHECK(N(p, 2).hx_in == before.hx_in && N(p, 2).hy_in == before.hy_in);
    CHECK(cosine(N(p, 2).hx_in, N(p, 2).hy_in, N(p, 2).hx_out, N(p, 2).hy_out) > -0.99);

    // A node born as a Tangent keeps its handle as a cusp, and the side it
    // had none on gets one along its chord.
    p = make_path({{0,0,C},{100,0,T},{200,80,S},{300,0,S}});
    const Path tangent = p;
    convert(p, 2, C);
    CHECK(N(p, 2).hx_out == N(tangent, 2).hx_out
       && N(p, 2).hy_out == N(tangent, 2).hy_out);      // the Tangent's own handle
    CHECK(flat(p, 1, 0, true));                         // the blank side, now straight
    convert(p, 2, T);
    CHECK(same_handles(p, tangent, 1e-12));
}

// A cusp owns both its handles. The side it had none on is given one along
// its chord, and neither side moves when a neighbouring Tangent is pulled.
// (Before, the blank side grew a handle of its own and the segment looped.)
void test_cusp_keeps_both_handles_when_a_neighbour_is_pulled()
{
    // Tangent, corner, smooth, tangent; closed. The last node has an
    // in-handle only, until it becomes a cusp.
    Path p = make_path({{190,237,T},{594,69,C},{723,184,S},{590,278,T}}, Close::Plain);
    CHECK(has_in(N(p, 4)) && !has_out(N(p, 4)));
    convert(p, 4, C);
    CHECK(has_in(N(p, 4)) && flat(p, 3, 0, false));     // blank side filled along the chord
    const Node cusp = N(p, 4);

    // Pull the handle of the first Tangent that faces the cusp.
    double ax, ay;
    CHECK(handle_axis(p, 0, true, ax, ay));
    drag_handle(p, 0, true, 190 + ax * 66, 237 + ay * 66);
    CHECK(N(p, 4).hx_in  == cusp.hx_in  && N(p, 4).hy_in  == cusp.hy_in);
    CHECK(N(p, 4).hx_out == cusp.hx_out && N(p, 4).hy_out == cusp.hy_out);
}

// ------------------------------------ FreeHand experiments (see the notes)
// Each test is something tried in FreeHand. The directions are FreeHand's.
// Where FreeHand showed no handle yet because the node was a corner a moment
// ago, 3.2.0 shows it at once, exactly as for a tangent placed directly.

void test_freehand_closed_convert_one_node()
{
    // Convert 2: curve toward 3, following 1, the corner.
    Path p = closed_shape();
    convert(p, 2, T);
    CHECK(!has_in(N(p, 2)));
    CHECK(has_out(N(p, 2)) && toward(p, 1, 2, N(p, 2).hx_out, N(p, 2).hy_out));
    CHECK_NEAR(len_out(N(p, 2)), K * D(p, 2, 3), 1e-9);

    // Convert 3 alone: it follows 4, the corner, and not 2.
    p = closed_shape();
    convert(p, 3, T);
    CHECK(!has_out(N(p, 3)));
    CHECK(has_in(N(p, 3)) && toward(p, 4, 3, N(p, 3).hx_in, N(p, 3).hy_in));
    CHECK_NEAR(len_in(N(p, 3)), K * D(p, 2, 3), 1e-9);

    // Convert 1 first: it follows 4, the closest sharp node.
    p = closed_shape();
    convert(p, 1, T);
    CHECK(has_out(N(p, 1)) && !has_in(N(p, 1)));
    CHECK(toward(p, 4, 1, N(p, 1).hx_out, N(p, 1).hy_out));

    // Convert 4 first: it follows 1.
    p = closed_shape();
    convert(p, 4, T);
    CHECK(has_in(N(p, 4)) && !has_out(N(p, 4)));
    CHECK(toward(p, 1, 4, N(p, 4).hx_in, N(p, 4).hy_in));
}

void test_freehand_closed_convert_two_nodes()
{
    // Convert 2, then 3: the shape collapses to a polygon with 2 and 3 as
    // tangents without handles. Pulled, 2 follows 1 and 3 follows 2.
    Path p = closed_shape();
    convert(p, 2, T);
    convert(p, 3, T);
    for (int n = 1; n <= 4; ++n) CHECK(polygon_corner(p, n));
    CHECK(axis_is(p, 2, false, 1, 2));
    CHECK(axis_is(p, 3, false, 2, 3));

    // Pull 3's handle. It stays on the line from 2 and its length follows the drag.
    drag_handle(p, 2, false, N(p, 3).x + 80, N(p, 3).y + 30);
    CHECK(toward(p, 2, 3, N(p, 3).hx_out, N(p, 3).hy_out));
    CHECK_NEAR(len_out(N(p, 3)), std::hypot(80, 30), 1e-9);
    CHECK(N(p, 3).manual_out);
    CHECK(has_in(N(p, 4)));                              // the corner 4 continues the new curve

    // Convert 3, then 4: 4 follows 3.
    p = closed_shape();
    convert(p, 3, T);
    convert(p, 4, T);
    CHECK(polygon_corner(p, 4));
    CHECK(axis_is(p, 4, false, 3, 4));
}

void test_freehand_closed_convert_all_in_any_order()
{
    // All four tangents: a polygon, and each node follows the previous one.
    int order[4] = {1, 2, 3, 4};
    std::vector<Path> results;
    do {
        Path p = closed_shape();
        for (int k = 0; k < 4; ++k) convert(p, order[k], T);
        for (int n = 1; n <= 4; ++n) {
            CHECK(polygon_corner(p, n));
            CHECK(axis_is(p, n, false, n == 1 ? 4 : n - 1, n));
        }
        results.push_back(p);
    } while (std::next_permutation(order, order + 4));
    for (size_t k = 1; k < results.size(); ++k)
        CHECK(same_handles(results[0], results[k], 0.0));    // the order does not matter
}

void test_freehand_open_convert_one_node()
{
    // Last node: its handle goes back toward the previous node.
    Path p = open_shape();
    convert(p, 4, T);
    CHECK(has_in(N(p, 4)) && !has_out(N(p, 4)));
    CHECK(toward(p, 4, 3, N(p, 4).hx_in, N(p, 4).hy_in));

    // First node: its handle goes toward the second.
    p = open_shape();
    convert(p, 1, T);
    CHECK(has_out(N(p, 1)) && !has_in(N(p, 1)));
    CHECK(toward(p, 1, 2, N(p, 1).hx_out, N(p, 1).hy_out));

    // Second node: follows 1, and the curve toward 3 stays.
    p = open_shape();
    convert(p, 2, T);
    CHECK(!has_in(N(p, 2)));
    CHECK(has_out(N(p, 2)) && toward(p, 1, 2, N(p, 2).hx_out, N(p, 2).hy_out));

    // Third node first: two handles, each continuing the opposite chord.
    p = open_shape();
    convert(p, 3, T);
    CHECK(toward(p, 2, 3, N(p, 3).hx_out, N(p, 3).hy_out));
    CHECK(toward(p, 4, 3, N(p, 3).hx_in,  N(p, 3).hy_in));
    CHECK_NEAR(len_out(N(p, 3)), K * D(p, 3, 4), 1e-9);
    CHECK_NEAR(len_in(N(p, 3)),  K * D(p, 2, 3), 1e-9);
}

void test_freehand_open_convert_third_then_second()
{
    Path p = open_shape();
    convert(p, 3, T);
    convert(p, 2, T);
    CHECK(!has_in(N(p, 3)));                             // the left handle is gone
    CHECK(has_out(N(p, 3)));                             // the right one stays
    CHECK(!has_out(N(p, 2)));                            // and 2 has none toward 3
    CHECK(axis_is(p, 3, true, 4, 3));                    // drawn out, it follows the last node
    drag_handle(p, 2, true, N(p, 3).x - 120, N(p, 3).y + 40);
    CHECK(toward(p, 4, 3, N(p, 3).hx_in, N(p, 3).hy_in));
    CHECK_NEAR(len_in(N(p, 3)), std::hypot(120, 40), 1e-9);
}

void test_freehand_open_convert_all()
{
    // 1 and 2 first, then 3 and 4: a polygon. Each node's handle follows
    // the previous node, except the first, which follows the second.
    Path p = open_shape();
    convert(p, 1, T);  convert(p, 2, T);  convert(p, 3, T);  convert(p, 4, T);
    for (int n = 1; n <= 4; ++n) CHECK(polygon_corner(p, n));
    CHECK(axis_is(p, 1, false, 1, 2));
    CHECK(axis_is(p, 2, false, 1, 2));
    CHECK(axis_is(p, 3, false, 2, 3));
    CHECK(axis_is(p, 4, false, 3, 4));
}

void test_freehand_circle_of_four_tangents()
{
    // Four smooth nodes on a circle. Converting one gives a notch.
    const double R = 200, cx = 300, cy = 300;
    Path p = make_path({{cx, cy - R, S}, {cx + R, cy, S}, {cx, cy + R, S}, {cx - R, cy, S}},
                       Close::Plain);
    convert(p, 1, T);
    CHECK(has_in(N(p, 1)) && has_out(N(p, 1)));
    CHECK(toward(p, 4, 1, N(p, 1).hx_out, N(p, 1).hy_out));
    CHECK(toward(p, 2, 1, N(p, 1).hx_in,  N(p, 1).hy_in));
    CHECK(N(p, 1).hy_out < 0 && N(p, 1).hy_in < 0);      // both point up: it sits in a dip

    // Convert all four. FreeHand keeps the circle's own handles and shows four
    // notches. 3.2.0 resets them, and a tangent has no automatic handle toward
    // another tangent, so the circle becomes a square until handles are pulled.
    for (int n = 2; n <= 4; ++n) convert(p, n, T);
    for (int n = 1; n <= 4; ++n) CHECK(polygon_corner(p, n));
    drag_handle(p, 0, false, N(p, 1).x, N(p, 1).y - 60);
    CHECK(toward(p, 4, 1, N(p, 1).hx_out, N(p, 1).hy_out));
}

// ------------------------------------------- pulling Tangent handles

void test_pull_either_side_of_a_tangent_between_sharp_nodes()
{
    Path p = closed_shape();
    convert(p, 2, T);  convert(p, 3, T);
    CHECK(polygon_corner(p, 2));
    drag_handle(p, 1, true, N(p, 2).x - 50, N(p, 2).y - 50);
    CHECK(N(p, 2).manual_in && !N(p, 2).manual_out);
    CHECK(toward(p, 3, 2, N(p, 2).hx_in, N(p, 2).hy_in));
    CHECK_NEAR(len_in(N(p, 2)), std::hypot(50, 50), 1e-9);
}

void test_pull_where_there_is_no_direction_is_ignored()
{
    Path p = make_path({{5,5,T}});                       // no neighbour to take a direction from
    const Path before = p;
    drag_handle(p, 0, false, 50, 50);
    CHECK(same_handles(p, before, 0.0));
    CHECK(!N(p, 1).manual_out);
}

void test_pulling_back_to_the_node_removes_the_handle()
{
    Path p = open_shape();
    convert(p, 4, T);
    drag_handle(p, 3, false, N(p, 4).x + 100, N(p, 4).y);       // beyond the end
    CHECK(has_out(N(p, 4)) && N(p, 4).manual_out);
    drag_handle(p, 3, false, N(p, 4).x, N(p, 4).y);              // tip back on the node
    CHECK(!has_out(N(p, 4)));
    CHECK(!N(p, 4).manual_out);
}

void test_pulling_one_handle_leaves_the_other_automatic()
{
    // A Tangent between two smooth nodes has both handles on its own. Pulling
    // one changes that one only; the other still follows the rule.
    Path p = smooth_ring();
    convert(p, 3, T);
    const double inLen = len_in(N(p, 3));
    CHECK(has_in(N(p, 3)) && has_out(N(p, 3)));
    drag_handle(p, 2, false, N(p, 3).x + 150, N(p, 3).y);
    CHECK(N(p, 3).manual_out && !N(p, 3).manual_in);
    CHECK_NEAR(len_out(N(p, 3)), 150.0, 1e-9);
    CHECK_NEAR(len_in(N(p, 3)), inLen, 1e-9);
}

void test_pull_handle_beyond_an_open_end()
{
    Path p = open_shape();
    convert(p, 4, T);
    drag_handle(p, 3, false, N(p, 4).x + 60, N(p, 4).y - 100);     // anywhere: only the length counts
    CHECK(toward(p, 3, 4, N(p, 4).hx_out, N(p, 4).hy_out));
    CHECK_NEAR(len_out(N(p, 4)), std::hypot(60, 100), 1e-9);

    p = open_shape();
    convert(p, 1, T);
    drag_handle(p, 0, true, N(p, 1).x - 70, N(p, 1).y + 20);
    CHECK(toward(p, 2, 1, N(p, 1).hx_in, N(p, 1).hy_in));
    CHECK_NEAR(len_in(N(p, 1)), std::hypot(70, 20), 1e-9);
}

void test_pulled_handle_follows_its_axis_when_neighbours_move()
{
    Path p = open_shape();
    convert(p, 4, T);
    drag_handle(p, 3, false, N(p, 4).x + 100, N(p, 4).y);
    const double len = len_out(N(p, 4));
    N(p, 3).x += 60;  N(p, 3).y -= 90;                   // move the previous node
    compute_handles(p);
    CHECK_NEAR(len_out(N(p, 4)), len, 1e-9);             // length kept
    CHECK(toward(p, 3, 4, N(p, 4).hx_out, N(p, 4).hy_out));   // direction follows the chord
}

void test_pulled_handle_is_cleared_when_its_axis_disappears()
{
    Path p = open_shape();
    convert(p, 4, T);
    drag_handle(p, 3, false, N(p, 4).x + 100, N(p, 4).y);
    CHECK(has_out(N(p, 4)));
    N(p, 3).x = N(p, 4).x;  N(p, 3).y = N(p, 4).y;       // the previous node lands on it
    compute_handles(p);
    CHECK(polygon_corner(p, 4));
    CHECK(!N(p, 4).manual_out);
    CHECK(all_finite(p));
}

void test_pulled_handle_is_kept_when_neighbour_types_change()
{
    Path p = closed_shape();
    convert(p, 2, T);  convert(p, 3, T);
    drag_handle(p, 2, false, N(p, 3).x + 80, N(p, 3).y + 30);
    const double len = len_out(N(p, 3));
    convert(p, 4, S);                                    // the corner beside it becomes smooth
    CHECK_NEAR(len_out(N(p, 3)), len, 1e-9);
    CHECK(toward(p, 2, 3, N(p, 3).hx_out, N(p, 3).hy_out));
}

void test_corner_ignores_a_pulled_tangent_handle()
{
    // Pulling a handle out of tangent 3 bends only tangent 3's end of the
    // segment. Corner 4 beside it keeps its handle on the chord.
    Path p = closed_shape();
    convert(p, 2, T);  convert(p, 3, T);
    CHECK(flat(p, 3, 2, true));
    const Path before = p;
    drag_handle(p, 2, false, N(p, 3).x + 80, N(p, 3).y + 30);
    CHECK(has_out(N(p, 3)));                             // the pulled handle exists
    CHECK(flat(p, 3, 2, true));                          // corner 4 is unmoved
    CHECK(same_node(p, before, 4));
}


void test_all_corners_draw_straight_lines()
{
    // Every side lies along its chord, so the shape is a polygon, and every
    // handle is there to be pulled.
    const Path open = make_path({{0,0,C},{100,0,C},{100,100,C},{0,100,C}});
    const Path loop = make_path({{0,0,C},{100,0,C},{100,100,C},{0,100,C}}, Close::Plain);
    for (int n = 1; n <= 4; ++n) {
        CHECK(polygon_corner(open, n));
        CHECK(polygon_corner(loop, n));
    }
    for (int i = 0; i < 4; ++i) {
        CHECK(segment_is_straight(open, i) == (i < 3));   // the open path has 3
        CHECK(segment_is_straight(loop, i));              // the closed one has 4
    }
    // The ends of the open path still have nothing beyond them.
    CHECK(!has_in(open.nodes[0]) && !has_out(open.nodes[3]));
}

void test_smooth_circle()
{
    // Eight smooth nodes on a circle: every handle is tangent to it.
    std::vector<Pt> pts;
    for (int i = 0; i < 8; ++i)
        pts.push_back({300 + 200 * std::cos(i * PI / 4), 300 + 200 * std::sin(i * PI / 4), S});
    const Path p = make_path(pts, Close::Plain);
    for (int i = 0; i < 8; ++i) {
        const Node& n = p.nodes[i];
        const double rx = n.x - 300, ry = n.y - 300;
        CHECK_NEAR(cosine(n.hx_out, n.hy_out, rx, ry), 0.0, 1e-9);   // tangent
        CHECK_NEAR(cosine(n.hx_in,  n.hy_in,  rx, ry), 0.0, 1e-9);
        CHECK_NEAR(cosine(n.hx_in,  n.hy_in, n.hx_out, n.hy_out), -1.0, 1e-9);
        CHECK_NEAR(len_out(n), K * dist(p, i, (i + 1) % 8), 1e-9);
        CHECK_NEAR(len_in(n),  K * dist(p, i, (i + 7) % 8), 1e-9);
    }
}

void test_smooth_unequal_distances()
{
    // The tangent is that of the circle through three points, not the
    // direction from previous to next. Circle: centre (0,0), radius 100.
    // Node at angle 90 degrees, neighbours at 0 and 150 degrees.
    const double a0 = 0, a1 = PI / 2, a2 = 150 * PI / 180;
    const Path p = make_path({{100*std::cos(a0), 100*std::sin(a0), C},
                              {100*std::cos(a1), 100*std::sin(a1), S},
                              {100*std::cos(a2), 100*std::sin(a2), C}});
    const Node& n = p.nodes[1];
    CHECK_NEAR(cosine(n.hx_out, n.hy_out, 1, 0), -1.0, 1e-9);   // tangent at the top points along -x
    CHECK_NEAR(cosine(n.hx_in,  n.hy_in,  1, 0),  1.0, 1e-9);
}

void test_smooth_ends_follow_their_chord()
{
    const Path p = make_path({{0,0,S},{100,50,C},{200,0,S}});
    CHECK(!has_in(p.nodes[0]));
    CHECK(points_at(p, 0, 1, p.nodes[0].hx_out, p.nodes[0].hy_out));
    CHECK_NEAR(len_out(p.nodes[0]), K * dist(p, 0, 1), 1e-9);
    CHECK(!has_out(p.nodes[2]));
    CHECK(points_at(p, 2, 1, p.nodes[2].hx_in, p.nodes[2].hy_in));
}

void test_corner_reflects_neighbour_arc()
{
    // C S C: the corners continue the smooth node's arc. The segment from
    // the smooth node to a corner is mirror-symmetric about its bisector.
    const Path p = make_path({{0,100,C},{100,0,S},{200,100,C},{100,200,C}});
    const Node& s = p.nodes[1];
    CHECK(has_out(p.nodes[0]) && !flat(p, 0, 1, false));   // corner 0 follows smooth 1
    CHECK(has_in(p.nodes[2])  && !flat(p, 2, 1, true));    // corner 2 follows smooth 1
    CHECK(flat(p, 2, 3, false));                     // corner 2 faces corner 3: straight
    CHECK(flat(p, 3, 2, true) && !has_out(p.nodes[3]));
    // Segment 0 -> 1 is symmetric: tip(0) and tip(1) mirror across the
    // perpendicular bisector of the chord.
    const double cx = p.nodes[1].x - p.nodes[0].x, cy = p.nodes[1].y - p.nodes[0].y;
    const double a = cosine(p.nodes[0].hx_out, p.nodes[0].hy_out, cx, cy);
    const double b = cosine(s.hx_in, s.hy_in, -cx, -cy);
    CHECK_NEAR(a, b, 1e-9);
}

void test_end_corner_beside_smooth()
{
    const Path p = make_path({{0,0,C},{100,80,S},{250,0,S}});
    CHECK(has_out(p.nodes[0]));
    CHECK(!has_in(p.nodes[0]));
}

// A sharp node can be reshaped without converting it first: its handles are
// there from the start, lying along the edges.
void test_sharp_node_can_be_pulled_straight_away()
{
    Path p = make_path({{0,0,C},{100,0,C},{200,0,C}});
    CHECK(flat(p, 1, 2, false) && !p.nodes[1].manual_out);
    CHECK(segment_is_straight(p, 1));

    drag_handle(p, 1, false, 150, 60);                 // pull the middle node's handle
    CHECK(p.nodes[1].manual_out);
    CHECK(p.nodes[1].hx_out == 50 && p.nodes[1].hy_out == 60);
    CHECK(!segment_is_straight(p, 1));                 // that side is a curve now
    CHECK(segment_is_straight(p, 0));                  // the other side is untouched

    // The handle is the user's from now on: moving a neighbour leaves it be.
    p.nodes[2].x = 400;
    compute_handles(p);
    CHECK(p.nodes[1].hx_out == 50 && p.nodes[1].hy_out == 60);
}

// segment_is_straight tells a drawn line from a drawn curve, for export.
void test_segment_is_straight()
{
    const Path square = make_path({{0,0,C},{100,0,C},{100,100,C},{0,100,C}}, Close::Plain);
    for (int i = 0; i < 4; ++i) CHECK(segment_is_straight(square, i));

    // An open path has no segment after its last node, and none before its first.
    const Path open = make_path({{0,0,C},{100,0,C},{200,0,C}});
    CHECK(segment_is_straight(open, 0) && segment_is_straight(open, 1));
    CHECK(!segment_is_straight(open, 2));
    CHECK(!segment_is_straight(open, -1) && !segment_is_straight(open, 3));

    // A smooth node curves the segments on both sides of it.
    const Path curve = make_path({{0,0,C},{100,80,S},{200,0,C}});
    CHECK(!segment_is_straight(curve, 0) && !segment_is_straight(curve, 1));

    // A Tangent between sharp neighbours leaves both sides straight.
    const Path notch = make_path({{0,0,C},{100,0,T},{200,0,C}});
    CHECK(segment_is_straight(notch, 0) && segment_is_straight(notch, 1));

    // A handle pointing the wrong way, or past the far node, is not straight.
    Path back = make_path({{0,0,C},{100,0,C}});
    drag_handle(back, 0, false, -40, 0);
    CHECK(!segment_is_straight(back, 0));
    Path past = make_path({{0,0,C},{100,0,C}});
    drag_handle(past, 0, false, 160, 0);
    CHECK(!segment_is_straight(past, 0));
}

void test_corner_between_corners_is_a_straight_line()
{
    const Path p = make_path({{0,0,S},{100,0,C},{200,0,C},{300,50,S}});
    CHECK(flat(p, 1, 2, false));      // faces corner 2
    CHECK(flat(p, 2, 1, true));       // faces corner 1
    CHECK(segment_is_straight(p, 1));
}

void test_tangent_after_corner()
{
    // C T S: the edge C-T stays straight and the curve leaves along it.
    const Path p = make_path({{100,500,C},{300,500,T},{450,380,S},{600,380,S}});
    CHECK(flat(p, 0, 1, false));                          // straight edge
    CHECK(!has_in(p.nodes[1]));                           // the Tangent never bends it
    CHECK(has_out(p.nodes[1]));
    CHECK_NEAR(cosine(p.nodes[1].hx_out, p.nodes[1].hy_out, 1, 0), 1.0, 1e-9);   // along +x
    CHECK_NEAR(len_out(p.nodes[1]), K * dist(p, 1, 2), 1e-9);
}

void test_tangent_before_corner()
{
    // The mirror image: S T C.
    const Path p = make_path({{0,380,S},{150,380,S},{300,500,T},{500,500,C}});
    CHECK(!has_out(p.nodes[2]));                          // the Tangent never bends it
    CHECK(flat(p, 3, 2, true));                           // straight edge
    CHECK(has_in(p.nodes[2]));
    CHECK_NEAR(cosine(p.nodes[2].hx_in, p.nodes[2].hy_in, 1, 0), -1.0, 1e-9);   // points back along -x
    CHECK_NEAR(len_in(p.nodes[2]), K * dist(p, 2, 1), 1e-9);
}

void test_tangent_in_closed_path()
{
    // "D" shape, plain close: C T S T C. Straight top, bottom and left
    // sides, rounded right end.
    const Path p = bezigon::scenes::build(bezigon::scenes::all[2]);
    for (int n : {1, 5}) CHECK(polygon_corner(p, n));    // the corners: straight both sides
    CHECK(!has_in(p.nodes[1]) && has_out(p.nodes[1]));   // top: straight in, curve out
    CHECK(has_in(p.nodes[3]) && !has_out(p.nodes[3]));   // bottom: curve in, straight out
    CHECK_NEAR(cosine(p.nodes[1].hx_out, p.nodes[1].hy_out, 1, 0), 1.0, 1e-9);   // leaves along the top
    CHECK_NEAR(cosine(p.nodes[3].hx_in,  p.nodes[3].hy_in,  1, 0), 1.0, 1e-9);   // arrives along the bottom
    CHECK_NEAR(cosine(p.nodes[2].hx_in, p.nodes[2].hy_in,
                      p.nodes[2].hx_out, p.nodes[2].hy_out), -1.0, 1e-9);        // smooth in the middle
}

void test_plain_close_keeps_start_type()
{
    const std::vector<Pt> pts = {{0,0,S},{100,0,C},{100,100,S},{0,100,C}};
    const Path p = make_path(pts, Close::Plain);
    CHECK(p.nodes[0].type == S);
    // The start node is smooth and wraps around: collinear handles.
    CHECK_NEAR(cosine(p.nodes[0].hx_in, p.nodes[0].hy_in,
                      p.nodes[0].hx_out, p.nodes[0].hy_out), -1.0, 1e-9);
}

void test_modifier_close_start_node()
{
    // Start placed as Corner: in-handle straight at the last node; the
    // out-handle uses the corner rule (node 1 is a corner, so none).
    const std::vector<Pt> corner = {{0,0,C},{100,0,C},{100,100,S},{0,100,S}};
    Path p = make_path(corner, Close::Modifier);
    CHECK(has_in(p.nodes[0]));
    CHECK(points_at(p, 0, 3, p.nodes[0].hx_in, p.nodes[0].hy_in));
    CHECK(flat(p, 0, 1, false));            // node 1 is a corner, so straight at it

    // Start placed as Smooth: out-handle also straight at node 1.
    std::vector<Pt> smooth = corner;
    smooth[0].type = S;
    p = make_path(smooth, Close::Modifier);
    CHECK(has_in(p.nodes[0]) && has_out(p.nodes[0]));
    CHECK(points_at(p, 0, 3, p.nodes[0].hx_in,  p.nodes[0].hy_in));
    CHECK(points_at(p, 0, 1, p.nodes[0].hx_out, p.nodes[0].hy_out));
    CHECK(p.nodes[0].type == C);

    // Start placed as Tangent behaves like Smooth here.
    std::vector<Pt> tangent = corner;
    tangent[0].type = T;
    CHECK(same_handles(p, make_path(tangent, Close::Modifier), 1e-12));
}

void test_modifier_close_start_corner_reflects_out()
{
    // Start placed as Corner, node 1 smooth: the out-handle reflects it.
    const Path p = make_path({{0,0,C},{100,-40,S},{200,40,S},{100,150,S}}, Close::Modifier);
    CHECK(has_out(p.nodes[0]));
    CHECK(!points_at(p, 0, 1, p.nodes[0].hx_out, p.nodes[0].hy_out));   // reflected, not straight
}

void test_close_path_rules()
{
    Path p = make_path({{0,0,C}});                  // one node: nothing to close
    CHECK(!close_path(p, false));
    CHECK(p.close() == Close::Open);
    p = make_path({{0,0,C},{10,0,C}});              // two nodes close into a loop
    CHECK(close_path(p, false));
    CHECK(p.close() == Close::Plain);
    p = make_path({{0,0,C},{10,0,C},{10,10,C}});
    CHECK(close_path(p, true));
    CHECK(p.close() == Close::Modifier);
    CHECK(p.nodes[0].type == C);                 // node types are never rewritten
}

// The close state can only be set by close_path (Path::close_ is private),
// so a host can no longer mark a path modifier-closed while its start node is
// still Smooth. That is a compile-time guarantee; this checks the outcome.
void test_close_state_and_start_node_agree()
{
    Path p = make_path({{0,0,S},{100,0,S},{100,100,S}});
    CHECK(p.close() == Close::Open);
    CHECK(close_path(p, true));
    CHECK(p.close() == Close::Modifier);
    CHECK(p.nodes[0].type == C);
    CHECK(p.nodes[0].cusp);
}

void test_modifier_close_turns_the_start_node_into_a_corner()
{
    Path p = make_path({{0,0,S},{100,0,T},{100,100,C}}, Close::Modifier);
    CHECK(p.nodes[0].type == C);
    CHECK(p.nodes[1].type == T);
    CHECK(p.nodes[2].type == C);

    // A plain close, or none, leaves the start node as it is.
    p = make_path({{0,0,S},{100,0,T},{100,100,C}}, Close::Plain);
    CHECK(p.nodes[0].type == S);
    p = make_path({{0,0,S},{100,0,T},{100,100,C}}, Close::Open);
    CHECK(p.nodes[0].type == S);
}

void test_handle_fraction_option()
{
    Path p = make_path({{0,0,S},{100,0,S},{100,100,S}});
    Options o;  o.handleFraction = 0.25;
    compute_handles(p, o);
    CHECK_NEAR(len_out(p.nodes[0]), 25.0, 1e-9);
    CHECK_NEAR(len_in(p.nodes[2]), 25.0, 1e-9);
}

void test_recompute_follows_moves_and_type_changes()
{
    Path p = make_path({{0,0,C},{100,0,S},{200,50,C}});
    CHECK(has_out(p.nodes[0]) && !flat(p, 0, 1, false));
    p.nodes[1].type = C;
    compute_handles(p);
    CHECK(flat(p, 0, 1, false) && flat(p, 1, 0, true));   // now a straight line
    p.nodes[1].type = S;
    p.nodes[1].y = 80;
    compute_handles(p);
    CHECK(has_out(p.nodes[0]));
}

void test_freehand_shield()
{
    struct Row { double inx, iny, outx, outy; };
    const Row expect[8] = {
        { 21,  91, -26,  70},     // Top     (corner, start)
        { 66, -40, -65,  39},     // A       (smooth)
        { 74,   9, -26, 102},     // UL      (corner)
        {-28,-101,  47, 174},     // D       (smooth)
        {-169,-66, 161, -96},     // Bottom  (corner)
        {-45, 183,  24, -88},     // C       (smooth)
        { 11,  89, -55,  14},     // UR      (corner)
        { 52,  19, -89, -33},     // B       (smooth)
    };
    const Path p = bezigon::scenes::build(bezigon::scenes::all[0]);
    for (int i = 0; i < 8; ++i) {
        const Node& n = p.nodes[i];
        CHECK_NEAR(n.hx_in,  expect[i].inx,  3.0);
        CHECK_NEAR(n.hy_in,  expect[i].iny,  3.0);
        CHECK_NEAR(n.hx_out, expect[i].outx, 3.0);
        CHECK_NEAR(n.hy_out, expect[i].outy, 3.0);
    }
}

void test_freehand_click_patterns()
{
    // PC PC MC PC PC, open: the first node's edge to node 2 is straight.
    Path p = make_path({{100,100,C},{200,60,C},{300,120,S},{400,60,C},{500,100,C}});
    CHECK(!has_in(p.nodes[0]) && flat(p, 0, 1, false));

    // PC MC MC MC PC, open: the first node gets one handle toward node 2.
    p = make_path({{100,200,C},{200,100,S},{300,80,S},{400,100,S},{500,200,C}});
    CHECK(has_out(p.nodes[0]) && !has_in(p.nodes[0]));

    // PC PC MC MC, plain close: node 1 has a handle toward node 4 only.
    p = make_path({{100,100,C},{300,100,C},{350,250,S},{150,250,S}}, Close::Plain);
    CHECK(has_in(p.nodes[0]));
    CHECK(flat(p, 0, 1, false));            // straight edge to the next corner

    // PC PC MC MC, modifier close: same pair of handles at the start, the
    // in-handle straight at the last node.
    p = make_path({{100,100,C},{300,100,C},{350,250,S},{150,250,S}}, Close::Modifier);
    CHECK(has_in(p.nodes[0]) && flat(p, 0, 1, false));
    CHECK(points_at(p, 0, 3, p.nodes[0].hx_in, p.nodes[0].hy_in));
}

void test_drag_smooth_mirrors_opposite()
{
    Path p = make_path({{0,0,C},{100,0,S},{200,80,C}});
    const double oppLen = len_out(p.nodes[1]);
    drag_handle(p, 1, true, 100 - 30, 40);                // drag the in-handle
    const Node& n = p.nodes[1];
    CHECK_NEAR(n.hx_in, -30, EPS);
    CHECK_NEAR(n.hy_in,  40, EPS);
    CHECK(n.manual_in && n.manual_out);
    CHECK_NEAR(cosine(n.hx_in, n.hy_in, n.hx_out, n.hy_out), -1.0, 1e-9);
    CHECK_NEAR(len_out(n), oppLen, 1e-9);                 // opposite length kept
}

void test_drag_updates_neighbouring_corners()
{
    // Turning a smooth node's handle changes the arc its corner neighbours
    // continue. The library must recompute them, the host should not have to.
    Path p = make_path({{0,0,C},{100,0,S},{200,80,C}});
    const double before = p.nodes[0].hy_out;
    drag_handle(p, 1, false, 100 + 40, 40);               // swing the out-handle
    CHECK(std::fabs(p.nodes[0].hy_out - before) > 1.0);
    const Path fresh = p;                                 // and it matches a clean recompute
    Path again = p;
    compute_handles(again);
    CHECK(same_handles(fresh, again, 1e-12));
}

void test_drag_corner_leaves_opposite_alone()
{
    Path p = make_path({{0,0,S},{100,0,C},{200,80,S}});
    const Node before = p.nodes[1];
    drag_handle(p, 1, false, 140, 60);
    const Node& n = p.nodes[1];
    CHECK_NEAR(n.hx_out, 40, EPS);
    CHECK(n.manual_out && !n.manual_in);
    CHECK_NEAR(n.hx_in, before.hx_in, EPS);
    CHECK_NEAR(n.hy_in, before.hy_in, EPS);
}

void test_drag_with_missing_opposite_handle()
{
    // The end node has no opposite handle: nothing to mirror or freeze.
    Path p = make_path({{0,0,S},{100,50,S},{200,0,C}});
    drag_handle(p, 0, false, 50, 50);
    CHECK(p.nodes[0].manual_out);
    CHECK(!p.nodes[0].manual_in);
    CHECK(!has_in(p.nodes[0]));
}

void test_drag_tangent_keeps_direction_and_takes_length()
{
    Path p = make_path({{100,500,C},{300,500,T},{450,380,S},{600,380,S}});
    drag_handle(p, 1, false, 300 + 12, 500 - 90);         // far off the line, 90 up
    const Node& n = p.nodes[1];
    CHECK(n.manual_out);
    CHECK_NEAR(cosine(n.hx_out, n.hy_out, 1, 0), 1.0, 1e-9);        // still along the line
    CHECK_NEAR(len_out(n), std::hypot(12, 90), 1e-9);               // length from the drag
    CHECK(!has_in(n));
    // A recompute keeps it, and moving the node keeps the length too.
    p.nodes[1].x = 320;
    compute_handles(p);
    CHECK_NEAR(len_out(p.nodes[1]), std::hypot(12, 90), 1e-9);
    CHECK_NEAR(cosine(p.nodes[1].hx_out, p.nodes[1].hy_out, 1, 0), 1.0, 1e-9);
}

void test_manual_survives_recompute()
{
    Path p = make_path({{0,0,C},{100,0,S},{200,80,C},{300,0,S}});
    drag_handle(p, 1, false, 150, 30);
    const Node dragged = p.nodes[1];
    p.nodes[3].y = 40;                                    // move something else
    compute_handles(p);
    CHECK_NEAR(p.nodes[1].hx_out, dragged.hx_out, 1e-12);
    CHECK_NEAR(p.nodes[1].hy_in,  dragged.hy_in,  1e-12);
}

void test_manual_smooth_heading_steers_neighbours()
{
    // Dragging the smooth node's handle changes the corner's reflection.
    Path p = make_path({{0,0,C},{100,0,S},{200,0,C}});
    const double flat = p.nodes[0].hy_out;
    drag_handle(p, 1, false, 100 + 30, -30);
    CHECK(std::fabs(p.nodes[0].hy_out - flat) > 1.0);
}

void test_manual_in_handle_alone_steers_neighbours()
{
    // The last node has only an in-handle to drag. Its direction still
    // becomes the node's heading, and the corner before it follows.
    Path p = make_path({{0,0,C},{100,0,C},{200,0,S}});
    const double flat = p.nodes[1].hy_out;
    drag_handle(p, 2, true, 200 - 30, 30);
    CHECK(p.nodes[2].manual_in && !p.nodes[2].manual_out);
    CHECK(std::fabs(p.nodes[1].hy_out - flat) > 1.0);
}

void test_release_manual_handles()
{
    Path p = make_path({{0,0,C},{100,0,S},{200,80,C}});
    const Path auto_path = p;
    drag_handle(p, 1, true, 60, 50);
    for (size_t i = 0; i < p.nodes.size(); ++i)
        p.nodes[i].manual_in = p.nodes[i].manual_out = false;
    compute_handles(p);
    CHECK(same_handles(p, auto_path, 1e-12));
}

void test_drag_on_modifier_start_does_not_mirror()
{
    // The start node was placed Smooth but acts as a Corner after the
    // modifier close, so it has no collinear partner.
    Path p = make_path({{0,0,S},{100,0,C},{100,100,S},{0,100,S}}, Close::Modifier);
    const Node before = p.nodes[0];
    drag_handle(p, 0, false, 30, 30);
    CHECK_NEAR(p.nodes[0].hx_in, before.hx_in, EPS);
    CHECK_NEAR(p.nodes[0].hy_in, before.hy_in, EPS);
    CHECK(!p.nodes[0].manual_in);
}

void test_drag_bad_index_is_ignored()
{
    Path p = make_path({{0,0,C},{100,0,S},{200,80,C}});
    const Path before = p;
    drag_handle(p, -1, true, 5, 5);
    drag_handle(p, 3, true, 5, 5);
    drag_handle(p, 1000, false, 5, 5);
    CHECK(same_handles(p, before, 0.0));
    Path empty;
    drag_handle(empty, 0, true, 1, 1);
}

void test_tiny_paths()
{
    Path p;
    compute_handles(p);
    CHECK(p.nodes.empty());

    p = make_path({{5,5,S}});
    CHECK(!has_in(p.nodes[0]) && !has_out(p.nodes[0]));
    p = make_path({{5,5,T}});
    CHECK(!has_in(p.nodes[0]) && !has_out(p.nodes[0]));

    p = make_path({{0,0,S},{100,0,S}});
    CHECK(has_out(p.nodes[0]) && has_in(p.nodes[1]));
    // A smooth end node points along its chord, so the corner's reflected
    // handle lies along the chord too: the arc is a straight line.
    p = make_path({{0,0,C},{100,0,S}});
    CHECK(points_at(p, 0, 1, p.nodes[0].hx_out, p.nodes[0].hy_out));
    CHECK(points_at(p, 1, 0, p.nodes[1].hx_in,  p.nodes[1].hy_in));

    // Two nodes can be closed; a single node cannot.
    p = make_path({{0,0,S},{100,0,S}});
    CHECK(close_path(p, true));
    CHECK(p.close() == Close::Modifier);
    p = make_path({{0,0,S}});
    CHECK(!close_path(p, true));
    CHECK(p.close() == Close::Open);
}

// ------------------------------------------------ two-node loops (4.2.0)

// Plain close of two Smooth nodes: Xara's ellipse. Each node has the other on
// both sides, so it points square to the chord, and the handles are 0.39 of it.
void test_two_node_loop_plain_close_is_an_ellipse()
{
    const Path p = make_path({{0,0,S},{0,200,S}}, Close::Plain);
    const Node& a = p.nodes[0];
    const Node& b = p.nodes[1];
    CHECK(a.type == S && b.type == S);
    for (int i = 0; i < 2; ++i) {
        const Node& n = p.nodes[i];
        CHECK_NEAR(n.hy_in,  0.0, 1e-9);                    // square to the chord
        CHECK_NEAR(n.hy_out, 0.0, 1e-9);
        CHECK_NEAR(len_in(n),  K * 200, 1e-9);
        CHECK_NEAR(len_out(n), K * 200, 1e-9);
        CHECK(cosine(n.hx_in, n.hy_in, n.hx_out, n.hy_out) < -0.999999);
    }
    // The two segments bulge to opposite sides: a closed ellipse, not a line.
    CHECK(a.hx_out * b.hx_in > 0);                          // segment 0 -> 1, one side
    CHECK(b.hx_out * a.hx_in > 0);                          // segment 1 -> 0, the other
    CHECK(a.hx_out * b.hx_out < 0);
}

// Modifier close of the same two nodes: the start node becomes a cusp, lying
// along the chord, and the other node keeps its square heading. The closing
// logic decides, not a fixed Xara shape.
void test_two_node_loop_modifier_close_makes_a_cusp()
{
    const Path p = make_path({{0,0,S},{0,200,S}}, Close::Modifier);
    const Node& a = p.nodes[0];
    const Node& b = p.nodes[1];
    CHECK(a.type == C && a.cusp);
    CHECK(points_at(p, 0, 1, a.hx_in,  a.hy_in));           // straight back
    CHECK(points_at(p, 0, 1, a.hx_out, a.hy_out));          // cusp: straight on
    CHECK_NEAR(b.hy_in,  0.0, 1e-9);                        // b still square to it
    CHECK_NEAR(b.hy_out, 0.0, 1e-9);
    CHECK(std::fabs(b.hx_in) > 1.0);
}

// A corner born a corner, plain-closed with a Smooth node, continues the
// Smooth node's arc, as it would in any loop: still an ellipse.
void test_two_node_loop_corner_beside_smooth()
{
    const Path p = make_path({{0,0,C},{0,200,S}}, Close::Plain);
    const Node& a = p.nodes[0];
    CHECK(has_in(a) && has_out(a));
    CHECK_NEAR(a.hy_in,  0.0, 1e-9);
    CHECK_NEAR(a.hy_out, 0.0, 1e-9);
}

// Two corners closed: both segments straight, lying on top of each other.
void test_two_node_loop_of_corners_is_flat()
{
    const Path p = make_path({{0,0,C},{0,200,C}}, Close::Plain);
    CHECK(flat(p, 0, 1, true)  && flat(p, 0, 1, false));
    CHECK(flat(p, 1, 0, true)  && flat(p, 1, 0, false));
    CHECK(segment_is_straight(p, 0) && segment_is_straight(p, 1));
}

// Toggling the start node of a modifier-closed two-node loop moves between
// the cusp and the ellipse, and lands on the same cusp every time.
void test_two_node_loop_toggles()
{
    const Path closed = make_path({{0,0,S},{0,200,S}}, Close::Modifier);
    Path p = closed;
    set_node_type(p, 0, S);
    const Path ellipse = make_path({{0,0,S},{0,200,S}}, Close::Plain);
    CHECK(same_handles(p, ellipse, 1e-9));
    set_node_type(p, 0, C);
    CHECK(same_handles(p, closed, 1e-12));
    CHECK(p.close() == Close::Modifier);
}

// Two separate nodes on one point, anywhere other than a two-node loop: nothing
// special happens. Here a closed ring of four where nodes 1 and 3 coincide;
// node 2's handles simply point straight at that shared point.
void test_coincidence_in_a_larger_loop_stays_plain()
{
    const Path p = make_path({{0,0,C},{100,0,C},{100,200,S},{100,0,C}}, Close::Plain);
    CHECK(all_finite(p));
    CHECK(points_at(p, 2, 1, p.nodes[2].hx_in,  p.nodes[2].hy_in));
    CHECK(points_at(p, 2, 3, p.nodes[2].hx_out, p.nodes[2].hy_out));
    CHECK_NEAR(len_in(p.nodes[2]),  K * 200, 1e-9);
    CHECK_NEAR(len_out(p.nodes[2]), K * 200, 1e-9);
}

void test_coincident_nodes()
{
    // Never crash, never produce NaN, whatever the positions.
    const std::vector<std::vector<Pt> > cases = {
        {{50,50,S},{50,50,S},{50,50,S}},
        {{0,0,C},{0,0,S},{100,0,S}},
        {{0,0,S},{100,0,S},{0,0,S}},
        {{0,0,S},{100,0,T},{0,0,C},{100,0,S}},
        {{0,0,T},{0,0,T},{0,0,T},{0,0,T}},
        {{0,0,S},{100,100,S},{200,200,S},{100,100,S}},
        {{0,0,S},{1e-12,0,S},{100,0,S}},
    };
    for (size_t c = 0; c < cases.size(); ++c) {
        for (int close = 0; close < 3; ++close) {
            const Path p = make_path(cases[c], close == 0 ? Close::Open
                                              : close == 1 ? Close::Plain : Close::Modifier);
            CHECK(all_finite(p));
        }
    }
}

void test_path_that_goes_out_and_comes_back()
{
    // Click A, modifier-click B, click C, drag C onto A, and leave the path
    // open. A and C coincide but are separate nodes, so nothing special
    // happens: B has no circle to follow, and every handle lies along the
    // one chord until the nodes are moved apart. (Clicking A now would merge
    // C into A and close a two-node loop; that is the demo's job.)
    const Path p = make_path({{0,0,C},{100,0,S},{0,0,C}});
    CHECK(all_finite(p));

    const Node& a = p.nodes[0];
    const Node& b = p.nodes[1];
    const Node& c = p.nodes[2];
    CHECK(points_at(p, 1, 0, b.hx_in,  b.hy_in));        // straight at A ...
    CHECK(points_at(p, 1, 2, b.hx_out, b.hy_out));       // ... and at C
    CHECK_NEAR(len_in(b),  K * 100, 1e-9);
    CHECK_NEAR(len_out(b), K * 100, 1e-9);
    CHECK(flat(p, 0, 1, false));                         // A's handle on the chord
    CHECK(flat(p, 2, 1, true));                          // C's handle on the chord
    CHECK(segment_is_straight(p, 0) && segment_is_straight(p, 1));
    (void)a; (void)c;
}

// The threshold for "no circle" scales with the drawing, so a smooth node
// behaves the same at any size, including segments of billions of units.
void test_smooth_node_at_any_scale()
{
    const double scales[] = { 1e-6, 1.0, 1e3, 1e9, 3e9, 1e10, 1e12 };
    for (size_t k = 0; k < sizeof(scales) / sizeof(scales[0]); ++k) {
        const double s = scales[k];
        const Path p = make_path({{0,0,C},{s,0,S},{2*s,1e-3*s,C}});
        const Node& b = p.nodes[1];
        CHECK_NEAR(cosine(b.hx_in, b.hy_in, b.hx_out, b.hy_out), -1.0, 1e-12);
    }
}

void test_huge_and_tiny_coordinates()
{
    const double scales[] = {1e-6, 1e-3, 1.0, 1e3, 1e6, 1e9};
    for (size_t k = 0; k < sizeof(scales) / sizeof(scales[0]); ++k) {
        const double s = scales[k];
        const Path p = make_path({{0,0,C},{s,0,S},{2*s,s,T},{3*s,s,C},{4*s,0,S}});
        CHECK(all_finite(p));
        CHECK(has_out(p.nodes[1]));
    }
}

// Scenes shipped with the demo must all produce finite, sensible output.
void test_demo_scenes()
{
    namespace sc = bezigon::scenes;
    for (int s = 0; s < sc::count; ++s)
        CHECK(all_finite(sc::build(sc::all[s])));

    // Line to curve: the Tangent at node 2 leaves the straight edge without
    // a kink and curves into the Smooth node after it.
    const Path lc = sc::build(sc::all[1]);
    CHECK(flat(lc, 0, 1, false) && !has_in(lc.nodes[1]) && has_out(lc.nodes[1]));
    CHECK(segment_is_straight(lc, 0));

    // Notch: the Tangent has two handles, and they are not collinear.
    const Path nt = sc::build(sc::all[3]);
    CHECK(has_in(nt.nodes[2]) && has_out(nt.nodes[2]));
    CHECK(cosine(nt.nodes[2].hx_in, nt.nodes[2].hy_in,
                 nt.nodes[2].hx_out, nt.nodes[2].hy_out) > -0.99);

    // Wave: the first Tangent has an out-handle, the middle one has both.
    const Path wv = sc::build(sc::all[6]);
    CHECK(has_out(wv.nodes[0]) && !has_in(wv.nodes[0]));
    CHECK(has_in(wv.nodes[2]) && has_out(wv.nodes[2]));

    // Square: every side straight, every handle lying on an edge.
    const Path sq = sc::build(sc::all[4]);
    for (int n = 1; n <= (int)sq.nodes.size(); ++n) CHECK(polygon_corner(sq, n));
    for (int i = 0; i < (int)sq.nodes.size(); ++i)   CHECK(segment_is_straight(sq, i));

    // Teardrop: the start node has both handles, pointing straight at its
    // neighbours.
    const Path tear = sc::build(sc::all[5]);
    CHECK(points_at(tear, 0, 4, tear.nodes[0].hx_in,  tear.nodes[0].hy_in));
    CHECK(points_at(tear, 0, 1, tear.nodes[0].hx_out, tear.nodes[0].hy_out));
}

// ============================================== random properties

Path transformed(const Path& p, double angle, double scale, bool mirror,
                 double tx, double ty)
{
    Path q = p;
    const double c = std::cos(angle), s = std::sin(angle);
    for (size_t i = 0; i < q.nodes.size(); ++i) {
        double x = p.nodes[i].x * (mirror ? -1 : 1), y = p.nodes[i].y;
        q.nodes[i].x = scale * (c * x - s * y) + tx;
        q.nodes[i].y = scale * (s * x + c * y) + ty;
    }
    for (size_t i = 0; i < q.nodes.size(); ++i) {
        q.nodes[i].hx_in = q.nodes[i].hy_in = q.nodes[i].hx_out = q.nodes[i].hy_out = 0.0;
    }
    compute_handles(q);
    return q;
}

void apply_to_offset(double angle, double scale, bool mirror,
                     double& hx, double& hy)
{
    const double c = std::cos(angle), s = std::sin(angle);
    const double x = hx * (mirror ? -1 : 1), y = hy;
    hx = scale * (c * x - s * y);
    hy = scale * (s * x + c * y);
}

void prop_handles_are_finite_and_sized(Rng& rng, int runs)
{
    for (int r = 0; r < runs; ++r) {
        const Path p = random_path(rng, 1 + rng.below(12), true, random_close(rng));
        CHECK(all_finite(p));
        const int n = (int)p.nodes.size();
        const bool loop = p.close() != Close::Open && n >= 2;
        for (int i = 0; i < n; ++i) {
            const Node& nd = p.nodes[i];
            const int prev = i > 0 ? i - 1 : (loop ? n - 1 : -1);
            const int next = i < n - 1 ? i + 1 : (loop ? 0 : -1);
            // Every handle is K times its own segment, and there is no
            // handle toward a neighbour that does not exist.
            if (has_in(nd))  { CHECK(prev >= 0); CHECK_NEAR(len_in(nd),  K * dist(p, i, prev), 1e-9); }
            if (has_out(nd)) { CHECK(next >= 0); CHECK_NEAR(len_out(nd), K * dist(p, i, next), 1e-9); }
        }
    }
}

void prop_similarity_invariance(Rng& rng, int runs)
{
    for (int r = 0; r < runs; ++r) {
        const Path p = random_path(rng, 3 + rng.below(8), true, random_close(rng));
        const double angle = rng.uniform(0, 2 * PI), scale = rng.uniform(0.2, 5.0);
        const bool   mirror = rng.below(2) == 1;
        const Path q = transformed(p, angle, scale, mirror, rng.uniform(-500, 500), rng.uniform(-500, 500));
        bool same = true;
        for (size_t i = 0; i < p.nodes.size(); ++i) {
            double a[4] = {p.nodes[i].hx_in, p.nodes[i].hy_in, p.nodes[i].hx_out, p.nodes[i].hy_out};
            apply_to_offset(angle, scale, mirror, a[0], a[1]);
            apply_to_offset(angle, scale, mirror, a[2], a[3]);
            const double b[4] = {q.nodes[i].hx_in, q.nodes[i].hy_in, q.nodes[i].hx_out, q.nodes[i].hy_out};
            for (int k = 0; k < 4; ++k) if (std::fabs(a[k] - b[k]) > 1e-6 * scale) same = false;
        }
        CHECK(same);
    }
}

void prop_cyclic_shift(Rng& rng, int runs)
{
    for (int r = 0; r < runs; ++r) {
        const Path p = random_path(rng, 3 + rng.below(8), true, Close::Plain);
        const int n = (int)p.nodes.size(), k = 1 + rng.below(n - 1);
        Path q = p;
        for (int i = 0; i < n; ++i) q.nodes[i] = p.nodes[(i + k) % n];
        compute_handles(q);
        bool same = true;
        for (int i = 0; i < n; ++i) {
            const Node& a = p.nodes[(i + k) % n];
            const Node& b = q.nodes[i];
            if (std::fabs(a.hx_in - b.hx_in) > 1e-9 || std::fabs(a.hy_in - b.hy_in) > 1e-9 ||
                std::fabs(a.hx_out - b.hx_out) > 1e-9 || std::fabs(a.hy_out - b.hy_out) > 1e-9)
                same = false;
        }
        CHECK(same);
    }
}

void prop_reversal(Rng& rng, int runs)
{
    for (int r = 0; r < runs; ++r) {
        const Path p = random_path(rng, 2 + rng.below(9), true,
                                   rng.below(2) ? Close::Open : Close::Plain);
        const int n = (int)p.nodes.size();
        Path q = p;
        for (int i = 0; i < n; ++i) q.nodes[i] = p.nodes[n - 1 - i];
        compute_handles(q);
        // In a closed loop of two nodes both handles of a node face the same
        // neighbour, so reversing the order maps each segment onto itself: the
        // same two segments are drawn, with every handle where it was.
        const bool twoLoop = (n == 2 && p.close() != Close::Open);
        bool same = true;
        for (int i = 0; i < n; ++i) {
            const Node& a = p.nodes[n - 1 - i];
            const Node& b = q.nodes[i];
            const double bin_x  = twoLoop ? b.hx_in  : b.hx_out, bin_y  = twoLoop ? b.hy_in  : b.hy_out;
            const double bout_x = twoLoop ? b.hx_out : b.hx_in,  bout_y = twoLoop ? b.hy_out : b.hy_in;
            if (std::fabs(a.hx_in - bin_x) > 1e-9 || std::fabs(a.hy_in - bin_y) > 1e-9 ||
                std::fabs(a.hx_out - bout_x) > 1e-9 || std::fabs(a.hy_out - bout_y) > 1e-9)
                same = false;
        }
        CHECK(same);
    }
}

void prop_locality(Rng& rng, int runs)
{
    for (int r = 0; r < runs; ++r) {
        const Path p = random_path(rng, 5 + rng.below(8), true, random_close(rng));
        const int n = (int)p.nodes.size(), k = rng.below(n);
        for (int what = 0; what < 2; ++what) {
            Path q = p;
            if (what == 0) { q.nodes[k].x += rng.uniform(-40, 40);  q.nodes[k].y += rng.uniform(-40, 40); }
            else           q.nodes[k].type = (NodeType)(((int)q.nodes[k].type + 1 + rng.below(2)) % 3);
            compute_handles(q);
            for (int i = 0; i < n; ++i) {
                if (graph_distance(p, i, k) <= 2) continue;
                const bool same =
                    p.nodes[i].hx_in == q.nodes[i].hx_in && p.nodes[i].hy_in == q.nodes[i].hy_in &&
                    p.nodes[i].hx_out == q.nodes[i].hx_out && p.nodes[i].hy_out == q.nodes[i].hy_out;
                CHECK(same);
            }
        }
    }
}

void prop_idempotent(Rng& rng, int runs)
{
    for (int r = 0; r < runs; ++r) {
        Path p = random_path(rng, 3 + rng.below(8), true, random_close(rng));
        if (rng.below(2)) {                                // some manual handles too
            const int i = rng.below((int)p.nodes.size());
            drag_handle(p, i, rng.below(2) == 1, p.nodes[i].x + rng.uniform(-50, 50),
                                                  p.nodes[i].y + rng.uniform(-50, 50));
        }
        Path q = p;
        compute_handles(q);
        CHECK(same_handles(p, q, 1e-9));
    }
}

void prop_corner_arc_is_symmetric(Rng& rng, int runs)
{
    for (int r = 0; r < runs; ++r) {
        const Path p = random_path(rng, 3 + rng.below(9), true, Close::Plain);
        const int n = (int)p.nodes.size();
        for (int i = 0; i < n; ++i) {
            const int j = (i + 1) % n;
            const Node& a = p.nodes[i];
            const Node& b = p.nodes[j];
            const bool ca = p.nodes[i].type == C, cb = p.nodes[j].type == C;
            if (ca == cb || !has_out(a) || !has_in(b)) continue;
            const double cx = b.x - a.x, cy = b.y - a.y, cl = std::hypot(cx, cy);
            // Angle of each handle to the chord, signed. Mirror symmetry
            // means they are equal and opposite in the chord's frame.
            const double ang_a = std::atan2(cx * a.hy_out - cy * a.hx_out, cx * a.hx_out + cy * a.hy_out);
            const double ang_b = std::atan2(cx * b.hy_in  - cy * b.hx_in,  cx * b.hx_in  + cy * b.hy_in);
            CHECK_NEAR(std::fabs(ang_a), std::fabs(PI - std::fabs(ang_b)), 1e-9);
            CHECK(cl > 0);
        }
    }
}

void prop_all_smooth_has_full_handles(Rng& rng, int runs)
{
    for (int r = 0; r < runs; ++r) {
        Path p = random_path(rng, 3 + rng.below(8), false, Close::Plain);
        for (size_t i = 0; i < p.nodes.size(); ++i) p.nodes[i].type = S;
        compute_handles(p);
        for (size_t i = 0; i < p.nodes.size(); ++i)
            CHECK(has_in(p.nodes[i]) && has_out(p.nodes[i]));
    }
}

void prop_drag_matches_recompute(Rng& rng, int runs)
{
    for (int r = 0; r < runs; ++r) {
        Path p = random_path(rng, 3 + rng.below(8), true, random_close(rng));
        for (int d = 0; d < 3; ++d) {
            const int i = rng.below((int)p.nodes.size());
            drag_handle(p, i, rng.below(2) == 1, p.nodes[i].x + rng.uniform(-80, 80),
                                                  p.nodes[i].y + rng.uniform(-80, 80));
            Path q = p;
            compute_handles(q);
            CHECK(same_handles(p, q, 1e-9));
            CHECK(all_finite(p));
        }
    }
}

// Smooth nodes are G1: in- and out-handle are collinear and opposite.
void prop_smooth_nodes_are_g1(Rng& rng, int runs)
{
    for (int r = 0; r < runs; ++r) {
        const Path p = random_path(rng, 3 + rng.below(9), true, random_close(rng));
        for (int i = 0; i < (int)p.nodes.size(); ++i) {
            const Node& nd = p.nodes[i];
            if (p.nodes[i].type == S && has_in(nd) && has_out(nd))
                CHECK_NEAR(cosine(nd.hx_in, nd.hy_in, nd.hx_out, nd.hy_out), -1.0, 1e-9);
        }
    }
}

// Neighbour indices of node i, or -1 where there is none.
void neighbours_of(const Path& p, int i, int& prev, int& next)
{
    const int n = (int)p.nodes.size();
    const bool loop = p.close() != Close::Open && n >= 2;
    prev = i > 0     ? i - 1 : (loop ? n - 1 : -1);
    next = i < n - 1 ? i + 1 : (loop ? 0     : -1);
}

// Where a Tangent node's handle points, and which handles appear by
// themselves: the direction continues the chord on the other side (or the
// node's own chord at an end), and an automatic handle exists exactly where
// the neighbour already curves the segment (it is Smooth, or has a dragged
// handle facing this node), K times its own segment.
void prop_tangent_rule(Rng& rng, int runs)
{
    for (int r = 0; r < runs; ++r) {
        Path p = random_path(rng, 3 + rng.below(9), true, random_close(rng));
        for (int d = rng.below(3); d > 0; --d)               // some dragged handles
            drag_handle(p, rng.below((int)p.nodes.size()), rng.below(2) == 1,
                        rng.uniform(0, 600), rng.uniform(0, 600));

        for (int i = 0; i < (int)p.nodes.size(); ++i) {
            if (p.nodes[i].type != T) continue;
            const Node& nd = p.nodes[i];
            int prev, next;
            neighbours_of(p, i, prev, next);

            for (int isIn = 0; isIn < 2; ++isIn) {
                const int towardNode = isIn ? prev : next;
                const int other      = isIn ? next : prev;
                const bool has = isIn ? has_in(nd) : has_out(nd);
                const bool own = has && (isIn ? nd.manual_in : nd.manual_out);

                bool curved = false;
                if (towardNode >= 0) {
                    const Node& nb = p.nodes[towardNode];
                    const bool facing = isIn ? (nb.manual_out && has_out(nb))
                                             : (nb.manual_in  && has_in(nb));
                    curved = p.nodes[towardNode].type == S || facing;
                }
                CHECK(has == (own || curved));
                if (!has) continue;
                const double hx = isIn ? nd.hx_in : nd.hx_out, hy = isIn ? nd.hy_in : nd.hy_out;
                if (other >= 0)             CHECK(points_at(p, other, i, hx, hy));
                else if (towardNode >= 0)   CHECK(points_at(p, i, towardNode, hx, hy));
                if (!own) CHECK_NEAR(std::hypot(hx, hy), K * dist(p, i, towardNode), 1e-9);
            }
        }
    }
}

// handle_axis gives a direction on every side of a Tangent that has a
// neighbour to take it from, and agrees with the handles that appear.
void prop_handle_axis_rule(Rng& rng, int runs)
{
    for (int r = 0; r < runs; ++r) {
        const Path p = random_path(rng, 3 + rng.below(9), true, random_close(rng));
        for (int i = 0; i < (int)p.nodes.size(); ++i) {
            int prev, next;
            neighbours_of(p, i, prev, next);
            const bool tangent = p.nodes[i].type == T;

            for (int isIn = 0; isIn < 2; ++isIn) {
                const int towardNode = isIn ? prev : next;
                const int other      = isIn ? next : prev;
                double ax = 0, ay = 0;
                const bool got = handle_axis(p, i, isIn == 1, ax, ay);
                CHECK(got == (tangent && (other >= 0 || towardNode >= 0)));
                if (!got) continue;
                CHECK_NEAR(std::hypot(ax, ay), 1.0, 1e-12);
                if (other >= 0) CHECK(points_at(p, other, i, ax, ay));
                else            CHECK(points_at(p, i, towardNode, ax, ay));
            }
        }
    }
}

// Converting nodes to Smooth or Tangent in any order gives the same result.
void prop_conversion_order_independent(Rng& rng, int runs)
{
    for (int r = 0; r < runs; ++r) {
        const Path base = random_path(rng, 3 + rng.below(8), false, random_close(rng));
        const int n = (int)base.nodes.size();
        std::vector<int>      picks;
        std::vector<NodeType> types;
        for (int i = 0; i < n; ++i) {
            if (rng.below(2)) { picks.push_back(i);  types.push_back(rng.below(2) ? S : T); }
        }

        Path a = base, b = base;
        for (size_t k = 0; k < picks.size(); ++k) set_node_type(a, picks[k], types[k]);
        for (size_t k = picks.size(); k > 0; --k) set_node_type(b, picks[k - 1], types[k - 1]);
        CHECK(same_handles(a, b, 0.0));
    }
}

// Turning a node into another type and back restores the path exactly, and a
// node that was born curved keeps its own handles when it becomes a Corner.
// Every side with a neighbour has a handle, except a Tangent's, which stays
// blank wherever its segment is straight.
void prop_every_side_has_a_handle(Rng& rng, int runs)
{
    for (int r = 0; r < runs; ++r) {
        const Path p = random_path(rng, 2 + rng.below(10), true, random_close(rng));
        const int  n = (int)p.nodes.size();
        const bool loop = p.close() != Close::Open && n >= 2;
        for (int i = 0; i < n; ++i) {
            if (p.nodes[i].type == T) continue;
            const int prev = i > 0     ? i - 1 : (loop ? n - 1 : -1);
            const int next = i + 1 < n ? i + 1 : (loop ? 0     : -1);
            if (prev >= 0 && dist(p, i, prev) > EPS) CHECK(has_in(p.nodes[i]));
            if (next >= 0 && dist(p, i, next) > EPS) CHECK(has_out(p.nodes[i]));
        }
    }
}

// A segment reported straight really is drawn as the straight line: every
// point of the curve lies on the chord between its two nodes.
void prop_straight_segments_are_drawn_straight(Rng& rng, int runs)
{
    for (int r = 0; r < runs; ++r) {
        const Path p = random_path(rng, 2 + rng.below(8), true, random_close(rng));
        const int  n = (int)p.nodes.size();
        const bool loop = p.close() != Close::Open && n >= 2;
        for (int i = 0; i < n; ++i) {
            const int j = i + 1 < n ? i + 1 : (loop ? 0 : -1);
            if (j < 0 || !segment_is_straight(p, i)) continue;

            const Node& a = p.nodes[i];
            const Node& b = p.nodes[j];
            const double cx = b.x - a.x, cy = b.y - a.y, len = std::hypot(cx, cy);
            if (len < EPS) continue;
            for (int k = 1; k < 8; ++k) {
                const double t = k / 8.0, m = 1 - t;
                const double x = m*m*m * a.x + 3*m*m*t * (a.x + a.hx_out)
                               + 3*m*t*t * (b.x + b.hx_in) + t*t*t * b.x;
                const double y = m*m*m * a.y + 3*m*m*t * (a.y + a.hy_out)
                               + 3*m*t*t * (b.y + b.hy_in) + t*t*t * b.y;
                const double across = ((x - a.x) * cy - (y - a.y) * cx) / len;
                CHECK(std::fabs(across) < 1e-9);
            }
        }
    }
}

void prop_conversion_round_trip(Rng& rng, int runs)
{
    const NodeType kinds[3] = {C, S, T};
    for (int r = 0; r < runs; ++r) {
        Path p = random_path(rng, 3 + rng.below(9), true, random_close(rng));
        const int i = rng.below((int)p.nodes.size());

        const Path   original = p;
        const NodeType from   = p.nodes[i].type;
        NodeType to = kinds[rng.below(3)];
        if (to == from) continue;

        set_node_type(p, i, to);
        if (to == C && from == T
            && !(p.close() == Close::Modifier && i == 0)) {
            // From a Tangent, a cusp keeps every handle the Tangent had.
            const Node& was = original.nodes[i];
            const Node& now = p.nodes[i];
            if (has_in(was))  CHECK(now.hx_in  == was.hx_in  && now.hy_in  == was.hy_in);
            if (has_out(was)) CHECK(now.hx_out == was.hx_out && now.hy_out == was.hy_out);
        }
        set_node_type(p, i, from);
        if (from != C) {
            // A curved node comes back exactly as it was.
            CHECK(same_handles(p, original, 1e-9));
            CHECK(!p.nodes[i].manual_in && !p.nodes[i].manual_out);
        } else {
            // A Corner that has been curved comes back a cusp.
            CHECK(p.nodes[i].type == C && p.nodes[i].cusp);
            if (to == S) {
                Path expected = original;
                expected.nodes[i].cusp = true;
                compute_handles(expected);
                CHECK(same_handles(p, expected, 1e-9));
            }
        }
    }
}

// Smoothing a node and making it a Corner again lands it on its chords, every
// time, whatever its handles were before.
void prop_smooth_then_cusp_lies_on_the_chords(Rng& rng, int runs)
{
    for (int r = 0; r < runs; ++r) {
        Path p = random_path(rng, 3 + rng.below(9), true, random_close(rng));
        const int  i = rng.below((int)p.nodes.size());
        const int  n = (int)p.nodes.size();
        if (p.close() == Close::Modifier && i == 0) continue;   // the close owns that one

        set_node_type(p, i, S);
        set_node_type(p, i, C);
        const bool loop = p.close() != Close::Open && n >= 2;
        const int prev = i > 0     ? i - 1 : (loop ? n - 1 : -1);
        const int next = i + 1 < n ? i + 1 : (loop ? 0     : -1);
        if (prev >= 0 && dist(p, i, prev) > EPS) CHECK(flat(p, i, prev, true));
        if (next >= 0 && dist(p, i, next) > EPS) CHECK(flat(p, i, next, false));
    }
}

// Pulling a handle where handle_axis gives a direction puts the handle on it
// with the dragged length. Where there is none, nothing happens.
void prop_pull_follows_axis(Rng& rng, int runs)
{
    for (int r = 0; r < runs; ++r) {
        Path p = random_path(rng, 3 + rng.below(9), true, random_close(rng));
        const int i = rng.below((int)p.nodes.size());
        const bool isIn = rng.below(2) == 1;
        const double tx = p.nodes[i].x + rng.uniform(-90, 90);
        const double ty = p.nodes[i].y + rng.uniform(-90, 90);
        if (p.nodes[i].type != T) continue;

        double ax = 0, ay = 0;
        CHECK(handle_axis(p, i, isIn, ax, ay));          // every Tangent side here has a neighbour
        drag_handle(p, i, isIn, tx, ty);

        const Node& q = p.nodes[i];
        CHECK(isIn ? q.manual_in : q.manual_out);
        const double hx = isIn ? q.hx_in : q.hx_out, hy = isIn ? q.hy_in : q.hy_out;
        CHECK_NEAR(std::hypot(hx, hy), std::hypot(tx - q.x, ty - q.y), 1e-9);
        CHECK_NEAR(cosine(hx, hy, ax, ay), 1.0, 1e-9);   // on the axis
        CHECK(all_finite(p));
    }
}

void run_property(const char* name, void (*fn)(Rng&, int), Rng& rng, int runs)
{
    g_test = name;
    const int before = g_failures;
    fn(rng, runs);
    std::printf("%-4s %s\n", g_failures == before ? "ok" : "FAIL", name);
}

#define PROPERTY(fn) run_property(#fn, fn, rng, runs)

void test_random_properties(int runs, uint64_t seed)
{
    Rng rng(seed);
    std::printf("-- random properties: %d paths each, seed %llu\n",
                runs, (unsigned long long)seed);
    PROPERTY(prop_handles_are_finite_and_sized);
    PROPERTY(prop_similarity_invariance);
    PROPERTY(prop_cyclic_shift);
    PROPERTY(prop_reversal);
    PROPERTY(prop_locality);
    PROPERTY(prop_idempotent);
    PROPERTY(prop_corner_arc_is_symmetric);
    PROPERTY(prop_all_smooth_has_full_handles);
    PROPERTY(prop_drag_matches_recompute);
    PROPERTY(prop_smooth_nodes_are_g1);
    PROPERTY(prop_tangent_rule);
    PROPERTY(prop_handle_axis_rule);
    PROPERTY(prop_conversion_order_independent);
    PROPERTY(prop_every_side_has_a_handle);
    PROPERTY(prop_straight_segments_are_drawn_straight);
    PROPERTY(prop_conversion_round_trip);
    PROPERTY(prop_smooth_then_cusp_lies_on_the_chords);
    PROPERTY(prop_pull_follows_axis);
}

struct TestCase { const char* name; void (*fn)(); };

#define TEST(fn) { #fn, fn }
const TestCase kTests[] = {
    TEST(test_tangent_between_sharp_neighbours_is_a_polygon_corner),
    TEST(test_tangent_between_smooth_neighbours_is_a_notch),
    TEST(test_tangent_at_open_ends),
    TEST(test_tangent_ignores_coincident_neighbour),
    TEST(test_tangent_beside_modifier_start),
    TEST(test_handle_axis_contract),
    TEST(test_directly_placed_tangent_has_its_handle),
    TEST(test_wave_with_tangents),
    TEST(test_cusp_straightens_its_own_sides),
    TEST(test_tangent_follows_whether_its_segment_is_curved),
    TEST(test_make_node_is_never_a_cusp),
    TEST(test_set_node_type_ignores_same_type_and_bad_index),
    TEST(test_converting_to_smooth_or_tangent_resets_the_handles),
    TEST(test_modifier_start_node_toggles_back_to_what_the_close_made),
    TEST(test_smooth_to_cusp_lies_along_the_chords),
    TEST(test_node_drawn_sharp_toggles_between_smooth_and_cusp),
    TEST(test_node_born_curved_toggles_between_smooth_and_cusp),
    TEST(test_cusp_keeps_both_handles_when_a_neighbour_is_pulled),
    TEST(test_freehand_closed_convert_one_node),
    TEST(test_freehand_closed_convert_two_nodes),
    TEST(test_freehand_closed_convert_all_in_any_order),
    TEST(test_freehand_open_convert_one_node),
    TEST(test_freehand_open_convert_third_then_second),
    TEST(test_freehand_open_convert_all),
    TEST(test_freehand_circle_of_four_tangents),
    TEST(test_pull_either_side_of_a_tangent_between_sharp_nodes),
    TEST(test_pull_where_there_is_no_direction_is_ignored),
    TEST(test_pulling_back_to_the_node_removes_the_handle),
    TEST(test_pulling_one_handle_leaves_the_other_automatic),
    TEST(test_pull_handle_beyond_an_open_end),
    TEST(test_pulled_handle_follows_its_axis_when_neighbours_move),
    TEST(test_pulled_handle_is_cleared_when_its_axis_disappears),
    TEST(test_pulled_handle_is_kept_when_neighbour_types_change),
    TEST(test_corner_ignores_a_pulled_tangent_handle),
    TEST(test_all_corners_draw_straight_lines),
    TEST(test_smooth_circle),
    TEST(test_smooth_unequal_distances),
    TEST(test_smooth_ends_follow_their_chord),
    TEST(test_corner_reflects_neighbour_arc),
    TEST(test_end_corner_beside_smooth),
    TEST(test_sharp_node_can_be_pulled_straight_away),
    TEST(test_segment_is_straight),
    TEST(test_corner_between_corners_is_a_straight_line),
    TEST(test_tangent_after_corner),
    TEST(test_tangent_before_corner),
    TEST(test_tangent_in_closed_path),
    TEST(test_plain_close_keeps_start_type),
    TEST(test_modifier_close_start_node),
    TEST(test_modifier_close_start_corner_reflects_out),
    TEST(test_close_path_rules),
    TEST(test_close_state_and_start_node_agree),
    TEST(test_modifier_close_turns_the_start_node_into_a_corner),
    TEST(test_handle_fraction_option),
    TEST(test_recompute_follows_moves_and_type_changes),
    TEST(test_freehand_shield),
    TEST(test_freehand_click_patterns),
    TEST(test_drag_smooth_mirrors_opposite),
    TEST(test_drag_updates_neighbouring_corners),
    TEST(test_drag_corner_leaves_opposite_alone),
    TEST(test_drag_with_missing_opposite_handle),
    TEST(test_drag_tangent_keeps_direction_and_takes_length),
    TEST(test_manual_survives_recompute),
    TEST(test_manual_smooth_heading_steers_neighbours),
    TEST(test_manual_in_handle_alone_steers_neighbours),
    TEST(test_release_manual_handles),
    TEST(test_drag_on_modifier_start_does_not_mirror),
    TEST(test_drag_bad_index_is_ignored),
    TEST(test_tiny_paths),
    TEST(test_coincident_nodes),
    TEST(test_path_that_goes_out_and_comes_back),
    TEST(test_smooth_node_at_any_scale),
    TEST(test_two_node_loop_plain_close_is_an_ellipse),
    TEST(test_two_node_loop_modifier_close_makes_a_cusp),
    TEST(test_two_node_loop_corner_beside_smooth),
    TEST(test_two_node_loop_of_corners_is_flat),
    TEST(test_two_node_loop_toggles),
    TEST(test_coincidence_in_a_larger_loop_stays_plain),
    TEST(test_huge_and_tiny_coordinates),
    TEST(test_demo_scenes),
};

}   // namespace

int main(int argc, char** argv)
{
    int      runs = 20000;
    uint64_t seed = 1;
    for (int i = 1; i < argc; ++i) {
        if (!std::strcmp(argv[i], "--runs") && i + 1 < argc) runs = std::atoi(argv[++i]);
        else if (!std::strcmp(argv[i], "--seed") && i + 1 < argc) seed = (uint64_t)std::atoll(argv[++i]);
        else { std::printf("usage: %s [--runs N] [--seed N]\n", argv[0]); return 2; }
    }

    for (size_t t = 0; t < sizeof(kTests) / sizeof(kTests[0]); ++t) {
        g_test = kTests[t].name;
        const int before = g_failures;
        kTests[t].fn();
        std::printf("%-4s %s\n", g_failures == before ? "ok" : "FAIL", kTests[t].name);
    }

    test_random_properties(runs, seed);

    std::printf("\n%d checks, %d failed\n", g_checks, g_failures);
    return g_failures == 0 ? 0 : 1;
}

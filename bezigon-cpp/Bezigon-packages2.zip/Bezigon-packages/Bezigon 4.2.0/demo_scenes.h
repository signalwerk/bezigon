// This file is part of Bezigon, released under the MIT License.
// See LICENSE for details.
//
// Diese Datei ist Teil von Bezigon und steht unter der MIT-Lizenz.
// Siehe LICENSE für Einzelheiten.

// demo_scenes.h
// Ready-made paths for checking the demo by eye (keys 1-7 in main.cpp) and
// for the automated tests. Plain data: no graphics library needed.

#pragma once
#include "bezigon.h"

namespace bezigon {
namespace scenes {

struct SceneNode { double x, y; NodeType type; };

struct Scene
{
    const char*      name;
    Close            close;
    int              count;
    const SceneNode* nodes;
};

const NodeType C = NodeType::Corner;
const NodeType S = NodeType::Smooth;
const NodeType T = NodeType::Tangent;

// 1. Shield. Corner, Smooth, Corner, ... closed with a plain click.
//    The measured FreeHand shield: corners get cusps that reflect the arcs.
const SceneNode shield[] = {
    {431,  27, C}, {307, 178, S}, {119, 220, C}, {121, 488, S},
    {430, 833, C}, {716, 446, S}, {733, 214, C}, {589, 206, S},
};

// 2. Corner then curve: a straight edge, then a curve that leaves it
//    without a kink. Open path with one Tangent node.
const SceneNode lineToCurve[] = {
    {100, 500, C}, {300, 500, T}, {450, 380, S}, {600, 380, S},
};

// 3. "D" shape: straight top, bottom and left sides with a rounded right
//    end. The Tangent nodes sit where a straight side meets the curve.
//    Closed with a plain click.
const SceneNode dShape[] = {
    {150, 200, C}, {450, 200, T}, {580, 300, S}, {450, 400, T}, {150, 400, C},
};

// 4. Notch: a Tangent between two Smooth neighbours. Its handles are
//    locked to the chords of the opposite neighbours, so the curve gets a
//    notch instead of flowing through. Closed with a plain click.
const SceneNode notch[] = {
    {400, 100, S}, {590, 238, S}, {517, 462, T}, {283, 462, S}, {210, 238, S},
};

// 5. Four corners. Every side is a bare line, no handles at all.
const SceneNode square[] = {
    {250, 150, C}, {550, 150, C}, {550, 450, C}, {250, 450, C},
};

// 6. Teardrop: modifier close. The start node was placed Smooth, so after
//    the modifier close it is a Corner whose handles both point straight
//    at its neighbours, which pulls the tip into a point.
const SceneNode teardrop[] = {
    {400, 100, S}, {600, 250, S}, {550, 450, S}, {250, 450, S}, {200, 250, S},
};

// 7. Wave: an open path that starts with a Tangent. The first Tangent has an
//    out-handle toward node 2; the middle one has both handles and makes a
//    small notch. Measured from FreeHand.
const SceneNode wave[] = {
    {110, 354, T}, {396, 219, S}, {686, 404, T}, {962, 218, S},
};

const Scene all[] = {
    { "shield (plain close)",            Close::Plain,    8, shield      },
    { "line to curve (open)",            Close::Open,     4, lineToCurve },
    { "D shape (plain close)",           Close::Plain,    5, dShape      },
    { "tangent notch (plain close)",     Close::Plain,    5, notch       },
    { "square of corners (plain close)", Close::Plain,    4, square      },
    { "teardrop (modifier close)",       Close::Modifier, 5, teardrop    },
    { "wave with tangents (open)",       Close::Open,     4, wave        },
};
const int count = (int)(sizeof(all) / sizeof(all[0]));

// Build the path for a scene, handles included.
inline Path build(const Scene& s)
{
    Path p;
    for (int i = 0; i < s.count; ++i) {
        p.nodes.push_back(make_node(s.nodes[i].x, s.nodes[i].y, s.nodes[i].type));
    }
    if (s.close != Close::Open) close_path(p, s.close == Close::Modifier);
    compute_handles(p);
    return p;
}

}   // namespace scenes
}   // namespace bezigon
